# Beam Lab local edition

Install Node.js 20 or newer. From this extracted directory run `npm start --prefix simulator`, then open http://localhost:4173/. No npm installation step is needed. BOM edits and setup snapshots stay on disk. Optional component research uses your own Codex CLI installation and session; read simulator/CODEX_RESEARCH.md. This curated source package contains no personal run history or credentials. The detector and scan boards are unbuilt engineering prototypes; the synthetic images do not establish measured microscope resolution.
