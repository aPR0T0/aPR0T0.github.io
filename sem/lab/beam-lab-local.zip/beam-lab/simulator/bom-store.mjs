import {StoreError, PARAMETER_SCHEMA, validateParameters, presentBom, ROLES, STATUSES} from './bom-model.js';
export {StoreError, PARAMETER_SCHEMA, validateParameters} from './bom-model.js';
import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import { DEFAULTS } from './physics.js';
import { BSE_DEFAULTS } from './bse.js';
import { CURRENT_DEFAULTS } from './current.js';
import { DEFAULTS as BASE_DEFAULTS } from './versions/v1/physics.js';
import { ELECTRICAL_DEFAULTS, ELECTRICAL_PARAMETER_SCHEMA } from './electrical.js';
import { DEFAULT_PROGRAM, generateFirmware } from './scan.js';
import { LEGACY_SCAN_HARDWARE } from './scan-hardware.js';

// Saved-view metadata only; specimen selection is not a physical BOM parameter.
const SPECIMEN_IDS = new Set(['calibration', 'butterfly-wing', 'spheres', 'diatom', 'metal-grains', 'microchip', 'fibers']);

/** RFC 4180-style quoted CSV, including embedded newlines and escaped quotation marks. */
export function parseCsv(input) {
  const text = input.replace(/^\uFEFF/, '');
  const records = []; let record = [], field = '', quoted = false, afterQuote = false;
  const cell = () => { record.push(field); field = ''; afterQuote = false; };
  const row = () => { cell(); if (record.some(value => value !== '')) records.push(record); record = []; };
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (quoted) {
      if (c === '"') { if (text[i + 1] === '"') { field += '"'; i++; } else { quoted = false; afterQuote = true; } }
      else field += c;
    } else if (c === '"') {
      if (field || afterQuote) throw new StoreError(422, 'Invalid quotation in BOM CSV.');
      quoted = true;
    } else if (c === ',') cell();
    else if (c === '\r' || c === '\n') { if (c === '\r' && text[i + 1] === '\n') i++; row(); }
    else { if (afterQuote) throw new StoreError(422, 'Unexpected character after CSV quote.'); field += c; }
  }
  if (quoted) throw new StoreError(422, 'Unclosed quote in BOM CSV.');
  if (field || record.length || afterQuote) row();
  const columns = records.shift() || [];
  if (!columns.length || columns.some(c => !c) || new Set(columns).size !== columns.length) throw new StoreError(422, 'BOM needs unique nonempty CSV column headings.');
  return { columns, rows: records.map((values, index) => {
    if (values.length !== columns.length) throw new StoreError(422, `BOM row ${index + 2} has ${values.length} fields; expected ${columns.length}.`);
    return Object.fromEntries(columns.map((column, j) => [column, values[j]]));
  }) };
}

export function serializeCsv({ columns, rows }) {
  const escape = value => { const text = String(value ?? ''); return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text; };
  return [columns, ...rows.map(row => columns.map(column => row[column] ?? ''))].map(row => row.map(escape).join(',')).join('\r\n') + '\r\n';
}

const hash = value => createHash('sha256').update(value).digest('hex');
const sourceHash = row => row ? hash(JSON.stringify(row)) : '';
const mappingColumns = ['Id','Reference','Role','Name','Manufacturer','MPN','Datasheet','Status','Parameters','Notes','SourceFile','SourceRef','SourceFingerprint'];
const checkedString = (value, field, max = 12000) => { if (typeof value !== 'string' || value.length > max || value.includes('\0')) throw new StoreError(400, `${field} must be text below ${max} characters.`); return value; };

export function createBomStore({ repoRoot, dataDir = path.join(repoRoot, 'simulator/data') }) {
  const definitions = [
    { id: 'external', label: 'External system BOM', path: 'bom/external_system_bom.csv' },
    { id: 'pcb', label: 'Controller PCB BOM', path: 'bom/pcb_bom.csv' },
    { id: 'detector', label: 'LMC662 detector PCB BOM', path: 'detector-pcb/bom.csv', optional:true },
    { id: 'scan-dac', label: 'DAC80502 scan PCB BOM', path: 'scan-dac-pcb/bom.csv', optional:true },
    { id: 'simulation', label: 'Simulation component mapping', path: 'bom/simulation_parts.csv' },
  ];
  let queue = Promise.resolve();
  const serial = fn => { const next = queue.then(fn, fn); queue = next.catch(() => {}); return next; };

  async function readRaw() {
    const files = await Promise.all(definitions.map(async definition => {
      let text;
      try { text = await fs.readFile(path.join(repoRoot, definition.path), 'utf8'); }
      catch(error) { if(error.code==='ENOENT'&&definition.optional)return null; throw error; }
      return { ...definition, text, ...parseCsv(text) };
    }));
    const available = files.filter(Boolean);
    return { revision: hash(available.map(file => `${file.id}\0${file.text}`).join('\0')), files:available };
  }

  const present = raw => presentBom(raw, sourceHash);

  async function getBom() { return present(await readRaw()); }
  function checkRevision(revision, raw) { if (typeof revision !== 'string' || revision !== raw.revision) throw new StoreError(409, 'The BOM changed since you opened it. Reload before saving.', { revision: raw.revision }); }

  async function commit(raw, changed, description) {
    // Keep the exact originals before atomic per-file replacement. Revision check also catches external editor changes.
    checkRevision(raw.revision, await readRaw());
    const backupDir = path.join(dataDir, 'history', `${Date.now()}-${randomUUID()}`);
    await fs.mkdir(backupDir, { recursive: true });
    const staged = [];
    try {
      for (const file of changed) {
        const original = raw.files.find(original => original.id === file.id);
        await fs.writeFile(path.join(backupDir, `${file.id}.csv`), original.text, { flag: 'wx' });
        const target = path.join(repoRoot, file.path), temporary = `${target}.${randomUUID()}.tmp`;
        await fs.writeFile(temporary, serializeCsv(file), { flag: 'wx' });
        staged.push({ temporary, target });
      }
      await fs.writeFile(path.join(backupDir, 'change.json'), JSON.stringify({ at: new Date().toISOString(), description, previousRevision: raw.revision, files: changed.map(f => f.path) }, null, 2));
      checkRevision(raw.revision, await readRaw());
      for (const { temporary, target } of staged) await fs.rename(temporary, target);
    } finally { await Promise.all(staged.map(({ temporary }) => fs.unlink(temporary).catch(() => {}))); }
    return getBom();
  }

  async function updateRow(fileId, rowId, body) {
    return serial(async () => {
      const raw = await readRaw(); checkRevision(body.revision, raw);
      const original = raw.files.find(file => file.id === fileId);
      if (!original) throw new StoreError(404, 'BOM file not found.');
      const index = /^row-[1-9]\d*$/.test(rowId) ? Number(rowId.slice(4)) - 1 : -1;
      if (!original.rows[index]) throw new StoreError(404, 'BOM row not found.');
      if (!body.values || typeof body.values !== 'object' || Array.isArray(body.values)) throw new StoreError(400, 'Provide values as a column-to-text object.');
      const file = { ...original, rows: original.rows.map(row => ({ ...row })) };
      for (const [field, value] of Object.entries(body.values)) {
        if (!file.columns.includes(field)) throw new StoreError(400, `Unknown column: ${field}.`);
        if (file.id === 'simulation' && ['Id','SourceFingerprint'].includes(field)) {
          if (value !== file.rows[index][field]) throw new StoreError(400, `${field} is managed by Beam Lab.`);
          continue;
        }
        file.rows[index][field] = checkedString(value, field);
      }
      if (!file.rows[index].Reference?.trim()) throw new StoreError(400, 'Reference cannot be empty.');
      if (new Set(file.rows.map(row => row.Reference)).size !== file.rows.length) throw new StoreError(400, 'References must be unique within a BOM file.');
      if (file.id === 'simulation') validateMapping(file.rows[index]);
      return commit(raw, [file], `Updated ${file.id}/${rowId}`);
    });
  }

  function validateMapping(row) {
    if (!ROLES.includes(row.Role)) throw new StoreError(400, 'Unknown component role.');
    if (!STATUSES.includes(row.Status)) throw new StoreError(400, 'Unknown component status.');
    try { validateParameters(JSON.parse(row.Parameters)); } catch (error) { throw new StoreError(400, `Invalid component parameters: ${error.message}`); }
    if (row.SourceFile && !['external','pcb','detector'].includes(row.SourceFile)) throw new StoreError(400, 'SourceFile must be external, pcb or detector.');
    if (Boolean(row.SourceFile) !== Boolean(row.SourceRef)) throw new StoreError(400, 'SourceFile and SourceRef must both be set, or both empty.');
  }

  async function updateComponent(id, body) {
    return serial(async () => {
      const raw = await readRaw(); checkRevision(body.revision, raw);
      const original = raw.files.find(file => file.id === 'simulation');
      const file = { ...original, rows: original.rows.map(row => ({ ...row })) }, row = file.rows.find(row => row.Id === id);
      if (!row) throw new StoreError(404, 'Component not found.');
      const fields = { reference:'Reference',role:'Role',name:'Name',manufacturer:'Manufacturer',mpn:'MPN',datasheet:'Datasheet',status:'Status',parameters:'Parameters',notes:'Notes',sourceFile:'SourceFile',sourceRef:'SourceRef' };
      if (!body.values || typeof body.values !== 'object' || Array.isArray(body.values)) throw new StoreError(400, 'Provide component values as an object.');
      for (const [key, value] of Object.entries(body.values)) {
        if (!Object.hasOwn(fields, key)) throw new StoreError(400, `Unknown component field: ${key}.`);
        row[fields[key]] = key === 'parameters' ? JSON.stringify(validateParameters(value)) : checkedString(value, key);
      }
      validateMapping(row);
      const changed = [file];
      if (row.SourceRef) {
        const sourceOriginal = raw.files.find(source => source.id === row.SourceFile);
        const sourceFile = { ...sourceOriginal, rows: sourceOriginal.rows.map(source => ({ ...source })) };
        const source = sourceFile.rows.find(source => source.Reference === row.SourceRef);
        if (!source) throw new StoreError(400, 'Linked source reference does not exist.');
        let touchedSource = false;
        for (const key of ['manufacturer','mpn','datasheet']) if (key in body.values) {
          const column = key==='mpn'&&sourceFile.columns.includes('MPN_or_procurement_spec')?'MPN_or_procurement_spec':fields[key];
          if (!sourceFile.columns.includes(column)) sourceFile.columns=[...sourceFile.columns,column];
          source[column] = row[fields[key]]; touchedSource = true;
        }
        if (touchedSource) {
          changed.push(sourceFile);
          if (!('status' in body.values) && sourceHash(source) !== sourceHash(sourceOriginal.rows.find(source => source.Reference === row.SourceRef))) row.Status = 'needs-research';
        }
        // Saving a review records which hardware identity these model parameters refer to.
        if ('parameters' in body.values || 'status' in body.values || touchedSource) row.SourceFingerprint = sourceHash(source);
      } else row.SourceFingerprint = '';
      return commit(raw, changed, `Updated model component ${id}`);
    });
  }

  async function resolveBom({ allowAssumptions = false } = {}) {
    if (typeof allowAssumptions !== 'boolean') throw new StoreError(400, 'allowAssumptions must be boolean.');
    const bom = await getBom();
    const parameters = { ...DEFAULTS };
    for (const component of bom.components) Object.assign(parameters, component.parameters);
    const blocked = bom.issues.some(issue => issue.severity === 'error' || !allowAssumptions);
    return { ready: !blocked, revision: bom.revision, parameters, issues: bom.issues, components: bom.components,
      usedAssumptions: allowAssumptions && bom.issues.some(issue => issue.severity !== 'error'),
      model: 'Educational SEM model; component settings require independent hardware validation.' };
  }

  /** Explicit upgrade only: ordinary BOM reads never invent missing component values. */
  async function migrateElectricalMappings() {
    return serial(async () => {
      const raw = await readRaw();
      const original = raw.files.find(file => file.id === 'simulation');
      const file = { ...original, rows: original.rows.map(row => ({ ...row })) };
      const roleKeys = {
        acceleration: ['gunGap'], aperture: ['anodeApertureGap', 'apertureBias'],
        heater: ['heaterResistance'], lens: ['lensResistance'],
      };
      const known = new Set();
      for (const row of file.rows) {
        let parameters;
        try { parameters = validateParameters(JSON.parse(row.Parameters)); }
        catch (error) { throw new StoreError(422, `Review ${row.Reference} before upgrading electrical mappings: ${error.message}`); }
        for (const key of Object.keys(parameters)) known.add(key);
      }
      let changed = false;
      for (const [role, keys] of Object.entries(roleKeys)) {
        const missing = keys.filter(key => !known.has(key));
        if (!missing.length) continue;
        const candidates = file.rows.filter(row => row.Role === role);
        if (candidates.length !== 1) throw new StoreError(422, `Electrical mapping upgrade needs one unambiguous ${role} component.`);
        const row = candidates[0], parameters = JSON.parse(row.Parameters);
        for (const key of missing) parameters[key] = ELECTRICAL_DEFAULTS[key];
        row.Parameters = JSON.stringify(parameters);
        const description = missing.map(key => `${key}=${ELECTRICAL_DEFAULTS[key]} ${ELECTRICAL_PARAMETER_SCHEMA[key].unit}`).join(', ');
        row.Notes = `${row.Notes}${row.Notes ? '\n\n' : ''}Electrical visualization assumptions added: ${description}. These illustrative geometry/resistance values require measurement or component documentation before hardware use.`;
        if (row.Status === 'verified' || row.Status === 'user-defined') row.Status = 'needs-research';
        changed = true;
      }
      if (!changed) return present(raw);
      return commit(raw, [file], 'Added explicitly labeled electrical visualization assumptions; retained existing BOM values');
    });
  }

  async function baseSetup() {
    let firmwareCode = '';
    try { firmwareCode = await fs.readFile(path.join(repoRoot, 'simulator/versions/v1/firmware/ESP32_scan/ESP32_scan.ino'), 'utf8'); }
    catch { firmwareCode = generateFirmware(LEGACY_SCAN_HARDWARE); }
    return { id:'base-v1',name:'Base v1 · original parameters',createdAt:'2026-09-11T00:00:00.000Z',parameters:{...BASE_DEFAULTS},operatingState:{requestedBeam:true,roughing:true,turbo:true},trajectoryCode:DEFAULT_PROGRAM,firmwareCode,source:'base-v1',bomRevision:null,immutable:true };
  }

  async function getSetup(id) {
    if (id === 'base-v1') return baseSetup();
    if (id === 'previous-v1-session') {
      try {
        const previous = JSON.parse(await fs.readFile(path.join(repoRoot, 'simulator/previous-session.json'), 'utf8'));
        return { ...previous,createdAt:previous.createdAt || previous.capturedAt,bomRevision:previous.bomRevision || null,immutable:true };
      }
      catch (error) { if (error.code === 'ENOENT') throw new StoreError(404, 'Previous session is unavailable.'); throw error; }
    }
    if (!/^[0-9a-f-]{36}$/.test(id)) throw new StoreError(404, 'Saved setup not found.');
    try { return JSON.parse(await fs.readFile(path.join(dataDir, 'setups', `${id}.json`), 'utf8')); }
    catch (error) { if (error.code === 'ENOENT') throw new StoreError(404, 'Saved setup not found.'); throw error; }
  }

  async function listSetups() {
    let names = []; try { names = await fs.readdir(path.join(dataDir, 'setups')); } catch (error) { if (error.code !== 'ENOENT') throw error; }
    const snapshots = await Promise.all(names.filter(name => /^[0-9a-f-]{36}\.json$/.test(name)).map(name => getSetup(name.slice(0, -5))));
    snapshots.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    const summarize = ({ id,name,createdAt,source,bomRevision,immutable,parameters,operatingState,specimenId }) => ({
      id,name,createdAt,source,bomRevision,immutable,parameters,operatingState,
      ...(specimenId === undefined ? {} : { specimenId }),
    });
    let previous = [];
    try { previous = [summarize(await getSetup('previous-v1-session'))]; } catch (error) { if (error.status !== 404) throw error; }
    return { setups: [...previous, summarize(await baseSetup()), ...snapshots.map(summarize)] };
  }

  async function saveSetup(body) {
    // Legacy snapshots may omit only these new model assumptions. Every prior
    // physical parameter remains required; saving creates a new immutable file.
    validateParameters(body.parameters);
    const legacyAdditions={...ELECTRICAL_DEFAULTS,...BSE_DEFAULTS,...CURRENT_DEFAULTS,...LEGACY_SCAN_HARDWARE,detectorMode:'et'};
    const parameterDefaultsApplied = Object.keys(legacyAdditions).filter(key => !Object.hasOwn(body.parameters, key));
    const parameters = validateParameters({ ...legacyAdditions, ...body.parameters }, { complete: true });
    const name = checkedString(body.name || 'Untitled setup', 'name', 100).trim();
    if (!name) throw new StoreError(400, 'Name cannot be blank.');
    const snapshot = { id:randomUUID(),name,createdAt:new Date().toISOString(),parameters,
      trajectoryCode:checkedString(body.trajectoryCode ?? DEFAULT_PROGRAM, 'trajectoryCode', 24000),
      firmwareCode:checkedString(body.firmwareCode ?? '', 'firmwareCode', 200000),
      source:checkedString(body.source || 'manual', 'source', 120),
      bomRevision:body.bomRevision == null ? null : checkedString(body.bomRevision, 'bomRevision', 128),immutable:true };
    if (body.specimenId !== undefined) {
      if (!SPECIMEN_IDS.has(body.specimenId)) throw new StoreError(400, `specimenId must be one of: ${[...SPECIMEN_IDS].join(', ')}.`);
      snapshot.specimenId = body.specimenId;
    }
    if (parameterDefaultsApplied.length) snapshot.parameterDefaultsApplied = parameterDefaultsApplied;
    if (body.trajectoryDraft !== undefined) snapshot.trajectoryDraft = checkedString(body.trajectoryDraft, 'trajectoryDraft', 24000);
    if (body.firmwareAppliedCode !== undefined) snapshot.firmwareAppliedCode = checkedString(body.firmwareAppliedCode, 'firmwareAppliedCode', 200000);
    if (body.operatingState !== undefined) {
      if (!body.operatingState || typeof body.operatingState !== 'object' || Array.isArray(body.operatingState)) throw new StoreError(400, 'operatingState must be an object.');
      snapshot.operatingState = {};
      for (const key of ['requestedBeam','roughing','turbo']) if (Object.hasOwn(body.operatingState, key)) {
        if (typeof body.operatingState[key] !== 'boolean') throw new StoreError(400, `${key} must be boolean.`);
        snapshot.operatingState[key] = body.operatingState[key];
      }
    }
    const directory = path.join(dataDir, 'setups'); await fs.mkdir(directory, { recursive:true });
    await fs.writeFile(path.join(directory, `${snapshot.id}.json`), JSON.stringify(snapshot, null, 2), { flag:'wx' });
    return snapshot;
  }
  return { getBom, updateRow, updateComponent, resolveBom, migrateElectricalMappings, listSetups, getSetup, saveSetup };
}

export { mappingColumns };
