import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createBomStore, StoreError, PARAMETER_SCHEMA, validateParameters } from './bom-store.mjs';

const moduleRoot = path.dirname(fileURLToPath(import.meta.url));
const types = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.webp':'image/webp','.md':'text/plain; charset=utf-8','.ino':'text/plain; charset=utf-8'};

function respond(res, status, value) {
  res.writeHead(status, { 'Content-Type':'application/json; charset=utf-8', 'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff' });
  res.end(JSON.stringify(value));
}

function requestSecurity(req) {
  let url;
  try { url = new URL(`http://${req.headers.host}`); } catch { throw new StoreError(403, 'Invalid local Host header.'); }
  if (!['localhost','127.0.0.1','[::1]'].includes(url.hostname) || url.username || url.password) throw new StoreError(403, 'This server accepts localhost requests only.');
  const mutation = !['GET','HEAD','OPTIONS'].includes(req.method);
  if (mutation) {
    if (req.headers.origin && req.headers.origin !== url.origin) throw new StoreError(403, 'Cross-origin edits are not allowed.');
    if (req.headers['sec-fetch-site'] === 'cross-site') throw new StoreError(403, 'Cross-site edits are not allowed.');
    if (req.headers['x-beam-lab'] !== '1') throw new StoreError(403, 'BOM edits require the Beam Lab request header.');
    if (!(req.headers['content-type'] || '').toLowerCase().startsWith('application/json')) throw new StoreError(415, 'Send application/json.');
  }
}

async function readBody(req) {
  let bytes = 0; const chunks = [];
  for await (const chunk of req) {
    bytes += chunk.length;
    if (bytes > 600000) throw new StoreError(413, 'Request exceeds 600 KB.');
    chunks.push(chunk);
  }
  try {
    const result = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}');
    if (!result || typeof result !== 'object' || Array.isArray(result)) throw new Error();
    return result;
  } catch { throw new StoreError(400, 'Request body must be a JSON object.'); }
}

async function defaultResearch({ repoRoot, dataDir }) {
  try {
    const { createResearchService } = await import('./research-service.mjs');
    return createResearchService({ cwd:repoRoot, dataDir:path.join(dataDir, 'research'), parameterRules:PARAMETER_SCHEMA });
  } catch (error) {
    return {
      getStatus:async () => ({ available:false, reason:`Codex research bridge could not start: ${error.message}` }),
      start:() => { throw new StoreError(503, 'Codex research is unavailable. Enter reviewed model values, or use a saved setup.'); },
      get:() => null,
      cancel:() => null,
    };
  }
}

export function createServer({ root = moduleRoot, repoRoot = path.dirname(root), dataDir = path.join(root, 'data'), researchService, store = createBomStore({ repoRoot, dataDir }) } = {}) {
  const researchPromise = researchService ? Promise.resolve(researchService) : defaultResearch({ repoRoot, dataDir });
  const researchSources = new Map();
  const server = http.createServer(async (req, res) => {
    try {
      requestSecurity(req);
      const url = new URL(req.url, 'http://localhost');
      const parts = url.pathname.split('/').filter(Boolean).map(decodeURIComponent);
      if (parts[0] === 'api') {
        const research = await researchPromise;
        if (req.method === 'GET' && parts.length === 2 && parts[1] === 'status') return respond(res, 200, { version:'4.0.0',baseVersion:'1.0.0',baseUrl:'/base/',localOnly:true,codex:await research.getStatus() });
        if (req.method === 'GET' && parts.length === 2 && parts[1] === 'bom') return respond(res, 200, await store.getBom());
        if (req.method === 'PUT' && parts.length === 4 && parts[1] === 'bom') return respond(res, 200, await store.updateRow(parts[2], parts[3], await readBody(req)));
        if (req.method === 'PUT' && parts.length === 3 && parts[1] === 'components') return respond(res, 200, await store.updateComponent(parts[2], await readBody(req)));
        if (req.method === 'POST' && parts.length === 2 && parts[1] === 'resolve-bom') return respond(res, 200, await store.resolveBom(await readBody(req)));
        if (req.method === 'GET' && parts.length === 2 && parts[1] === 'setups') return respond(res, 200, await store.listSetups());
        if (req.method === 'GET' && parts.length === 3 && parts[1] === 'setups') return respond(res, 200, await store.getSetup(parts[2]));
        if (req.method === 'POST' && parts.length === 2 && parts[1] === 'setups') return respond(res, 201, await store.saveSetup(await readBody(req)));
        if (req.method === 'GET' && parts.join('/') === 'api/research/status') return respond(res, 200, await research.getStatus());
        if (req.method === 'POST' && parts.length === 2 && parts[1] === 'research') {
          const body = await readBody(req), bom = await store.getBom();
          const component = bom.components.find(component => component.id === body.componentId);
          if (!component) throw new StoreError(404, 'Component not found.');
          const job = await research.start({ ...component, sourceRevision:bom.revision });
          if (!researchSources.has(job.id)) researchSources.set(job.id, { componentId:component.id, identity:identityOf(component), revision:bom.revision });
          return respond(res, 202, job);
        }
        if (req.method === 'GET' && parts.length === 3 && parts[1] === 'research') {
          const job = await research.get(parts[2]);
          if (!job) throw new StoreError(404, 'Research job not found.');
          return respond(res, 200, job);
        }
        if (req.method === 'POST' && parts.length === 4 && parts[1] === 'research' && parts[3] === 'cancel') {
          await readBody(req);
          const job = await research.cancel(parts[2]);
          if (!job) throw new StoreError(404, 'Research job not found.');
          return respond(res, 200, job);
        }
        if (req.method === 'POST' && parts.length === 4 && parts[1] === 'research' && parts[3] === 'apply') {
          const body = await readBody(req), job = await research.get(parts[2]), bom = await store.getBom();
          if (!job) throw new StoreError(404, 'Research job not found.');
          if (job.status !== 'completed' || !job.result) throw new StoreError(409, 'Research has not completed successfully.');
          if (body.revision !== bom.revision) throw new StoreError(409, 'The BOM changed. Reload before reviewing this proposal.');
          const captured = researchSources.get(job.id);
          const component = bom.components.find(component => component.id === job.componentId);
          if (!captured || !component || captured.identity !== identityOf(component)) throw new StoreError(409, 'This component changed since research started. Research the current component again.');
          const parameters = { ...component.parameters }, accepted = [], skipped = [];
          for (const finding of job.result.findings || []) {
            const rule = Object.hasOwn(PARAMETER_SCHEMA, finding.parameter) ? PARAMETER_SCHEMA[finding.parameter] : null;
            let allowed = finding.confidence === 'high' && rule && finding.unit === rule.unit && Object.hasOwn(component.parameters, finding.parameter);
            try { if (!/^https?:$/.test(new URL(finding.sourceUrl).protocol)) allowed = false; validateParameters({[finding.parameter]:finding.value}); } catch { allowed = false; }
            if (allowed) { parameters[finding.parameter] = finding.value; accepted.push(finding.parameter); }
            else skipped.push(finding.parameter);
          }
          if (!accepted.length) throw new StoreError(422, 'No high-confidence findings with matching model units can be applied. Review the unknowns or enter manual values.');
          const complete = job.result.ready && !(job.result.unknowns || []).length && Object.keys(component.parameters).every(key => accepted.includes(key));
          const references = [...new Set((job.result.findings || []).filter(f => accepted.includes(f.parameter)).map(f => f.sourceUrl))];
          const notes = `${component.notes}\nCodex proposal ${job.id} applied ${new Date().toISOString()}. Applied: ${accepted.join(', ')}. Sources: ${references.join(' ')}${complete ? '' : ' Unresolved model values remain; review before hardware use.'}`.slice(0, 12000);
          const updated = await store.updateComponent(component.id, { revision:body.revision,values:{parameters,status:complete?'verified':'needs-research',notes} });
          return respond(res, 200, { ...updated, applied:accepted,skipped,fullyVerified:complete });
        }
        throw new StoreError(404, 'API route not found.');
      }
      if (!['GET','HEAD'].includes(req.method)) throw new StoreError(405, 'Method not allowed.');
      if (['detector-pcb','scan-dac-pcb'].includes(parts[0])) {
        const relative = parts.slice(1);
        if (!relative.length) { res.writeHead(302,{Location:`/${parts[0]}/README.md`}); return res.end(); }
        const artifactTypes = {'.json':'application/json','.svg':'image/svg+xml','.png':'image/png','.pdf':'application/pdf','.csv':'text/csv; charset=utf-8','.md':'text/plain; charset=utf-8','.zip':'application/zip','.kicad_pcb':'text/plain','.kicad_sch':'text/plain','.kicad_pro':'application/json','.ino':'text/plain'};
        if (!relative.length || relative.some(part=>part.startsWith('.')||/[\\/\0]/.test(part))) throw new StoreError(403,'Invalid artifact path.');
        const base = await fs.realpath(path.join(repoRoot,parts[0]));
        const filename = await fs.realpath(path.join(base,...relative));
        const mime = artifactTypes[path.extname(filename)];
        if (!filename.startsWith(base+path.sep)||!mime) throw new StoreError(404,'Artifact not found.');
        const data = await fs.readFile(filename);
        res.writeHead(200,{'Content-Type':mime,'X-Content-Type-Options':'nosniff','Cache-Control':'no-cache'});
        return res.end(req.method==='HEAD'?undefined:data);
      }
      if (url.pathname === '/base') { res.writeHead(302, {Location:'/base/'}); return res.end(); }
      const isBase = parts[0] === 'base';
      const relativeParts = isBase ? parts.slice(1) : parts;
      if (!relativeParts.length) relativeParts.push('index.html');
      if (relativeParts.some(part => part.startsWith('.') || part.includes('/') || part.includes('\\') || part.includes('\0')) || ['data','versions'].includes(relativeParts[0])) throw new StoreError(403, 'Private path.');
      const assetRoot = isBase ? path.join(root, 'versions/v1') : root;
      const filename = path.resolve(assetRoot, ...relativeParts);
      const extension = path.extname(filename);
      const migrationSnapshot = !isBase && relativeParts.length === 1 && relativeParts[0] === 'previous-session.json';
      if (!filename.startsWith(assetRoot + path.sep) || (!types[extension] && !migrationSnapshot) || /(?:\.test\.mjs|server\.mjs|bom-store\.mjs|research-service\.mjs)$/.test(filename)) throw new StoreError(404, 'Asset not found.');
      const realRoot = await fs.realpath(assetRoot), realFile = await fs.realpath(filename);
      if (!realFile.startsWith(realRoot + path.sep)) throw new StoreError(403, 'Asset path is outside this application.');
      const data = await fs.readFile(realFile);
      res.writeHead(200, {'Content-Type':migrationSnapshot ? 'application/json; charset=utf-8' : types[extension],'Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'});
      res.end(req.method === 'HEAD' ? undefined : data);
    } catch (error) {
      const status = error.status || (error.code === 'ENOENT' ? 404 : error instanceof URIError ? 400 : 500);
      respond(res, status, { error:status === 500 ? 'The local server could not complete the request.' : error.message, ...(error.details ? {details:error.details} : {}) });
      if (status === 500) console.error(error);
    }
  });
  server.on('close', () => { void researchPromise.then(research => research.close?.()); });
  return server;
}

function identityOf(component) {
  return JSON.stringify([component.id,component.manufacturer,component.mpn,component.datasheet,component.sourceFile,component.sourceRef,component.sourceFingerprint,component.parameters]);
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT || 4173);
  createServer().listen(port, '127.0.0.1', () => console.log(`Beam Lab v4 is running at http://localhost:${port} · Base v1: http://localhost:${port}/base/`));
}
