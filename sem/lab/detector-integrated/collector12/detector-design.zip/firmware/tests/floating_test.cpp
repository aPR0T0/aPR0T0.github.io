#include <cassert>
#include <iostream>
#include "../FloatingCollector/FloatingCollector.ino"

void resetLocal(){ArduinoStub::reset();Serial.reset();Wire.reset();parser.reset();}
void feedRequest(uint8_t type,uint32_t id,int16_t value=0,uint8_t status=OK){
  uint8_t bytes[FRAME_SIZE];encode({type,id,value,status},bytes);
  Serial.feed(std::vector<uint8_t>(bytes,bytes+FRAME_SIZE));
}
Frame response(){Frame frame{};assert(Serial.outgoing.size()==FRAME_SIZE);assert(decode(Serial.outgoing.data(),frame));return frame;}
void testFreshSingleShot(){
  resetLocal();Wire.busy=true;Wire.readyAt=10000;
  Wire.completedValues.push_back(11);Wire.nextValue=-312;
  int16_t sample=0;
  assert(acquire(sample)==OK);
  assert(sample==-312&&Wire.starts==1&&Wire.conversionReads==1&&millis()>=18);
  assert((Wire.config&0x7fff)==0x0b83);
}
void testFaults(){
  int16_t sample=1234;
  resetLocal();Wire.stuckBusy=true;assert(acquire(sample)==ADC_TIMEOUT);
  assert(millis()==25&&Wire.starts==0&&Wire.conversionReads==0&&sample==1234);
  resetLocal();Wire.stallNew=true;assert(acquire(sample)==ADC_TIMEOUT&&Wire.conversionReads==0);
  resetLocal();Wire.failWrite=true;assert(acquire(sample)==I2C_ERROR&&Wire.conversionReads==0);
  resetLocal();Wire.shortRead=true;assert(acquire(sample)==I2C_ERROR&&Wire.conversionReads==0);
  resetLocal();Wire.timeoutRead=true;assert(acquire(sample)==I2C_ERROR&&Wire.conversionReads==0);
  resetLocal();Wire.nextValue=32767;assert(acquire(sample)==CLIPPED&&sample==32767);
  resetLocal();Wire.nextValue=-32768;assert(acquire(sample)==CLIPPED&&sample==-32768);
}
void testProtocolDispatch(){
  resetLocal();feedRequest(PING,55);loop();Frame frame=response();
  assert(frame.type==PONG&&frame.id==55&&frame.status==OK&&Wire.starts==0);
  resetLocal();Wire.nextValue=-312;feedRequest(REQUEST,77);loop();frame=response();
  assert(frame.type==REPLY&&frame.id==77&&frame.value==-312&&frame.status==OK);
  resetLocal();feedRequest(REQUEST,1,123);feedRequest(REQUEST,2,0,I2C_ERROR);feedRequest(REPLY,3);loop();
  assert(Serial.outgoing.empty()&&Wire.starts==0);
}
int main(){testFreshSingleShot();testFaults();testProtocolDispatch();std::cout<<"Floating sketch: fresh conversion, ADC bounds/timeouts, I2C failures, optical dispatch passed\n";}
