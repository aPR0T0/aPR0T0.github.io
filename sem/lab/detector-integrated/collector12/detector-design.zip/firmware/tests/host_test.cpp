#include <cassert>
#include <iostream>
#include "../ESP32_Collector_scan/ESP32_Collector_scan.ino"

void resetHost(){
  ArduinoStub::reset();Serial.reset();collectorSerial.reset();linkParser.reset();
  bias.stop();nextRequestId=0;lastLinkReplyMs=0;biasRequested=false;
  faultInputReady=hvFaultLatched=hvFaultResetting=false;
  armed=calibrated=stopRequested=zeroRequested=calibrating=false;zeroCode=0;
}
void readyBias(){bias.start(0);bias.tick(100);bias.tick(10100);applyBiasPins();}
std::vector<uint8_t> frameBytes(const CollectorLink::Frame &frame){
  uint8_t bytes[CollectorLink::FRAME_SIZE];CollectorLink::encode(frame,bytes);
  return std::vector<uint8_t>(bytes,bytes+sizeof(bytes));
}
void respondOK(){
  collectorSerial.onWrite=[](const uint8_t *data,size_t size){
    assert(size==CollectorLink::FRAME_SIZE);CollectorLink::Frame request{};
    assert(CollectorLink::decode(data,request));
    const uint8_t type=request.type==CollectorLink::PING?CollectorLink::PONG:CollectorLink::REPLY;
    collectorSerial.feed(frameBytes({type,request.id,request.type==CollectorLink::PING?int16_t(0):int16_t(-312),CollectorLink::OK}));
  };
}
void testStartupAndCommands(){
  resetHost();setup();
  assert(!bias.power&&!bias.release&&!armed&&!calibrated);
  assert(ArduinoStub::levels[PIN_HV_ENABLE]==LOW&&ArduinoStub::levels[PIN_PGM_RELEASE]==LOW);
  assert(ArduinoStub::levels[PIN_BLANK]==HIGH);
  for(const auto &write:ArduinoStub::writes)
    assert((write.first!=PIN_HV_ENABLE&&write.first!=PIN_PGM_RELEASE)||write.second==LOW);
  Serial.command('s');readCommands();assert(!armed);
  Serial.command('z');readCommands();assert(!zeroRequested);
  respondOK();Serial.command('b');loop();
  assert(bias.ready()&&!armed&&!calibrated&&ArduinoStub::levels[PIN_BLANK]==HIGH);
  assert(ArduinoStub::levels[PIN_HV_ENABLE]==HIGH&&ArduinoStub::levels[PIN_PGM_RELEASE]==HIGH);
  Serial.command('z');loop();assert(calibrated&&!armed&&zeroCode==-312);
  Serial.command('s');readCommands();assert(armed);
  Serial.command('x');Serial.command('s');readCommands();
  assert(!bias.power&&!bias.release&&!armed&&!calibrated&&ArduinoStub::levels[PIN_BLANK]==HIGH);
}
void testResponseFilteringAndFaults(){
  resetHost();readyBias();int16_t result=0;
  collectorSerial.onWrite=[](const uint8_t *data,size_t){
    CollectorLink::Frame request{};assert(CollectorLink::decode(data,request));
    collectorSerial.feed(frameBytes({CollectorLink::REPLY,request.id-1,99,CollectorLink::OK}));
    collectorSerial.feed(frameBytes({CollectorLink::PONG,request.id,88,CollectorLink::OK}));
    auto corrupt=frameBytes({CollectorLink::REPLY,request.id,77,CollectorLink::OK});corrupt[9]^=1;
    collectorSerial.feed(corrupt);
    collectorSerial.feed(frameBytes({CollectorLink::REPLY,request.id,-456,CollectorLink::OK}));
  };
  assert(readFreshAdc(result)&&result==-456&&bias.power);
  resetHost();readyBias();
  collectorSerial.onWrite=[](const uint8_t *data,size_t){
    CollectorLink::Frame request{};assert(CollectorLink::decode(data,request));
    collectorSerial.feed(frameBytes({CollectorLink::REPLY,request.id,0,CollectorLink::ADC_TIMEOUT}));
  };
  assert(!readFreshAdc(result)&&!bias.power&&!bias.release);
  assert(ArduinoStub::levels[PIN_BLANK]==HIGH&&stopRequested);
}
void testTimeoutAndAbort(){
  resetHost();readyBias();int16_t result=0;
  const uint32_t start=millis();assert(!readFreshAdc(result));
  assert(uint32_t(millis()-start)>=100&&uint32_t(millis()-start)<=101);
  assert(!bias.power&&!bias.release&&!armed&&ArduinoStub::levels[PIN_BLANK]==HIGH);
  resetHost();readyBias();
  ArduinoStub::timeHook=[](){if(millis()==10)Serial.command('x');};
  assert(!readFreshAdc(result));
  assert(millis()<=11&&!bias.power&&!bias.release&&ArduinoStub::levels[PIN_BLANK]==HIGH);
  // Unsigned timeout must work across the 32-bit millisecond rollover.
  resetHost();readyBias();ArduinoStub::nowUs=uint64_t(UINT32_MAX-40)*1000;
  const uint32_t wrappedStart=millis();assert(!readFreshAdc(result));
  assert(uint32_t(millis()-wrappedStart)==100&&!bias.power);
}
void testIdleOpticalLossRemovesBias(){
  resetHost();readyBias();calibrated=true;ArduinoStub::nowUs=4000000;
  loop();
  assert(!bias.power&&!bias.release&&!calibrated&&ArduinoStub::levels[PIN_BLANK]==HIGH);
}
void testIdleCadenceAndStatus(){
  resetHost();readyBias();ArduinoStub::nowUs=4000000;respondOK();
  loop();assert(bias.ready()&&collectorSerial.outgoing.size()==CollectorLink::FRAME_SIZE);
  const uint32_t replied=lastLinkReplyMs;
  loop();assert(collectorSerial.outgoing.size()==CollectorLink::FRAME_SIZE);
  ArduinoStub::nowUs=uint64_t(replied+500)*1000;
  loop();assert(bias.ready()&&collectorSerial.outgoing.size()==2*CollectorLink::FRAME_SIZE);
  // A CRC-valid PONG with fault status must invalidate a previously acquired zero.
  calibrated=true;
  collectorSerial.onWrite=[](const uint8_t *data,size_t){
    CollectorLink::Frame request{};assert(CollectorLink::decode(data,request));
    collectorSerial.feed(frameBytes({CollectorLink::PONG,request.id,0,CollectorLink::I2C_ERROR}));
  };
  ArduinoStub::nowUs+=500000;loop();assert(!bias.power&&!bias.release&&!calibrated);
  // Samples own the UART exchange; no idle PING is inserted midway through one.
  resetHost();readyBias();ArduinoStub::nowUs=4000000;
  collectorSerial.onWrite=[](const uint8_t *data,size_t){
    CollectorLink::Frame request{};assert(CollectorLink::decode(data,request));
    assert(request.type==CollectorLink::REQUEST);
    ArduinoStub::timeHook=[request](){
      if(millis()>=4050){collectorSerial.feed(frameBytes({CollectorLink::REPLY,request.id,42,CollectorLink::OK}));ArduinoStub::timeHook=nullptr;}
    };
  };
  int16_t sample=0;assert(readFreshAdc(sample)&&sample==42);
  assert(collectorSerial.outgoing.size()==CollectorLink::FRAME_SIZE&&lastLinkReplyMs==4050);
}
void testDisableClampsBeforeRemovingPower(){
  resetHost();readyBias();calibrated=true;ArduinoStub::writes.clear();
  biasOff();
  assert(ArduinoStub::writes.size()==2);
  assert(ArduinoStub::writes[0]==std::make_pair(PIN_PGM_RELEASE,LOW));
  assert(ArduinoStub::writes[1]==std::make_pair(PIN_HV_ENABLE,LOW));
  assert(!calibrated&&!bias.power&&!bias.release);
}
void testHardwareFaultBlanksAndInvalidatesZero(){
  resetHost();setup();readyBias();calibrated=true;
  ArduinoStub::levels[34]=LOW;loop();
  assert(!bias.power&&!bias.release&&!calibrated&&!armed&&ArduinoStub::levels[PIN_BLANK]==HIGH);
  assert(Serial.messages.find("HV power fault latched")!=std::string::npos);
  assert(hvFaultLatched&&ArduinoStub::modes[PIN_HV_FAULT_N]==INPUT);
  const auto size=Serial.messages.size();loop();assert(Serial.messages.size()==size);
}
void testHardwareFaultStartupAndActiveWait(){
  resetHost();ArduinoStub::levels[34]=LOW;setup();
  assert(hvFaultLatched&&!bias.power&&ArduinoStub::modes[34]==INPUT);
  resetHost();setup();readyBias();calibrated=true;armed=true;
  const uint32_t start=millis();
  ArduinoStub::timeHook=[start](){if(uint32_t(millis()-start)>=5)ArduinoStub::levels[34]=LOW;};
  assert(!waitResponsive(20000));
  assert(hvFaultLatched&&!bias.power&&!bias.release&&!calibrated&&!armed);
  assert(uint32_t(millis()-start)<=6&&ArduinoStub::levels[PIN_BLANK]==HIGH);
}
void testExplicitFaultResetGraceAndNoAutomaticRetry(){
  resetHost();ArduinoStub::levels[34]=LOW;setup();
  Serial.command('b');loop();
  assert(hvFaultLatched&&!bias.power&&Serial.messages.find("remains after 20ms")!=std::string::npos);
  // Fault release alone must never retry or enable the module.
  ArduinoStub::levels[34]=HIGH;loop();assert(hvFaultLatched&&!bias.power);
  // Explicit b allows the fault output its deassertion time while EN is low.
  ArduinoStub::levels[34]=LOW;const uint32_t started=millis();
  ArduinoStub::timeHook=[started](){if(uint32_t(millis()-started)>=10)ArduinoStub::levels[34]=HIGH;};
  respondOK();Serial.command('b');loop();
  assert(uint32_t(millis()-started)>=10120&&bias.ready()&&!hvFaultLatched&&!calibrated&&!armed);
  Serial.command('s');readCommands();assert(!armed);
}
void testStartupLinkLossDoesNotWaitForLongSettlePolicy(){
  resetHost();setup();unsigned requests=0;const uint32_t started=millis();
  collectorSerial.onWrite=[&requests](const uint8_t *data,size_t){
    CollectorLink::Frame request{};assert(CollectorLink::decode(data,request));
    if(++requests==1)collectorSerial.feed(frameBytes({CollectorLink::PONG,request.id,0,CollectorLink::OK}));
  };
  Serial.command('b');loop();
  assert(!bias.power&&!bias.release&&!calibrated&&!armed);
  assert(uint32_t(millis()-started)<=650);
}
int main(){
  testStartupAndCommands();testResponseFilteringAndFaults();testTimeoutAndAbort();
  testIdleOpticalLossRemovesBias();testIdleCadenceAndStatus();testDisableClampsBeforeRemovingPower();
  testHardwareFaultBlanksAndInvalidatesZero();
  testHardwareFaultStartupAndActiveWait();testExplicitFaultResetGraceAndNoAutomaticRetry();
  testStartupLinkLossDoesNotWaitForLongSettlePolicy();
  std::cout<<"Host sketch: startup, zero gate, stale/corrupt reply rejection, fault, abort, rollover and idle link loss passed\n";
}
