#include "../CollectorLink.h"
#include <cassert>
#include <cstdint>
#include <vector>
using namespace CollectorLink;
int main() {
  Frame source{REPLY,0xf0123456u,-312,OK}, decoded{};
  uint8_t bytes[FRAME_SIZE]; encode(source,bytes);
  assert(decode(bytes,decoded));
  assert(decoded.type==REPLY && decoded.id==source.id && decoded.value==-312 && decoded.status==OK);
  for(size_t i=0;i<FRAME_SIZE;i++)for(int bit=0;bit<8;bit++){
    bytes[i]^=uint8_t(1u<<bit); assert(!decode(bytes,decoded)); bytes[i]^=uint8_t(1u<<bit);
  }
  Parser parser;
  for(uint8_t b:{0,1,0xa5,0xa5,3}) assert(!parser.push(b,decoded));
  for(size_t i=0;i<FRAME_SIZE;i++)assert(parser.push(bytes[i],decoded)==(i==FRAME_SIZE-1));
  assert(matches(decoded,REPLY,source.id));
  assert(!matches(decoded,REPLY,source.id+1));
  assert(!matches(decoded,PONG,source.id));
  source.status=ADC_TIMEOUT; encode(source,bytes); assert(decode(bytes,decoded));
  assert(!matches(decoded,REPLY,source.id));
  // CRC-correct frames from unsupported protocol versions/types are rejected.
  bytes[2]=2; uint16_t c=crc16(bytes,12); bytes[12]=uint8_t(c);bytes[13]=uint8_t(c>>8);
  assert(!decode(bytes,decoded));
  BiasSequence bias; assert(!bias.power && !bias.release && !bias.ready());
  bias.start(1000); assert(bias.power && !bias.release);
  bias.tick(1099); assert(!bias.release); bias.tick(1100);assert(bias.release&&!bias.ready());
  bias.tick(11099); assert(!bias.ready());bias.tick(11100);assert(bias.ready());
  bias.stop(); assert(!bias.power&&!bias.release&&!bias.ready());
  // Millisecond rollover must not skip the mandatory supply startup delay.
  bias.start(UINT32_MAX-20);bias.tick(30);assert(!bias.release);bias.tick(80);assert(bias.release);
}
