#pragma once
// Host-only API stubs. These do not model target timing, electrical levels,
// buffering, interrupt latency, fuse selection, or an Arduino board package.
#include <stdint.h>
#include <stddef.h>
#include <deque>
#include <functional>
#include <map>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

constexpr uint8_t LOW=0, HIGH=1, INPUT=0, OUTPUT=1;
constexpr uint32_t SERIAL_8N1=0;
namespace ArduinoStub {
static uint64_t nowUs=0;
static std::map<uint8_t,uint8_t> levels;
static std::map<uint8_t,uint8_t> modes;
static std::vector<std::pair<uint8_t,uint8_t> > writes;
static std::function<void()> timeHook;
inline void advance(uint64_t microseconds) {
  nowUs+=microseconds;
  if(timeHook)timeHook();
}
inline void reset() { nowUs=0;levels.clear();modes.clear();writes.clear();timeHook=nullptr; }
}
inline uint32_t millis(){return uint32_t(ArduinoStub::nowUs/1000);}
inline uint32_t micros(){return uint32_t(ArduinoStub::nowUs);}
inline void delay(uint32_t milliseconds){ArduinoStub::advance(uint64_t(milliseconds)*1000);}
inline void delayMicroseconds(uint32_t microseconds){ArduinoStub::advance(microseconds);}
inline void yield(){}
inline void digitalWrite(uint8_t pin,uint8_t value){ArduinoStub::levels[pin]=value;ArduinoStub::writes.push_back({pin,value});}
inline void pinMode(uint8_t pin,uint8_t mode){ArduinoStub::modes[pin]=mode;}
inline int digitalRead(uint8_t pin){const auto item=ArduinoStub::levels.find(pin);return item==ArduinoStub::levels.end()?HIGH:item->second;}
template<class T> inline T constrain(T value,T low,T high){return value<low?low:value>high?high:value;}

class HardwareSerial {
public:
  std::deque<uint8_t> incoming;
  std::vector<uint8_t> outgoing;
  std::string messages;
  std::function<void(const uint8_t*,size_t)> onWrite;
  explicit HardwareSerial(int=0){}
  void begin(uint32_t){}
  void begin(uint32_t,uint32_t,uint8_t,uint8_t){}
  int available(){return int(incoming.size());}
  int read(){if(incoming.empty())return -1;const uint8_t b=incoming.front();incoming.pop_front();return b;}
  size_t write(const uint8_t *bytes,size_t size){outgoing.insert(outgoing.end(),bytes,bytes+size);if(onWrite)onWrite(bytes,size);return size;}
  template<class T> void print(const T &value){std::ostringstream out;out<<value;messages+=out.str();}
  template<class T> void println(const T &value){print(value);messages+='\n';}
  void println(float value,int){println(value);}
  void flush(){}
  void feed(const std::vector<uint8_t> &bytes){incoming.insert(incoming.end(),bytes.begin(),bytes.end());}
  void command(char value){incoming.push_back(uint8_t(value));}
  void reset(){incoming.clear();outgoing.clear();messages.clear();onWrite=nullptr;}
};
static HardwareSerial Serial;
