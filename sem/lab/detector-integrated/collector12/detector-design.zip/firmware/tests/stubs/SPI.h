#pragma once
#include <Arduino.h>
constexpr uint8_t VSPI=0,MSBFIRST=1,SPI_MODE1=1;
class SPISettings {public:SPISettings(uint32_t,uint8_t,uint8_t){}};
class SPIClass {
public:
  explicit SPIClass(uint8_t){}
  void begin(uint8_t,int,uint8_t,uint8_t){}
  void beginTransaction(const SPISettings&){}
  uint8_t transfer(uint8_t value){return value;}
  void endTransaction(){}
};
