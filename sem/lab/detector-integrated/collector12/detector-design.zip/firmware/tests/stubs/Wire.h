#pragma once
#include <Arduino.h>
// Minimal single-shot ADS1115 model: a start written while BUSY is ignored;
// the old conversion must finish before a new request can launch. Tests use
// this to distinguish the requested result from an interrupted old result.
class TwoWire {
  std::vector<uint8_t> tx;
  std::deque<uint8_t> rx;
  uint8_t pointer=1;
  bool timeout=false;
public:
  uint16_t config=0x8583,conversion=0;
  int16_t nextValue=123;
  std::deque<int16_t> completedValues;
  bool busy=false,stuckBusy=false,stallNew=false;
  bool failWrite=false,shortRead=false,timeoutRead=false;
  uint64_t readyAt=0;
  unsigned starts=0,conversionReads=0;
  void reset(){*this=TwoWire();}
  void begin(){}
  void setClock(uint32_t){}
  void setWireTimeout(uint32_t,bool){}
  void clearWireTimeoutFlag(){timeout=false;}
  bool getWireTimeoutFlag(){return timeout;}
  void beginTransmission(uint8_t){tx.clear();}
  size_t write(uint8_t byte){tx.push_back(byte);return 1;}
  void finishIfReady(){
    if(busy&&!stuckBusy&&ArduinoStub::nowUs>=readyAt){
      busy=false;
      conversion=uint16_t(completedValues.empty()?nextValue:completedValues.front());
      if(!completedValues.empty())completedValues.pop_front();
    }
  }
  uint8_t endTransmission(bool=true){
    if(failWrite)return 2;
    if(tx.empty())return 0;
    pointer=tx[0];
    if(tx.size()==3&&pointer==1){
      finishIfReady();
      config=(uint16_t(tx[1])<<8)|tx[2];
      if((config&0x8000)&&!busy){++starts;busy=true;stuckBusy=stallNew;readyAt=ArduinoStub::nowUs+8000;}
    }
    return 0;
  }
  uint8_t requestFrom(uint8_t,uint8_t){
    finishIfReady();rx.clear();
    if(timeoutRead){timeout=true;return 0;}
    uint16_t value=pointer==1?uint16_t((config&0x7fff)|(busy||stuckBusy?0:0x8000)):conversion;
    if(pointer==0)++conversionReads;
    rx.push_back(uint8_t(value>>8));if(!shortRead)rx.push_back(uint8_t(value));
    return uint8_t(rx.size());
  }
  int read(){if(rx.empty())return -1;const uint8_t b=rx.front();rx.pop_front();return b;}
};
static TwoWire Wire;
