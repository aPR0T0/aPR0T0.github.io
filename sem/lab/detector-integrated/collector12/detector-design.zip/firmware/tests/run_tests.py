#!/usr/bin/env python3
"""Portable C++ checks of the shared protocol and actual .ino source.

These are host compiler / stub API tests, not Arduino target builds. No AVR
or ESP32 Arduino core, target linker, fuse/bootloader setup or hardware is
exercised. Binaries are built in a temporary directory and removed on exit.
"""
from pathlib import Path
import shutil
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent


def main():
    compiler = shutil.which('g++')
    if not compiler:
        raise SystemExit('g++ is required for portable firmware checks')
    targets = [
        ('protocol', 'link_test.cpp', 'c++11', []),
        ('floating', 'floating_test.cpp', 'c++11', ['-D__AVR_ATmega328P__', '-DF_CPU=8000000UL']),
        ('host', 'host_test.cpp', 'c++17', ['-DCONFIG_IDF_TARGET_ESP32']),
    ]
    with tempfile.TemporaryDirectory(prefix='collector-firmware-tests-') as folder:
        for name, source, standard, flags in targets:
            binary = str(Path(folder) / name)
            subprocess.run([compiler, f'-std={standard}', '-Wall', '-Wextra', '-Wpedantic', '-Werror',
                            '-I', str(HERE / 'stubs'), '-I', str(HERE.parent), *flags,
                            str(HERE / source), '-o', binary], check=True)
            subprocess.run([binary], check=True)
            print(f'{name}: portable compile and execution passed', flush=True)
    print('Arduino target compilation and hardware tests have NOT been performed.')


if __name__ == '__main__':
    main()
