#!/usr/bin/env python3
"""Configurable two-layer router with explicit copper-domain boundaries.

Adapted from the verified detector router. Domain definitions are a routing
constraint, not a manufacturer insulation rating. Run independent checks and
KiCad DRC before packaging any result.
"""

import argparse
from array import array
from collections import defaultdict
import heapq
import itertools
import json
import math
from pathlib import Path
import time

import pcbnew
from primitives import save_board_preserving_project

BOARD_SIZE = (88, 60)
PROJECT = 'integrated_detector'
ROOT = Path('.')
FILE = ROOT / 'kicad' / (PROJECT + '.kicad_pcb')
SPEC = {}
GRID = .10
NX = 881
NY = 601
N = NX * NY
CLEARANCE = .18
MARGIN = .025
VIA_DIAMETER = .6
VIA_DRILL = .3
WIDTHS = (.18, .25, .35, .5)
POWER = set()
WIDTH = {}
GROUND_NETS = {'AGND', 'PGND'}
LAYERS = (pcbnew.F_Cu, pcbnew.B_Cu)


def configure(spec, root):
    """Configure one routing job per process; a fresh Router owns its masks."""
    global BOARD_SIZE, PROJECT, ROOT, FILE, SPEC, GRID, NX, NY, N
    global CLEARANCE, MARGIN, VIA_DIAMETER, VIA_DRILL, WIDTHS, WIDTH, POWER, GROUND_NETS
    SPEC = spec
    routing = spec.get('routing', {})
    BOARD_SIZE = spec['board_mm']
    PROJECT = spec.get('project', 'integrated_detector')
    ROOT = Path(root).resolve()
    FILE = ROOT / 'kicad' / (PROJECT + '.kicad_pcb')
    GRID = routing.get('grid_mm', .10)
    NX, NY = round(BOARD_SIZE[0] / GRID) + 1, round(BOARD_SIZE[1] / GRID) + 1
    N = NX * NY
    CLEARANCE = spec.get('rules', {}).get('min_clearance', .18)
    MARGIN = routing.get('margin_mm', .025)
    VIA_DIAMETER = routing.get('via_diameter_mm', .6)
    VIA_DRILL = routing.get('via_drill_mm', .3)
    WIDTH = routing.get('widths', {})
    widths = {routing.get('default_width_mm', .18), *WIDTH.values()}
    for net, clearance in routing.get('net_clearances', {}).items():
        extra = 2*max(0, clearance-CLEARANCE)
        widths.add(WIDTH.get(net, routing.get('default_width_mm', .18))+extra)
        widths.add(VIA_DIAMETER+extra)
    WIDTHS = tuple(sorted(widths))
    POWER = set(routing.get('power_nets', []))
    GROUND_NETS = set(routing.get('ground_nets', ['AGND', 'PGND']))


def point_segment_distance(x, y, a, b):
    dx, dy = b[0]-a[0], b[1]-a[1]
    length2 = dx*dx + dy*dy
    t = max(0., min(1., ((x-a[0])*dx + (y-a[1])*dy)/length2)) if length2 else 0.
    return math.hypot(x-a[0]-t*dx, y-a[1]-t*dy)


def polygon_contains(points, x, y, margin=0):
    """Closed polygon containment with conservative copper-radius setback."""
    inside = False
    edge_distance = float('inf')
    for a, b in zip(points, points[1:] + points[:1]):
        edge_distance = min(edge_distance, point_segment_distance(x, y, a, b))
        if (a[1] > y) != (b[1] > y):
            cut = a[0] + (y-a[1])*(b[0]-a[0])/(b[1]-a[1])
            if x < cut:
                inside = not inside
    return (inside or edge_distance < 1e-8) and edge_distance + 1e-8 >= margin


def shape_contains(shape, x, y, margin=0):
    if 'rect' in shape:
        a, b, c, d = shape['rect']
        return a+margin-1e-8 <= x <= c-margin+1e-8 and b+margin-1e-8 <= y <= d-margin+1e-8
    return polygon_contains(shape['polygon'], x, y, margin)


class RoutingRegions:
    """Explicit net domains; component crossings never grant copper shortcuts."""
    def __init__(self, spec):
        self.spec = spec
        self.routing = spec.get('routing', {})
        self.domains = self.routing.get('domains', {})
        self.net_domain = {}
        for name, definition in self.domains.items():
            for net in definition['nets']:
                if net in self.net_domain:
                    raise ValueError('Net assigned to two routing domains: ' + net)
                self.net_domain[net] = name
        width, height = spec['board_mm']
        self.outline = {'polygon': spec['outline']} if 'outline' in spec else {'rect': [0, 0, width, height]}

    def domain(self, net):
        if net not in self.net_domain and self.routing.get('require_domains', bool(self.domains)) and not net.startswith('unconnected-'):
            raise ValueError('Unassigned routing domain: ' + net)
        return self.net_domain.get(net)

    def contains(self, net, x, y, radius=0):
        if not shape_contains(self.outline, x, y, radius):
            return False
        domain = self.domain(net)
        if domain is not None:
            definition = self.domains[domain]
            regions = definition.get('regions', [definition])
            if not any(shape_contains(region, x, y, radius) for region in regions):
                return False
        for shape in self.routing.get('keepouts', []):
            if net in shape.get('exempt_nets', []):
                continue
            # A circle touching the keepout boundary is conservatively denied.
            if 'rect' in shape:
                if shape_contains(shape, x, y, -radius):
                    return False
            else:
                points = shape['polygon']
                if polygon_contains(points, x, y) or any(point_segment_distance(x, y, a, b) < radius for a, b in zip(points, points[1:]+points[:1])):
                    return False
        return True


def vec(x, y):
    return pcbnew.VECTOR2I(pcbnew.FromMM(x), pcbnew.FromMM(y))


def mm(v):
    return pcbnew.ToMM(v)


def bounds(box):
    return mm(box.GetX()), mm(box.GetY()), mm(box.GetRight()), mm(box.GetBottom())


def overlaps(a, b, pad=0):
    return not (a[2]+pad < b[0] or b[2]+pad < a[0] or a[3]+pad < b[1] or b[3]+pad < a[1])


class Router:
    def __init__(self, board):
        self.board = board
        self.net_codes = {item.GetNetname(): code for code, item in board.GetNetsByNetcode().items() if code}
        self.hard_bit = 1 << (max(self.net_codes.values(), default=0) + 1)
        self.all_bits = (self.hard_bit << 1) - 1
        self.regions = RoutingRegions(SPEC)
        for net in self.net_codes:
            self.regions.domain(net)
        self.masks = {w: [self.empty_mask(), self.empty_mask()] for w in WIDTHS}
        self.via_masks = [self.empty_mask(), self.empty_mask()]
        self.via_pad_forbid = bytearray(N)
        self.via_hole_forbid = bytearray(N)
        self.via_positions = {}
        self.pads = defaultdict(list)
        self.report = {}
        self.steps = [(1, 0, 10), (-1, 0, 10), (0, 1, 10), (0, -1, 10),
                      (1, 1, 14), (1, -1, 14), (-1, 1, 14), (-1, -1, 14)]
        self.draw_initial_obstacles()
        self.seed_obstacles()

    def empty_mask(self):
        # Native 64-bit arrays for ordinary designs; arbitrary-precision masks
        # preserve every net bit when designs exceed 62 nets.
        return array('Q', [0]) * N if self.hard_bit < (1 << 64) else [0] * N

    def foreign_bits(self, net):
        return self.all_bits ^ (1 << self.net_codes[net])

    def width(self, net):
        return WIDTH.get(net, SPEC.get('routing', {}).get('default_width_mm', .18))

    def clearance(self, net):
        return SPEC.get('routing', {}).get('net_clearances', {}).get(net, CLEARANCE)

    def mask_width(self, net):
        return self.width(net)+2*max(0, self.clearance(net)-CLEARANCE)

    def via_clear(self, net, index):
        foreign = self.foreign_bits(net)
        if (self.via_masks[0][index] | self.via_masks[1][index]) & foreign:
            return False
        if self.clearance(net) > CLEARANCE:
            width = VIA_DIAMETER+2*(self.clearance(net)-CLEARANCE)
            if (self.masks[width][0][index] | self.masks[width][1][index]) & foreign:
                return False
        return True

    def seed_obstacles(self):
        # Honor hand-routed summing node and grounded guards on both faces.
        for t in self.board.GetTracks():
            code=t.GetNetCode();bit=1<<code; clearance=self.clearance(t.GetNetname())
            if isinstance(t,pcbnew.PCB_VIA):
                x,y=mm(t.GetPosition().x),mm(t.GetPosition().y)
                radius=mm(t.GetWidth(pcbnew.F_Cu))/2
                for w,masks in self.masks.items():
                    ix=self.raster_capsule(x,y,x,y,radius+clearance+w/2+MARGIN)
                    for mask in masks:self.mark(mask,ix,bit)
                ix=self.raster_capsule(x,y,x,y,radius+clearance+VIA_DIAMETER/2+MARGIN)
                for mask in self.via_masks:self.mark(mask,ix,bit)
                self.via_positions[round(y/GRID)*NX+round(x/GRID)]=t.GetNetname()
            else:
                a,b=t.GetStart(),t.GetEnd();coords=(mm(a.x),mm(a.y),mm(b.x),mm(b.y));radius=mm(t.GetWidth())/2;layer=LAYERS.index(t.GetLayer())
                for w,masks in self.masks.items():self.mark(masks[layer],self.raster_capsule(*coords,radius+clearance+w/2+MARGIN),bit)
                self.mark(self.via_masks[layer],self.raster_capsule(*coords,radius+clearance+VIA_DIAMETER/2+MARGIN),bit)
        for net in SPEC.get('routing', {}).get('pre_routed_nets', []):
            self.pads.pop(net, None)
        for anchor in SPEC.get('routing', {}).get('anchors', []):
            x, y = anchor['at']
            layers = [0 if layer == 'F.Cu' else 1 for layer in anchor.get('layers', ['F.Cu', 'B.Cu'])]
            self.pads[anchor['net']].append({'xy': (round(x/GRID), round(y/GRID)), 'real': (x, y), 'layers': layers, 'pin': 'Anchor.1'})

    @staticmethod
    def raster_rect(x1, y1, x2, y2, inflate):
        lo_x = max(0, math.ceil((x1-inflate)/GRID))
        hi_x = min(NX-1, math.floor((x2+inflate)/GRID))
        lo_y = max(0, math.ceil((y1-inflate)/GRID))
        hi_y = min(NY-1, math.floor((y2+inflate)/GRID))
        # Rectangular expansion deliberately overestimates rounded corners.
        return [y*NX+x for y in range(lo_y, hi_y+1) for x in range(lo_x, hi_x+1)]

    @staticmethod
    def raster_capsule(x1, y1, x2, y2, radius):
        lo_x = max(0, math.floor((min(x1, x2)-radius)/GRID))
        hi_x = min(NX-1, math.ceil((max(x1, x2)+radius)/GRID))
        lo_y = max(0, math.floor((min(y1, y2)-radius)/GRID))
        hi_y = min(NY-1, math.ceil((max(y1, y2)+radius)/GRID))
        dx, dy = x2-x1, y2-y1
        l2 = dx*dx + dy*dy
        r2 = radius*radius
        out = []
        for y in range(lo_y, hi_y+1):
            yy = y*GRID
            for x in range(lo_x, hi_x+1):
                xx = x*GRID
                t = max(0., min(1., ((xx-x1)*dx + (yy-y1)*dy)/l2)) if l2 else 0.
                if (xx-x1-t*dx)**2 + (yy-y1-t*dy)**2 <= r2:
                    out.append(y*NX+x)
        return out

    @staticmethod
    def mark(mask, indices, value):
        for i in indices:
            mask[i] |= value

    def draw_initial_obstacles(self):
        for width, masks in self.masks.items():
            inset = .5 + width/2 + MARGIN
            for masks1 in masks:
                for y in range(NY):
                    for x in range(NX):
                        if min(x*GRID, y*GRID, BOARD_SIZE[0]-x*GRID, BOARD_SIZE[1]-y*GRID) < inset:
                            masks1[y*NX+x] |= self.hard_bit
        for footprint in self.board.GetFootprints():
            for pad in footprint.Pads():
                net = pad.GetNetname()
                clearance = self.clearance(net)
                code = pad.GetNetCode()
                bit = (1 << code) if code else self.hard_bit
                box = bounds(pad.GetBoundingBox())
                pad_layers = [i for i, layer in enumerate(LAYERS) if pad.IsOnLayer(layer)]
                if pad.GetAttribute() == pcbnew.PAD_ATTRIB_NPTH:
                    cx, cy = mm(pad.GetPosition().x), mm(pad.GetPosition().y)
                    # M3 washer keepout: 3.2 mm radius, not just the 1.6 mm hole.
                    radius = SPEC.get('routing', {}).get('mounting_keepout_radius_mm', 3.2)
                    box = (cx-radius, cy-radius, cx+radius, cy+radius)
                    bit, pad_layers = self.hard_bit, [0, 1]
                for width, masks in self.masks.items():
                    indices = self.raster_rect(*box, clearance+width/2+MARGIN)
                    for layer in pad_layers:
                        self.mark(masks[layer], indices, bit)
                indices = self.raster_rect(*box, clearance+VIA_DIAMETER/2+MARGIN)
                for layer in pad_layers:
                    self.mark(self.via_masks[layer], indices, bit)
                # Never make via-in-pad, including on the same net.
                for i in self.raster_rect(*box, VIA_DIAMETER/2+.15):
                    self.via_pad_forbid[i] = 1
                if net and not net.startswith("unconnected-"):
                    self.net_codes[net] = code
                    pos = pad.GetPosition()
                    x, y = round(mm(pos.x)/GRID), round(mm(pos.y)/GRID)
                    self.pads[net].append({"xy": (x, y), "real": (mm(pos.x), mm(pos.y)),
                                           "layers": pad_layers, "pin": footprint.GetReference()+"."+pad.GetNumber()})
        # Avoid drilling through fixed functional legends. References will be
        # placed anew after routing, so they do not constrain the copper.
        for item in self.board.GetDrawings():
            if isinstance(item, pcbnew.PCB_TEXT) and item.GetLayer() == pcbnew.F_SilkS:
                for i in self.raster_rect(*bounds(item.GetBoundingBox()), .65):
                    self.via_pad_forbid[i] = 1

    def add_segment(self, net, a, b, layer, width):
        if math.dist(a, b) < 1e-7:
            return
        t = pcbnew.PCB_TRACK(self.board)
        t.SetStart(vec(*a))
        t.SetEnd(vec(*b))
        t.SetWidth(pcbnew.FromMM(width))
        t.SetLayer(LAYERS[layer])
        t.SetNetCode(self.net_codes[net])
        self.board.Add(t)
        bit = 1 << self.net_codes[net]
        for req_width, masks in self.masks.items():
            indices = self.raster_capsule(*a, *b, width/2+self.clearance(net)+req_width/2+MARGIN)
            self.mark(masks[layer], indices, bit)
        indices = self.raster_capsule(*a, *b, width/2+self.clearance(net)+VIA_DIAMETER/2+MARGIN)
        self.mark(self.via_masks[layer], indices, bit)
        self.report[net]["length_mm"] += math.dist(a, b)
        self.report[net]["segments"] += 1

    def add_via(self, net, x, y):
        i = y*NX+x
        if i in self.via_positions:
            assert self.via_positions[i] == net
            return
        v = pcbnew.PCB_VIA(self.board)
        v.SetPosition(vec(x*GRID, y*GRID))
        v.SetWidth(pcbnew.FromMM(VIA_DIAMETER))
        v.SetDrill(pcbnew.FromMM(VIA_DRILL))
        v.SetViaType(pcbnew.VIATYPE_THROUGH)
        v.SetLayerPair(pcbnew.F_Cu, pcbnew.B_Cu)
        v.SetNetCode(self.net_codes[net])
        self.board.Add(v)
        bit = 1 << self.net_codes[net]
        for req_width, masks in self.masks.items():
            indices = self.raster_capsule(x*GRID, y*GRID, x*GRID, y*GRID, VIA_DIAMETER/2+self.clearance(net)+req_width/2+MARGIN)
            for mask in masks:
                self.mark(mask, indices, bit)
        indices = self.raster_capsule(x*GRID, y*GRID, x*GRID, y*GRID, VIA_DIAMETER+self.clearance(net)+MARGIN)
        for mask in self.via_masks:
            self.mark(mask, indices, bit)
        for p in self.raster_capsule(x*GRID, y*GRID, x*GRID, y*GRID, VIA_DRILL+.25+MARGIN):
            self.via_hole_forbid[p] = 1
        self.via_positions[i] = net
        self.report[net]["vias"] += 1

    def search(self, net, start, goal):
        width = self.width(net)
        masks = self.masks[self.mask_width(net)]
        foreign = self.foreign_bits(net)
        gx, gy = goal["xy"]
        sx, sy = start["xy"]
        lo_x, hi_x = (5, NX-6)
        goals = {layer*N + gy*NX+gx for layer in goal["layers"]}
        valid_goals={state for state in goals if not (masks[state//N][state%N] & foreign)
            and self.regions.contains(net,gx*GRID,gy*GRID,width/2)}
        if not valid_goals:
            blocking=0
            for layer in goal['layers']:blocking |= masks[layer][gy*NX+gx] & foreign
            names=[name for name,code in self.net_codes.items() if blocking & (1<<code)]
            raise RuntimeError(f'Target {goal["pin"]} for {net} is blocked by clearance/domain constraints: {names}')
        goals=valid_goals
        via0, via1 = self.via_masks
        seq = itertools.count()
        best, parent, heap = {}, {}, []

        def h(x, y):
            dx, dy = abs(x-gx), abs(y-gy)
            return 10*max(dx, dy)+4*min(dx, dy)

        for layer in start["layers"]:
            i = sy*NX+sx
            if masks[layer][i] & foreign or not self.regions.contains(net, sx*GRID, sy*GRID, width/2):
                continue
            state = layer*N+i
            best[state] = 0
            heapq.heappush(heap, (h(sx, sy), next(seq), 0, state))
        visited = 0
        while heap:
            _, _, cost, state = heapq.heappop(heap)
            if best.get(state) != cost:
                continue
            if state in goals:
                path = [state]
                while state in parent:
                    state = parent[state]
                    path.append(state)
                path.reverse()
                return [(s//N, (s % N) % NX, (s % N)//NX) for s in path], visited
            layer, index = divmod(state, N)
            y, x = divmod(index, NX)
            mask = masks[layer]
            visited += 1
            for dx, dy, dcost in self.steps:
                xx, yy = x+dx, y+dy
                if not lo_x <= xx <= hi_x or not 4 <= yy < NY-4:
                    continue
                i2 = yy*NX+xx
                if mask[i2] & foreign or not self.regions.contains(net, xx*GRID, yy*GRID, width/2):
                    continue
                # Do not cut a diagonal across the corner of an obstacle.
                if dx and dy and ((mask[y*NX+xx] & foreign) or (mask[yy*NX+x] & foreign)):
                    continue
                nxt = layer*N+i2
                # Prefer the front for signal copper, leaving more back-plane
                # continuity. Ground trees prefer the back copper.
                penalty = (1 if layer else 0) if net not in GROUND_NETS else (0 if layer else 1)
                nc = cost+dcost+penalty
                if nc < best.get(nxt, 1e15):
                    best[nxt] = nc
                    parent[nxt] = state
                    heapq.heappush(heap, (nc+h(xx, yy), next(seq), nc, nxt))
            reuse = self.via_positions.get(index) == net
            if self.regions.contains(net, x*GRID, y*GRID, VIA_DIAMETER/2) and (reuse or (not self.via_pad_forbid[index] and not self.via_hole_forbid[index])) and self.via_clear(net, index):
                nxt = (1-layer)*N+index
                nc = cost+(0 if reuse else 140)
                if nc < best.get(nxt, 1e15):
                    best[nxt] = nc
                    parent[nxt] = state
                    heapq.heappush(heap, (nc+h(x, y), next(seq), nc, nxt))
        raise RuntimeError(f"No route for {net}: {start['pin']} -> {goal['pin']} ({visited} states). Adjust placement or routing order.")

    def commit_path(self, net, start, goal, path):
        width = self.width(net)
        self.add_segment(net, start["real"], (path[0][1]*GRID, path[0][2]*GRID), path[0][0], width)
        anchor = path[0]
        previous = path[0]
        last_direction = None
        for point in path[1:]:
            direction = (point[0]-previous[0], point[1]-previous[1], point[2]-previous[2])
            if point[0] != previous[0]:
                self.add_segment(net, (anchor[1]*GRID, anchor[2]*GRID), (previous[1]*GRID, previous[2]*GRID), previous[0], width)
                self.add_via(net, point[1], point[2])
                anchor = point
                last_direction = None
            elif last_direction is not None and direction != last_direction:
                self.add_segment(net, (anchor[1]*GRID, anchor[2]*GRID), (previous[1]*GRID, previous[2]*GRID), previous[0], width)
                anchor = previous
            previous = point
            last_direction = direction if direction[0] == 0 else None
        self.add_segment(net, (anchor[1]*GRID, anchor[2]*GRID), (previous[1]*GRID, previous[2]*GRID), previous[0], width)
        self.add_segment(net, (previous[1]*GRID, previous[2]*GRID), goal["real"], previous[0], width)

    def route_net(self, net):
        pads = self.pads[net]
        self.report.setdefault(net, {"pads": len(pads), "width_mm": self.width(net), "length_mm": 0., "vias": 0, "segments": 0})
        connected = [pads[0]]
        remaining = list(pads[1:])
        states = 0
        while remaining:
            _, ni, ci = min((math.dist(p["xy"], q["xy"]), i, j)
                            for i, p in enumerate(remaining) for j, q in enumerate(connected))
            start, goal = remaining.pop(ni), connected[ci]
            path, visited = self.search(net, start, goal)
            self.commit_path(net, start, goal, path)
            states += visited
            connected.append(start)
        self.report[net]["length_mm"] = round(self.report[net]["length_mm"], 3)
        print(f"{net:16s} {len(pads):2d} pads  {self.report[net]['length_mm']:7.1f} mm  {self.report[net]['vias']:2d} vias  {states:7d} search states", flush=True)

    def run(self):
        self.fanout_ics()
        def order(net):
            priority = SPEC.get('routing', {}).get('priority_nets', [])
            if net in priority:
                return (-1, priority.index(net), net)
            if net in GROUND_NETS:
                return (4, len(self.pads[net]), net)
            if net in ("SUM", "TIA", "INV", "VBIAS"):
                return (0, len(self.pads[net]), net)
            if net in POWER or net in ("+5VA", "COIL_LOW"):
                return (1, len(self.pads[net]), net)
            return (2, len(self.pads[net]), net)
        for net in sorted(self.pads, key=order):
            self.route_net(net)
        return self.report

    def fanout_ics(self):
        """Give IC pads an accessible two-layer anchor before long routes.

        This prevents an early long track from enclosing a later op-amp input
        in the narrow channel between adjacent SOIC pins and local bypasses.
        Vias are outside solder pads; adjacent same-net pins can share a via.
        """
        groups = []
        for net, pads in self.pads.items():
            self.report.setdefault(net, {"pads": len(pads), "width_mm": self.width(net), "length_mm": 0., "vias": 0, "segments": 0})
            for pad in pads:
                ref, number = pad["pin"].split(".")
                is_ic = ref in SPEC.get('routing', {}).get('fanout_refs', [])
                is_smd_ground = net in GROUND_NETS and len(pad["layers"]) == 1
                if is_ic:
                    groups.append((0 if is_ic else 1, ref, (0, int(number)) if number.isdigit() else (1, number), net, pad))
        for _, ref, number, net, pad in sorted(groups):
            foreign = self.foreign_bits(net)
            sx, sy = pad["xy"]
            lo_x, hi_x = (5, NX-6)
            candidates = []
            # Prefer sharing an existing short feedback/power-ground anchor.
            for i, vnet in self.via_positions.items():
                y, x = divmod(i, NX)
                d = math.hypot(x-sx, y-sy)
                if vnet == net and d <= 18:
                    candidates.append((d*.7, x, y, True))
            for radius in range(3, 29):
                for dx, dy in itertools.product(range(-radius, radius+1), repeat=2):
                    if max(abs(dx), abs(dy)) != radius:
                        continue
                    x, y = sx+dx, sy+dy
                    if not lo_x <= x <= hi_x or not 5 <= y < NY-5:
                        continue
                    i = y*NX+x
                    if self.via_pad_forbid[i] or self.via_hole_forbid[i] or not self.regions.contains(net, x*GRID, y*GRID, VIA_DIAMETER/2):
                        continue
                    if not self.via_clear(net, i):
                        continue
                    # Mainly horizontal fanout keeps the closely pitched pads
                    # from crossing each other's escape tracks.
                    candidates.append((math.hypot(dx, dy)+abs(dy)*.45, x, y, False))
                if len(candidates) > 40:
                    break
            found = False
            for _, x, y, reuse in sorted(candidates):
                goal = {"xy": (x, y), "real": (x*GRID, y*GRID),
                        "layers": [0, 1] if reuse else [0], "pin": "fanout"}
                try:
                    path, _ = self.search(net, pad, goal)
                except RuntimeError:
                    continue
                self.commit_path(net, pad, goal, path)
                self.add_via(net, x, y)
                pad["xy"] = (x, y)
                pad["real"] = (x*GRID, y*GRID)
                pad["layers"] = [0, 1]
                found = True
                break
            if not found:
                raise RuntimeError(f"No local fanout for {ref}.{number} ({net})")
        print(f"IC/ground escape routing complete: {len(self.via_positions)} shared/non-VIP vias", flush=True)


def apply_finishing_copper(board):
    """Apply explicit reviewed plane stitches/returns without rerouting signals."""
    def segment_key(net,a,b,width,layer):
        return net,tuple(sorted((tuple(a),tuple(b)))),width,layer
    existing_vias={tuple(t.GetPosition()):t for t in board.GetTracks() if isinstance(t,pcbnew.PCB_VIA)}
    existing_tracks={segment_key(t.GetNetname(),t.GetStart(),t.GetEnd(),t.GetWidth(),t.GetLayer())
        for t in board.GetTracks() if not isinstance(t,pcbnew.PCB_VIA)}
    counts={'stitching_vias_added':0,'finishing_segments_added':0}
    for item in SPEC.get('routing',{}).get('stitching_vias',[]):
        position=vec(*item['at']);key=tuple(position)
        if key in existing_vias:
            via=existing_vias[key]
            if via.GetNetname()!=item['net'] or via.GetWidth(pcbnew.F_Cu)!=pcbnew.FromMM(item.get('diameter',.6)) or via.GetDrillValue()!=pcbnew.FromMM(item.get('drill',.3)):
                raise ValueError('Conflicting stitch at '+str(item['at']))
            continue
        via=pcbnew.PCB_VIA(board);via.SetPosition(position)
        via.SetWidth(pcbnew.FromMM(item.get('diameter',.6)));via.SetDrill(pcbnew.FromMM(item.get('drill',.3)))
        via.SetViaType(pcbnew.VIATYPE_THROUGH);via.SetLayerPair(pcbnew.F_Cu,pcbnew.B_Cu);via.SetNet(board.FindNet(item['net']))
        board.Add(via);existing_vias[key]=via;counts['stitching_vias_added']+=1
    for item in SPEC.get('routing',{}).get('finishing_tracks',[]):
        layer=pcbnew.F_Cu if item.get('layer','F.Cu')=='F.Cu' else pcbnew.B_Cu
        width=pcbnew.FromMM(item.get('width',.5))
        for a,b in zip(item['points'],item['points'][1:]):
            start,end=vec(*a),vec(*b);key=segment_key(item['net'],start,end,width,layer)
            if key in existing_tracks:continue
            track=pcbnew.PCB_TRACK(board);track.SetStart(start);track.SetEnd(end);track.SetWidth(width);track.SetLayer(layer)
            track.SetNet(board.FindNet(item['net']));board.Add(track);existing_tracks.add(key);counts['finishing_segments_added']+=1
    return counts


def add_zones(board):
    for definition in SPEC.get('routing', {}).get('zones', []):
        net = board.FindNet(definition['net'])
        if net is None:
            raise ValueError('Unknown zone net: ' + definition['net'])
        if 'rect' in definition:
            a, b, c, d = definition['rect']
            points = [[a, b], [c, b], [c, d], [a, d]]
        else:
            points = definition['polygon']
        for name in definition.get('layers', ['F.Cu', 'B.Cu']):
            zone = pcbnew.ZONE(board)
            zone.SetLayer(pcbnew.F_Cu if name == 'F.Cu' else pcbnew.B_Cu)
            zone.SetNetCode(net.GetNetCode())
            zone.SetLocalClearance(pcbnew.FromMM(definition.get('clearance_mm', .3)))
            zone.SetThermalReliefGap(pcbnew.FromMM(definition.get('thermal_gap_mm', .3)))
            zone.SetThermalReliefSpokeWidth(pcbnew.FromMM(definition.get('thermal_spoke_mm', .3)))
            zone.SetPadConnection(pcbnew.ZONE_CONNECTION_FULL if definition.get('pad_connection') == 'full' else pcbnew.ZONE_CONNECTION_THERMAL)
            zone.SetMinThickness(pcbnew.FromMM(.25))
            zone.SetIslandRemovalMode(pcbnew.ISLAND_REMOVAL_MODE_ALWAYS)
            poly = zone.Outline()
            poly.NewOutline()
            for x, y in points:
                poly.Append(pcbnew.FromMM(x), pcbnew.FromMM(y))
            holes = list(definition.get('holes', []))
            for footprint in board.GetFootprints():
                if any(pad.GetAttribute() == pcbnew.PAD_ATTRIB_NPTH for pad in footprint.Pads()):
                    x, y = mm(footprint.GetPosition().x), mm(footprint.GetPosition().y)
                    radius = SPEC.get('routing', {}).get('mounting_keepout_radius_mm', 3.2) + .15
                    if polygon_contains(points, x, y, radius):
                        holes.append([[x+radius*math.cos(math.radians(a)), y+radius*math.sin(math.radians(a))] for a in range(0, 360, 15)])
            for hole in holes:
                index = poly.NewHole(0)
                for x, y in hole:
                    poly.Append(pcbnew.FromMM(x), pcbnew.FromMM(y), 0, index)
            board.Add(zone)
    pcbnew.ZONE_FILLER(board).Fill(board.Zones())


def place_reference_labels(board):
    """Keep all reference designators visible and clear of bodies/pads/text."""
    fixed = []
    for item in board.GetDrawings():
        if item.GetLayer() in (pcbnew.F_SilkS,pcbnew.F_Mask):
            fixed.append(bounds(item.GetBoundingBox()))
    bodies = [bounds(f.GetBoundingBox(False, False)) for f in board.GetFootprints()]
    # Avoid holes in the mask from vias when printing references.
    for track in board.GetTracks():
        if isinstance(track, pcbnew.PCB_VIA):
            x, y = mm(track.GetPosition().x), mm(track.GetPosition().y)
            r = mm(track.GetWidth(pcbnew.F_Cu))/2+.15
            fixed.append((x-r, y-r, x+r, y+r))
    for fp in sorted(board.GetFootprints(), key=lambda f: (0 if f.GetReference().startswith(("U", "K", "J", "RV")) else 1, f.GetReference())):
        ref = fp.Reference()
        ref.SetTextAngle(pcbnew.EDA_ANGLE(0, pcbnew.DEGREES_T))
        ref.SetTextSize(vec(.8, .8))
        ref.SetTextThickness(pcbnew.FromMM(.13))
        ref.SetVisible(True)
        b = bounds(fp.GetBoundingBox(False, False))
        cx, cy = (b[0]+b[2])/2, (b[1]+b[3])/2
        tw = max(1.4, len(ref.GetText())*.8)
        candidates = []
        for d in [.8, 1.3, 1.8, 2.4, 3.0, 4.0, 5.0]:
            for dx in [0, -1.5, 1.5, -3.0, 3.0]:
                candidates.extend([(cx+dx, b[1]-d), (cx+dx, b[3]+d)])
            candidates.extend([(b[0]-tw/2-d, cy), (b[2]+tw/2+d, cy)])
        placed = False
        for x, y in candidates:
            ref.SetPosition(vec(x, y))
            box = bounds(ref.GetBoundingBox())
            if min(box[0], box[1]) < .6 or box[2] > BOARD_SIZE[0]-.6 or box[3] > BOARD_SIZE[1]-.6:
                continue
            if any(overlaps(box, obstacle, .15) for obstacle in bodies+fixed):
                continue
            fixed.append(box)
            placed = True
            break
        if not placed:
            raise RuntimeError("No clear silkscreen reference location for " + fp.GetReference())


def remove_unused_fanout_vias(board):
    """Remove temporary escape vias that final routing only used on one side."""
    tracks = [t for t in board.GetTracks() if not isinstance(t, pcbnew.PCB_VIA)]
    removed = 0
    for v in list(board.GetTracks()):
        if not isinstance(v, pcbnew.PCB_VIA) or v.GetNetname() in GROUND_NETS:
            continue
        p = v.GetPosition()
        layers = {t.GetLayer() for t in tracks if t.GetNetCode() == v.GetNetCode()
                  and (t.GetStart() == p or t.GetEnd() == p)}
        if len(layers) < 2:
            board.Delete(v)
            removed += 1
    return removed


def route(root, finish_only=False, no_zones=False):
    root = Path(root)
    spec = json.loads((root / 'verification/design_manifest.json').read_text())
    configure(spec, root)
    board = pcbnew.LoadBoard(str(FILE))
    if not finish_only:
        for zone in list(board.Zones()):
            board.Delete(zone)
        started = time.monotonic()
        router = Router(board)
        try:
            report = router.run()
        except Exception:
            save_board_preserving_project(str(ROOT / 'verification/routing_partial.kicad_pcb'), board)
            raise
        save_board_preserving_project(str(FILE), board)
        (ROOT / 'verification/routing.json').write_text(json.dumps({'grid_mm': GRID, 'clearance_mm': CLEARANCE,
            'via_diameter_mm': VIA_DIAMETER, 'via_drill_mm': VIA_DRILL,
            'seconds': round(time.monotonic()-started, 3), 'nets': report}, indent=2) + '\n')
    removed = remove_unused_fanout_vias(board)
    added=apply_finishing_copper(board)
    if any(added.values()):print(json.dumps(added),flush=True)
    if not no_zones:
        for zone in list(board.Zones()):
            board.Delete(zone)
        add_zones(board)
    place_reference_labels(board)
    save_board_preserving_project(str(FILE), board)
    if '(pts)' in FILE.read_text():
        raise RuntimeError('Empty polygon contour in generated board')
    report_path = ROOT / 'verification/routing.json'
    if report_path.exists():
        data = json.loads(report_path.read_text())
        counts = defaultdict(int)
        for track in board.GetTracks():
            if isinstance(track, pcbnew.PCB_VIA):
                counts[track.GetNetname()] += 1
        data['removed_unused_fanout_vias'] = removed
        for net, info in data['nets'].items():
            info['vias'] = counts[net]
        report_path.write_text(json.dumps(data, indent=2) + '\n')
    return FILE


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('package', type=Path)
    parser.add_argument('--finish-only', action='store_true')
    parser.add_argument('--no-zones', action='store_true')
    args = parser.parse_args()
    route(args.package, args.finish_only, args.no_zones)


if __name__ == '__main__':
    main()
