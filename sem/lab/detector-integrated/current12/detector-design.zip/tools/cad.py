#!/usr/bin/env python3
"""Configurable native KiCad generation; no component pinout is inferred.

Run `/usr/bin/python3 cad.py SPEC.json OUTPUT_DIRECTORY`.
See README.md for the structured specification and complete command sequence.
"""
from __future__ import annotations
import argparse
import copy
import csv
import json
from pathlib import Path
import re
import subprocess
from types import SimpleNamespace
import uuid
import xml.etree.ElementTree as ET
import pcbnew
import primitives as h

LAYER_IDS = {'F.Cu': pcbnew.F_Cu, 'B.Cu': pcbnew.B_Cu, 'F.Mask': pcbnew.F_Mask,
             'B.Mask': pcbnew.B_Mask, 'F.SilkS': pcbnew.F_SilkS, 'B.SilkS': pcbnew.B_SilkS,
             'F.Fab': pcbnew.F_Fab, 'B.Fab': pcbnew.B_Fab, 'Dwgs.User': pcbnew.Dwgs_User,
             'Edge.Cuts': pcbnew.Edge_Cuts}


def configure(spec, root):
    h.ROOT = Path(root).resolve()
    h.OUT = h.ROOT / 'kicad'
    h.LIB = h.OUT / 'Integrated.pretty'
    h.PROJECT = spec['project']
    h.DATE = spec.get('date', '2026-09-13')
    h.REVISION = spec.get('revision', 'UNBUILT')
    h.NAMESPACE = uuid.uuid5(uuid.NAMESPACE_URL, 'integrated-detector:' + h.PROJECT)


def validate_spec(spec):
    if not re.fullmatch(r'[A-Za-z0-9_-]+', spec.get('project', '')):
        raise ValueError('project must be a filename-safe identifier')
    if len(spec.get('board_mm', [])) != 2 or min(spec['board_mm']) <= 0:
        raise ValueError('board_mm must specify positive width and height')
    refs = [p['ref'] for p in spec['parts']]
    if len(set(refs)) != len(refs):
        raise ValueError('Duplicate reference designators')
    for p in spec['parts']:
        for key in ('value', 'symbol', 'footprint', 'nets', 'at', 'sch'):
            if key not in p:
                raise ValueError(f'{p["ref"]}: missing {key}')
        if len(p['at']) != 3 or len(p['sch']) not in (2, 3):
            raise ValueError(f'{p["ref"]}: at and sch are [x,y,angle] coordinates')
    sheets = [s['id'] for s in spec.get('sheets', [])]
    if len(set(sheets)) != len(sheets):
        raise ValueError('Duplicate schematic sheet ids')
    for sid in sheets:
        if not re.fullmatch(r'[A-Za-z0-9_-]+', sid):
            raise ValueError('Sheet id must be filename-safe')
    if sheets:
        for p in spec['parts']:
            if p.get('sheet') not in sheets:
                raise ValueError(f'{p["ref"]}: unknown schematic sheet')


def default_symbols():
    result = {}
    stock = {'R': ('Device', 'R'), 'C': ('Device', 'C'), 'CP': ('Device', 'C_Polarized'),
             'D': ('Device', 'D'), 'BAT54S': ('Diode', 'BAT54S'),
             'TestPoint': ('Connector', 'TestPoint'), 'MountingHole': ('Mechanical', 'MountingHole'),
             'PWR_FLAG': ('power', 'PWR_FLAG'), 'LDO': ('Regulator_Linear', 'MCP1700x-330xxTO')}
    for name, source in stock.items():
        result[name] = renamed_stock(name, source)
    result['DualOpAmp'] = h.opamp_symbol('DualOpAmp', [(3, 2, 1), (5, 6, 7)], (8, 4))
    result['ADC'] = h.box_symbol('ADC', [(4, 'AIN0', 'input'), (5, 'AIN1', 'input'),
        (6, 'AIN2', 'input'), (7, 'AIN3', 'input'), (1, 'ADDR', 'input')],
        [(8, 'VDD', 'power_in'), (3, 'GND', 'power_in'), (9, 'SDA', 'bidirectional'),
         (10, 'SCL', 'input'), (2, 'ALERT_RDY', 'open_collector')], step=7.62)
    for count in range(1, 13):
        name = f'Conn{count}'
        result[name] = h.box_symbol(name, [(i, str(i), 'passive') for i in range(1, count + 1)], [], 'J', width=3.81)
    return result


def renamed_stock(name, source):
    library, original = source
    symbol = h.stock_symbol(library, original)
    symbol[1] = name
    for section in h.children(symbol, 'symbol'):
        section[1] = name + section[1][len(original):]
    return symbol


def make_symbols(spec):
    symbols = default_symbols()
    for name, definition in spec.get('symbols', {}).items():
        if isinstance(definition, str):
            symbols[name] = h.parse(definition)
        elif 'stock' in definition:
            symbols[name] = renamed_stock(name, definition['stock'])
        elif 'opamp' in definition:
            symbols[name] = h.opamp_symbol(name, definition['opamp'], definition['power_pins'])
        else:
            symbols[name] = h.box_symbol(name, definition.get('left', []), definition.get('right', []),
                definition.get('reference', 'U'), definition.get('width', 12.7), definition.get('step', 5.08))
        if symbols[name][1] != name:
            raise ValueError(f'Custom symbol root must be named {name}')
    content = [h.A('kicad_symbol_lib'), h.form('(version 20250114)'), h.form('(generator "kicad_symbol_editor")')]
    (h.OUT / 'Integrated.kicad_sym').write_text(h.emit(content + list(symbols.values())) + '\n')
    (h.OUT / 'sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "Integrated") (type "KiCad") (uri "${KIPRJMOD}/Integrated.kicad_sym") (options "") (descr "Explicit prototype pin maps")))\n')
    return symbols


def through_hole_footprint(name, pads, body, description=''):
    """Build a module footprint from explicitly supplied top-view pad locations.

    pads: [{number, at:[x,y], size:[x,y], drill:diameter, shape:'circle'|'rect'}]
    body: [left,top,right,bottom], all coordinates in mm. No pin map is assumed.
    """
    text = f'(footprint {json.dumps(name)} (version 20241229) (generator "pcbnew") (layer "F.Cu")\n'
    text += f'(descr {json.dumps(description)}) (attr through_hole)\n'
    cx = (body[0] + body[2]) / 2
    for prop, value, y, layer in [('Reference', 'REF**', body[1]-1.2, 'F.SilkS'), ('Value', name, body[3]+1.2, 'F.Fab')]:
        text += f'(property "{prop}" {json.dumps(value)} (at {cx} {y} 0) (layer "{layer}") (effects (font (size 1 1) (thickness .15))))\n'
    for layer, margin, width in [('F.Fab', 0, .1), ('F.SilkS', .1, .12), ('F.CrtYd', .5, .05)]:
        text += f'(fp_rect (start {body[0]-margin} {body[1]-margin}) (end {body[2]+margin} {body[3]+margin}) (stroke (width {width}) (type solid)) (fill none) (layer "{layer}"))\n'
    for p in pads:
        text += f'(pad {json.dumps(str(p["number"]))} thru_hole {p.get("shape", "circle")} (at {h.xy(p["at"])}) (size {h.xy(p.get("size", [1.8, 1.8]))}) (drill {p.get("drill", 1)}) (layers "*.Cu" "*.Mask"))\n'
    return text + ')\n'


def make_footprints(spec, parts):
    custom = spec.get('footprints', {})
    stripped_names = {p.footprint.split(':')[-1] for p in parts if p.extras.get('strip_silk')}
    for p in parts:
        library, name = p.footprint.split(':', 1)
        dest = h.LIB / (name + '.kicad_mod')
        if name in custom:
            definition = custom[name]
            content = definition if isinstance(definition, str) else through_hole_footprint(name, **definition)
        else:
            if library == 'Integrated':
                raise ValueError(f'No supplied geometry for {p.footprint}')
            content = (h.SYS_FOOTPRINTS / (library + '.pretty') / (name + '.kicad_mod')).read_text()
        content = content.replace('${KICAD9_3DMODEL_DIR}', '${KICAD10_3DMODEL_DIR}')
        if name in spec.get('models', {}):
            model = spec['models'][name]
            left, top, right, bottom = model['body']
            height = model['height_mm']
            # KiCad VRML convention is 0.1 inch units; board Y is reversed.
            factor = 1/2.54
            color = model.get('color', [.12, .13, .14])
            body = '#VRML V2.0 utf8\n'
            body += f'Transform {{ translation {(left+right)/2*factor} {-(top+bottom)/2*factor} {height/2*factor} children [ Shape {{ appearance Appearance {{ material Material {{ diffuseColor {color[0]} {color[1]} {color[2]} }} }} geometry Box {{ size {(right-left)*factor} {(bottom-top)*factor} {height*factor} }} }} ] }}\n'
            (h.OUT/'3d').mkdir(exist_ok=True)
            (h.OUT/'3d'/(name+'.wrl')).write_text(body)
            tree0 = h.parse(content)
            tree0 = [item for item in tree0 if not (isinstance(item,list) and item and item[0]=='model')]
            tree0.append(h.form(f'(model "${{KIPRJMOD}}/3d/{name}.wrl" (offset (xyz 0 0 0)) (scale (xyz 1 1 1)) (rotate (xyz 0 0 0)))'))
            content = h.emit(tree0)

        tree = h.parse(content)
        if name in stripped_names:
            tree = [v for v in tree if not (isinstance(v, list) and v and v[0] in
                ('fp_line', 'fp_rect', 'fp_circle', 'fp_arc', 'fp_poly') and h.child(v, 'layer') and h.child(v, 'layer')[1] == 'F.SilkS')]
        dest.write_text(h.emit(tree) + '\n')
    (h.OUT / 'fp-lib-table').write_text('(fp_lib_table (version 7) (lib (name "Integrated") (type "KiCad") (uri "${KIPRJMOD}/Integrated.pretty") (options "") (descr "Project-local stock and supplied footprints")))\n')


def as_part(definition):
    p = SimpleNamespace(**copy.deepcopy(definition))
    p.nets = {str(k): v for k, v in p.nets.items()}
    p.sch_at, p.sch_angle = p.sch[:2], p.sch[2] if len(p.sch) > 2 else 0
    for key, default in [('mpn', ''), ('manufacturer', ''), ('buy', ''), ('buy_alt', ''),
                         ('purpose', ''), ('datasheet', ''), ('extras', {}), ('sheet', 'main')]:
        if not hasattr(p, key):
            setattr(p, key, default)
    return p


def add_schematic_decorations(sch, decorations, flag_offset=0):
    for points in decorations.get('wires', []):
        sch.wire(points)
    for label in decorations.get('labels', []):
        sch.label(label['net'], label['at'], label.get('angle', 0))
    for note in decorations.get('notes', []):
        sch.note(note['text'], note['at'], note.get('size', 1.2))
    for pt in decorations.get('junctions', []):
        sch.items.append(f'(junction (at {h.xy(pt)}) (diameter 0) (color 0 0 0 0) (uuid "{sch.ident("junction")}"))')
    for i, flag in enumerate(decorations.get('flags', []), 1):
        sch.power_flag(flag['net'], flag['at'], flag.get('index', flag_offset+i))


def make_schematics(spec, symbols, parts):
    sheets = spec.get('sheets', []) or [{'id': 'main', 'title': spec.get('title', spec['project']), **spec.get('schematic', {})}]
    for sheet_number, sheet in enumerate(sheets, 1):
        sid = sheet['id']
        child = sid != 'main' or bool(spec.get('sheets'))
        name = spec['project'] + '_' + sid if child else spec['project']
        sch = h.Schematic(name, sheet['title'], symbols, sheet_key=sid if child else None, root_name=spec['project'])
        for p in parts:
            if p.sheet != sid:
                continue
            for unit in getattr(p, 'units', [{'unit': 1, 'at': p.sch}]):
                at = unit['at']
                sch.add_part(p, unit.get('unit', 1), at[:2], at[2] if len(at) > 2 else 0, buffer=unit.get('buffer', False))
        add_schematic_decorations(sch, sheet, sheet_number*100)
        sch.save()
    if not spec.get('sheets'):
        return
    overview = h.Schematic(spec['project'], spec.get('title', spec['project']), symbols, root_name=spec['project'])
    overview.note(spec.get('title', spec['project']), (20.32, 20.32), 2.2)
    for index, sheet in enumerate(sheets):
        x, y = 20.32, 45.72 + index * 35.56
        sid, title = sheet['id'], sheet['title']
        overview.items.append(f'(sheet (at {x} {y}) (size 177.8 25.4) (fields_autoplaced yes)'
            f' (stroke (width .254) (type default)) (fill (color 0 0 0 0)) (uuid "{h.uid("sheet:" + sid)}")'
            f' (property "Sheetname" {json.dumps(title)} (at {x} {y-1.27} 0) (effects (font (size 1.27 1.27)) (justify left bottom)))'
            f' (property "Sheetfile" "{spec["project"]}_{sid}.kicad_sch" (at {x} {y+26.67} 0) (effects (font (size 1.27 1.27)) (justify left top)))'
            f' (instances (project "{spec["project"]}" (path "/{h.uid("root")}" (page "{index+2}")))))')
        description=spec.get('overview_descriptions',{}).get(sid)
        if description:overview.note(description,(x+5.08,y+5.08),1.15)
    add_schematic_decorations(overview, spec.get('schematic', {}))
    overview.save()


def project_settings(spec):
    rules = {'min_clearance': .18, 'min_track_width': .18, 'min_copper_edge_clearance': .5,
        'min_hole_clearance': .2, 'min_hole_to_hole': .2, 'min_through_hole_diameter': .3,
        'min_via_diameter': .6, 'min_via_annular_width': .15, 'min_silk_clearance': .1,
        'min_text_height': .8, 'min_text_thickness': .12, 'min_resolved_spokes': 2}
    rules.update(spec.get('rules', {}))
    return {'meta': {'filename': spec['project'] + '.kicad_pro', 'version': 3},
        'board': {'design_settings': {'meta': {'version': 2}, 'drc_exclusions': [], 'rules': rules,
        'rule_severities': {'courtyards_overlap': 'error', 'missing_courtyard': 'warning',
            'unconnected_items': 'error', 'shorting_items': 'error', 'clearance': 'error',
            'silk_overlap': 'warning', 'silk_over_copper': 'warning'}}},
        'erc': {'erc_exclusions': [], 'meta': {'version': 0}},
        'net_settings': {'meta': {'version': 4}, 'classes': [{'name': 'Default',
            'clearance': rules['min_clearance'], 'track_width': rules['min_track_width'],
            'via_diameter': .6, 'via_drill': .3, 'bus_width': 12, 'wire_width': 6,
            'schematic_color': [0, 0, 0, 0]}]},
        'text_variables': {'ASSEMBLY_STATUS': 'UNBUILT PROTOTYPE'}}


def make_board(spec, parts, native):
    board = pcbnew.BOARD()
    board.SetCopperLayerCount(2)
    board.SetFileName(str(h.OUT / (spec['project'] + '.kicad_pcb')))
    settings = board.GetDesignSettings()
    rules = project_settings(spec)['board']['design_settings']['rules']
    settings.m_TrackMinWidth = pcbnew.FromMM(rules['min_track_width'])
    settings.m_MinClearance = pcbnew.FromMM(rules['min_clearance'])
    settings.m_CopperEdgeClearance = pcbnew.FromMM(rules['min_copper_edge_clearance'])
    settings.SetBoardThickness(pcbnew.FromMM(spec.get('thickness_mm', 1.6)))
    nets, native_pins = {}, {}
    for index, net in enumerate(native.findall('nets/net'), 1):
        name = net.get('name')
        item = pcbnew.NETINFO_ITEM(board, name, index)
        board.Add(item)
        nets[name] = item
        for node in net.findall('node'):
            native_pins[(node.get('ref'), node.get('pin'))] = name
    for p in parts:
        name = p.footprint.split(':')[-1]
        fp = pcbnew.FootprintLoad(str(h.LIB), name)
        if fp is None:
            raise ValueError(f'Failed to load footprint {name}')
        fp.SetFPID(pcbnew.LIB_ID('Integrated', name))
        fp.SetReference(p.ref)
        fp.SetValue(p.value)
        fp.SetPosition(h.vec(*p.at[:2]))
        fp.SetOrientationDegrees(p.at[2])
        fp.m_Uuid.Clone(pcbnew.KIID(h.uid('footprint:' + p.ref)))
        sheet_path = '/' + h.uid('sheet:' + p.sheet) if spec.get('sheets') else ''
        unit = getattr(p, 'units', [{'unit': 1}])[0].get('unit', 1)
        fp.SetPath(pcbnew.KIID_PATH('/' + h.uid('root') + sheet_path + '/' + h.uid(f'symbol:{p.ref}:{unit}')))
        fp.Value().SetVisible(False)
        actual_numbers = {pad.GetNumber() for pad in fp.Pads() if pad.GetNumber()}
        if actual_numbers != set(p.nets):
            raise ValueError(f'{p.ref}: footprint pads {actual_numbers} differ from explicit pins {set(p.nets)}')
        for pad in fp.Pads():
            number = pad.GetNumber()
            if number:
                native_name = native_pins.get((p.ref, number))
                wanted = p.nets[number]
                if wanted is not None and native_name != wanted:
                    raise ValueError(f'{p.ref}.{number}: native schematic {native_name} differs from {wanted}')
                if native_name:
                    pad.SetNet(nets[native_name])
        if p.ref.startswith('H'):
            fp.SetAttributes(fp.GetAttributes() | pcbnew.FP_EXCLUDE_FROM_BOM | pcbnew.FP_EXCLUDE_FROM_POS_FILES)
        for key, val in {'MPN': p.mpn, 'Manufacturer': p.manufacturer, 'Buy_Mouser': p.buy if p.mpn else '', 'Buy_DigiKey': p.buy_alt if p.mpn else '', 'Datasheet': p.datasheet, 'Function': p.purpose}.items():
            fp.SetField(key, val)
            fp.GetField(key).SetVisible(False)
            fp.GetField(key).SetLayer(pcbnew.F_Fab)
        board.Add(fp)
    width, height = spec['board_mm']
    outline = spec.get('outline', [[0, 0], [width, 0], [width, height], [0, height]])
    for a, b in zip(outline, outline[1:] + outline[:1]):
        shape = pcbnew.PCB_SHAPE()
        shape.SetShape(pcbnew.SHAPE_T_SEGMENT)
        shape.SetStart(h.vec(*a)); shape.SetEnd(h.vec(*b))
        shape.SetWidth(pcbnew.FromMM(.1)); shape.SetLayer(pcbnew.Edge_Cuts)
        board.Add(shape)
    for seed in spec.get('tracks', []):
        for a, b in zip(seed['points'], seed['points'][1:]):
            track = pcbnew.PCB_TRACK(board)
            track.SetStart(h.vec(*a)); track.SetEnd(h.vec(*b))
            track.SetWidth(pcbnew.FromMM(seed.get('width', .25)))
            track.SetLayer(LAYER_IDS[seed.get('layer', 'F.Cu')]); track.SetNet(nets[seed['net']])
            board.Add(track)
    for seed in spec.get('vias', []):
        via = pcbnew.PCB_VIA(board)
        via.SetPosition(h.vec(*seed['at'])); via.SetWidth(pcbnew.FromMM(seed.get('diameter', .6)))
        via.SetDrill(pcbnew.FromMM(seed.get('drill', .3)))
        via.SetViaType(pcbnew.VIATYPE_THROUGH); via.SetLayerPair(pcbnew.F_Cu, pcbnew.B_Cu)
        via.SetNet(nets[seed['net']]); board.Add(via)
    for graphic in spec.get('graphics', []):
        layer = LAYER_IDS[graphic.get('layer', 'F.SilkS')]
        if 'text' in graphic:
            h.pcb_text(board, graphic['text'], *graphic['at'], graphic.get('height', 1), layer, graphic.get('width', .15))
        else:
            for a, b in zip(graphic['points'], graphic['points'][1:]):
                shape = pcbnew.PCB_SHAPE()
                shape.SetShape(pcbnew.SHAPE_T_SEGMENT); shape.SetStart(h.vec(*a)); shape.SetEnd(h.vec(*b))
                shape.SetWidth(pcbnew.FromMM(graphic.get('width', .15))); shape.SetLayer(layer); board.Add(shape)
    h.save_board_preserving_project(board.GetFileName(), board)
    return board


def generate(spec, root):
    validate_spec(spec)
    configure(spec, root)
    for folder in (h.OUT, h.LIB, h.ROOT / 'exports', h.ROOT / 'fabrication', h.ROOT / 'verification'):
        folder.mkdir(parents=True, exist_ok=True)
    # Create the project before pcbnew attaches it; otherwise its process cache
    # can retain default settings and overwrite the supplied rules on save.
    (h.OUT / (h.PROJECT + '.kicad_pro')).write_text(json.dumps(project_settings(spec), indent=2) + '\n')
    parts = [as_part(p) for p in spec['parts']]
    symbols = make_symbols(spec)
    make_footprints(spec, parts)
    make_schematics(spec, symbols, parts)
    netlist = h.ROOT / 'verification' / 'detector.net.xml'
    subprocess.run(['kicad-cli', 'sch', 'export', 'netlist', '--format', 'kicadxml', '-o', str(netlist), str(h.OUT / (h.PROJECT + '.kicad_sch'))], check=True)
    native = ET.parse(netlist)
    make_board(spec, parts, native)
    (h.OUT / (h.PROJECT + '.kicad_pro')).write_text(json.dumps(project_settings(spec), indent=2) + '\n')
    if spec.get('custom_rules'):
        (h.OUT / (h.PROJECT + '.kicad_dru')).write_text(spec['custom_rules'].rstrip() + '\n')
    (h.ROOT / 'verification' / 'design_manifest.json').write_text(json.dumps(spec, indent=2) + '\n')
    with (h.ROOT / 'bom.csv').open('w', newline='') as output:
        writer = csv.writer(output)
        writer.writerow(['Reference', 'Value', 'Quantity', 'MPN_or_procurement_spec', 'Footprint', 'Function', 'Datasheet'])
        for p in parts:
            writer.writerow([p.ref, p.value, 1, p.mpn or p.value, p.footprint, p.purpose, p.datasheet])
    return h.ROOT


def refresh(spec, root):
    """Refresh diagrams, field text and preview bodies without changing copper.

    Net maps and physical placements must match the existing design manifest.
    Re-run native checks after this operation; it invalidates previous hashes.
    """
    validate_spec(spec)
    configure(spec, root)
    previous=json.loads((h.ROOT/'verification/design_manifest.json').read_text())
    old={p['ref']:p for p in previous['parts']}
    for p in spec['parts']:
        if p['ref'] not in old or any(p.get(k)!=old[p['ref']].get(k) for k in ('nets','at','footprint','symbol')):
            raise ValueError('Refresh cannot change copper or circuit: '+p['ref'])
    if len(old)!=len(spec['parts']):raise ValueError('Refresh cannot remove parts')
    parts=[as_part(p) for p in spec['parts']]
    symbols=make_symbols(spec)
    make_footprints(spec,parts)
    make_schematics(spec,symbols,parts)
    board_path=h.OUT/(h.PROJECT+'.kicad_pcb')
    tree=h.parse(board_path.read_text())
    by_ref={p.ref:p for p in parts}
    stripped_names={p.footprint.split(':')[-1] for p in parts if p.extras.get('strip_silk')}
    # Work on the native S-expression for metadata/model refresh. Sharing
    # FP_3DMODEL proxies between loaded footprints is unsafe in the SWIG API.
    for fp in h.children(tree,'footprint'):
        properties={item[1]:item for item in h.children(fp,'property')}
        ref=properties['Reference'][2]
        p=by_ref[ref]
        properties['Value'][2]=p.value
        for key,value in {'MPN':p.mpn,'Manufacturer':p.manufacturer,'Buy_Mouser':p.buy if p.mpn else '',
                          'Buy_DigiKey':p.buy_alt if p.mpn else '', 'Datasheet':p.datasheet,'Function':p.purpose}.items():
            properties[key][2]=value
        name=p.footprint.split(':')[-1]
        if name in stripped_names:
            fp[:]=[item for item in fp if not (isinstance(item,list) and item and item[0] in
                ('fp_line','fp_rect','fp_circle','fp_arc','fp_poly') and h.child(item,'layer') and h.child(item,'layer')[1]=='F.SilkS')]
        source=h.parse((h.LIB/(name+'.kicad_mod')).read_text())
        fp[:]=[item for item in fp if not (isinstance(item,list) and item and item[0]=='model')]
        fp.extend(copy.deepcopy(h.children(source,'model')))
    old_texts={g['text'] for g in previous.get('graphics',[]) if 'text' in g}
    tree[:]=[item for item in tree if not (isinstance(item,list) and len(item)>1 and item[0]=='gr_text' and item[1] in old_texts)]
    for index,graphic in enumerate(spec.get('graphics',[])):
        if 'text' not in graphic:continue
        height=graphic.get('height',1);width=graphic.get('width',.15)
        tree.append(h.parse(f'(gr_text {json.dumps(graphic["text"],ensure_ascii=False)} (at {h.xy(graphic["at"])} 0)'
            f' (layer "{graphic.get("layer","F.SilkS")}") (uuid "{h.uid("graphic-text:"+str(index))}")'
            f' (effects (font (size {height} {height}) (thickness {width}))))'))
    board_path.write_text(h.emit(tree)+'\n')
    (h.ROOT/'verification/design_manifest.json').write_text(json.dumps(spec,indent=2)+'\n')
    with (h.ROOT/'bom.csv').open('w',newline='') as output:
        writer=csv.writer(output)
        writer.writerow(['Reference','Value','Quantity','MPN_or_procurement_spec','Footprint','Function','Datasheet'])
        for p in parts:writer.writerow([p.ref,p.value,1,p.mpn or p.value,p.footprint,p.purpose,p.datasheet])
    return h.ROOT


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('spec', type=Path); parser.add_argument('output', type=Path); parser.add_argument('--refresh', action='store_true')
    args = parser.parse_args()
    (refresh if args.refresh else generate)(json.loads(args.spec.read_text()), args.output)
