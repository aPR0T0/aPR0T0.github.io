#!/usr/bin/env python3
"""Native ERC/DRC, independent pin maps, and copper-domain audit.

Run `/usr/bin/python3 check.py OUTPUT_DIRECTORY` after routing.
A passing report establishes CAD consistency only, not bench performance or an
insulation certification. No ERC/DRC exclusions are accepted.
"""
from __future__ import annotations
import argparse
from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import pcbnew
from router import RoutingRegions, point_segment_distance


def insist(condition, message):
    if not condition:
        raise AssertionError(message)


def native_pin_nets(path):
    tree = ET.parse(path)
    pins = {}
    for net in tree.findall('nets/net'):
        for node in net.findall('node'):
            if not node.get('ref').startswith('#'):
                pins[(node.get('ref'), node.get('pin'))] = net.get('name')
    return tree, pins


def verify_pins(spec, board, native):
    expected = {(p['ref'], str(pin)): net for p in spec['parts'] for pin, net in p['nets'].items()}
    actual = {}
    for footprint in board.GetFootprints():
        for pad in footprint.Pads():
            if not pad.GetNumber():
                continue
            key = footprint.GetReference(), pad.GetNumber()
            if key in actual:
                insist(actual[key] == pad.GetNetname(), f'Duplicate numbered pads differ: {key}')
            actual[key] = pad.GetNetname()
    insist(set(actual) == set(expected), f'PCB pad set differs: {set(actual) ^ set(expected)}')
    insist(set(native) == set(expected), f'Native pin set differs: {set(native) ^ set(expected)}')
    for key, wanted in expected.items():
        if wanted is None:
            insist(native[key].startswith('unconnected-'), f'NC pin connected in schematic: {key}')
            insist(actual[key] in ('', native[key]), f'NC pad connected on board: {key}')
        else:
            insist(actual[key] == native[key] == wanted, f'Pin mismatch {key}: wanted {wanted}, schematic {native[key]}, PCB {actual[key]}')
    for ref, pins in spec.get('audit', {}).get('pin_nets', {}).items():
        for pin, net in pins.items():
            seen = actual.get((ref, str(pin)))
            match = (seen in ('', None) or str(seen).startswith('unconnected-')) if net is None else seen == net
            insist(match, f'Independent interface pin audit failed: {ref}.{pin} expected {net}')
    for net, members in spec.get('audit', {}).get('net_members', {}).items():
        actual_members = {f'{ref}.{pin}' for (ref, pin), value in actual.items() if value == net}
        insist(actual_members == set(members), f'Unexpected nodes on {net}: {actual_members} != {set(members)}')
    for a, b in spec.get('audit', {}).get('distinct_nets', []):
        insist(a != b and a in actual.values() and b in actual.values(), f'Missing/distorted separate nets {a}, {b}')
    return actual


def segment_samples(a, b, step=.1):
    count = max(1, math.ceil(math.dist(a, b)/step))
    for i in range(count+1):
        f = i/count
        yield a[0]+f*(b[0]-a[0]), a[1]+f*(b[1]-a[1])


def xy(vector):
    return pcbnew.ToMM(vector.x), pcbnew.ToMM(vector.y)


def verify_finishing_copper(spec,board):
    """Require the reviewed local returns/stitches and solid pad-to-zone lands."""
    vias=[t for t in board.GetTracks() if isinstance(t,pcbnew.PCB_VIA)]
    tracks=[t for t in board.GetTracks() if not isinstance(t,pcbnew.PCB_VIA)]
    routing=spec.get('routing',{});segments=0
    for item in routing.get('stitching_vias',[]):
        candidates=[v for v in vias if v.GetNetname()==item['net'] and math.dist(xy(v.GetPosition()),item['at'])<1e-6]
        insist(len(candidates)==1,'Missing/duplicate required plane stitch: '+str(item))
        via=candidates[0];radius=pcbnew.ToMM(via.GetWidth(pcbnew.F_Cu))/2
        insist(abs(radius*2-item.get('diameter',.6))<1e-6 and abs(pcbnew.ToMM(via.GetDrillValue())-item.get('drill',.3))<1e-6,'Wrong stitch size: '+str(item))
        x,y=xy(via.GetPosition())
        for footprint in board.GetFootprints():
            for pad in footprint.Pads():
                box=pad.GetBoundingBox();x1,y1=pcbnew.ToMM(box.GetX()),pcbnew.ToMM(box.GetY());x2,y2=pcbnew.ToMM(box.GetRight()),pcbnew.ToMM(box.GetBottom())
                insist(x+radius+.15<x1 or x-radius-.15>x2 or y+radius+.15<y1 or y-radius-.15>y2,
                    f'Stitch intrudes into pad envelope: {item} / {footprint.GetReference()}.{pad.GetNumber()}')
    for item in routing.get('finishing_tracks',[]):
        layer=pcbnew.F_Cu if item.get('layer','F.Cu')=='F.Cu' else pcbnew.B_Cu
        for a,b in zip(item['points'],item['points'][1:]):
            found=any(t.GetNetname()==item['net'] and t.GetLayer()==layer and abs(pcbnew.ToMM(t.GetWidth())-item.get('width',.5))<1e-6
                and ((math.dist(xy(t.GetStart()),a)<1e-6 and math.dist(xy(t.GetEnd()),b)<1e-6)
                    or (math.dist(xy(t.GetStart()),b)<1e-6 and math.dist(xy(t.GetEnd()),a)<1e-6)) for t in tracks)
            insist(found,'Missing required local return segment: '+str(item));segments+=1
    lands=0
    footprints={f.GetReference():f for f in board.GetFootprints()}
    for net,members in spec.get('audit',{}).get('solid_zone_pad_members',{}).items():
        zones=[z for z in board.Zones() if not z.GetIsRuleArea() and z.GetNetname()==net and z.IsOnLayer(pcbnew.F_Cu) and z.GetPadConnection()==pcbnew.ZONE_CONNECTION_FULL]
        for member in members:
            ref,number=member.split('.');pad=next(p for p in footprints[ref].Pads() if p.GetNumber()==number)
            insist(pad.GetNetname()==net and any(z.HitTestFilledArea(pcbnew.F_Cu,pad.GetPosition(),0) for z in zones),'No filled solid F.Cu zone at required pad: '+member)
            lands+=1
    return {'required_plane_stitches':len(routing.get('stitching_vias',[])),'required_local_return_segments':segments,'solid_zone_pad_lands':lands}


def verify_geometry(spec, board):
    regions = RoutingRegions(spec)
    crossing = set(spec.get('routing', {}).get('crossing_components', []))
    crossing_seen = set()
    for footprint in board.GetFootprints():
        domains = set()
        for pad in footprint.Pads():
            net = pad.GetNetname()
            if not net or net.startswith('unconnected-'):
                continue
            domain = regions.domain(net)
            if domain:
                domains.add(domain)
            box = pad.GetBoundingBox()
            x1, y1 = pcbnew.ToMM(box.GetX()), pcbnew.ToMM(box.GetY())
            x2, y2 = pcbnew.ToMM(box.GetRight()), pcbnew.ToMM(box.GetBottom())
            # A bounding rectangle is conservative for round/oval pads.
            for point in [(x1, y1), (x1, y2), (x2, y1), (x2, y2)]:
                insist(regions.contains(net, *point), f'Pad escapes routing domain: {footprint.GetReference()}.{pad.GetNumber()} ({net}) at {point}')
        if len(domains) > 1:
            ref = footprint.GetReference()
            insist(ref in crossing, f'Undeclared component crossing domains: {ref} {domains}')
            crossing_seen.add(ref)
    insist(crossing_seen == crossing, f'Crossing allowlist contains unused/misplaced references: {crossing - crossing_seen}')
    count = 0
    for track in board.GetTracks():
        net = track.GetNetname()
        if isinstance(track, pcbnew.PCB_VIA):
            radius = pcbnew.ToMM(track.GetWidth(pcbnew.F_Cu))/2
            point = xy(track.GetPosition())
            insist(regions.contains(net, *point, radius), f'Via escapes routing domain: {net} at {point}')
        else:
            radius = pcbnew.ToMM(track.GetWidth())/2
            for point in segment_samples(xy(track.GetStart()), xy(track.GetEnd())):
                insist(regions.contains(net, *point, radius), f'Track escapes routing domain: {net} at {point}')
        count += 1
    for zone in board.Zones():
        if zone.GetIsRuleArea():
            continue
        poly = zone.Outline()
        for index in range(poly.OutlineCount()):
            contour = poly.COutline(index)
            points = [xy(contour.CPoint(i)) for i in range(contour.PointCount())]
            for a, b in zip(points, points[1:]+points[:1]):
                for point in segment_samples(a, b):
                    insist(regions.contains(zone.GetNetname(), *point), f'Zone outline escapes routing domain: {zone.GetNetname()} at {point}')
    for net, requirement in spec.get('audit', {}).get('sensitive_nets', {}).items():
        tracks = [t for t in board.GetTracks() if t.GetNetname() == net]
        vias = [t for t in tracks if isinstance(t, pcbnew.PCB_VIA)]
        copper = [t for t in tracks if not isinstance(t, pcbnew.PCB_VIA)]
        if requirement.get('no_vias', True):
            insist(not vias, f'Sensitive net {net} has vias')
        if 'max_length_mm' in requirement:
            length = sum(pcbnew.ToMM(t.GetLength()) for t in copper)
            insist(length <= requirement['max_length_mm']+1e-6, f'{net} length {length} exceeds allowed {requirement["max_length_mm"]}')
        if 'layer' in requirement:
            wanted = pcbnew.F_Cu if requirement['layer'] == 'F.Cu' else pcbnew.B_Cu
            insist(all(t.GetLayer() == wanted for t in copper), f'{net} changes copper side')
    return {'checked_tracks_and_vias': count, 'declared_crossing_components': sorted(crossing_seen)}


def verify_mounting_clearance(spec, board):
    radius=spec.get('mechanical',{}).get('copper_keepout_radius_mm',spec.get('routing',{}).get('mounting_keepout_radius_mm',3.2))
    holes=[pad for fp in board.GetFootprints() for pad in fp.Pads() if pad.GetAttribute()==pcbnew.PAD_ATTRIB_NPTH]
    for hole in holes:
        hx,hy=xy(hole.GetPosition())
        for track in board.GetTracks():
            if isinstance(track,pcbnew.PCB_VIA):
                distance=math.dist((hx,hy),xy(track.GetPosition()))-pcbnew.ToMM(track.GetWidth(pcbnew.F_Cu))/2
            else:
                distance=point_segment_distance(hx,hy,xy(track.GetStart()),xy(track.GetEnd()))-pcbnew.ToMM(track.GetWidth())/2
            insist(distance+1e-5>=radius,f'Copper enters insulating-fastener envelope at {(hx,hy)}: {distance} mm')
        for fp in board.GetFootprints():
            for pad in fp.Pads():
                if pad.GetAttribute()==pcbnew.PAD_ATTRIB_NPTH:continue
                box=pad.GetBoundingBox();x1,y1=pcbnew.ToMM(box.GetX()),pcbnew.ToMM(box.GetY());x2,y2=pcbnew.ToMM(box.GetRight()),pcbnew.ToMM(box.GetBottom())
                distance=math.hypot(max(x1-hx,0,hx-x2),max(y1-hy,0,hy-y2))
                insist(distance+1e-5>=radius,f'Pad enters insulating-fastener envelope at {(hx,hy)}: {fp.GetReference()}.{pad.GetNumber()}')
        for zone in board.Zones():
            if zone.GetIsRuleArea():continue
            for layer in (pcbnew.F_Cu,pcbnew.B_Cu):
                if zone.IsOnLayer(layer):
                    insist(not zone.HitTestFilledArea(layer,hole.GetPosition(),pcbnew.FromMM(radius)),f'Filled copper enters fastener envelope at {(hx,hy)}')
    return {'mounting_holes_checked':len(holes),'fastener_copper_keepout_radius_mm':radius,'fastener_material':'Insulating; no grounded metal on collector board'}


def check(root):
    root = Path(root).resolve()
    verification = root / 'verification'
    spec = json.loads((verification / 'design_manifest.json').read_text())
    project = spec['project']
    kicad = root / 'kicad'
    settings = json.loads((kicad / (project + '.kicad_pro')).read_text())
    insist(not settings['board']['design_settings'].get('drc_exclusions'), 'DRC exclusions are forbidden')
    insist(not settings['erc'].get('erc_exclusions'), 'ERC exclusions are forbidden')
    subprocess.run(['kicad-cli', 'sch', 'erc', '--format', 'json', '--severity-all', '-o', str(verification / 'erc.json'), str(kicad / (project + '.kicad_sch'))], check=True)
    project_bytes = (kicad / (project + '.kicad_pro')).read_bytes()
    subprocess.run(['kicad-cli', 'pcb', 'drc', '--format', 'json', '--schematic-parity', '--severity-all', '--refill-zones', '--save-board', '-o', str(verification / 'drc.json'), str(kicad / (project + '.kicad_pcb'))], check=True)
    (kicad / (project + '.kicad_pro')).write_bytes(project_bytes)
    subprocess.run(['kicad-cli', 'sch', 'export', 'netlist', '--format', 'kicadxml', '-o', str(verification / 'detector.net.xml'), str(kicad / (project + '.kicad_sch'))], check=True)
    erc = json.loads((verification / 'erc.json').read_text())
    drc = json.loads((verification / 'drc.json').read_text())
    erc_issues = [issue for sheet in erc['sheets'] for issue in sheet['violations']]
    insist(not erc_issues, f'ERC violations: {erc_issues}')
    for group in ('violations', 'unconnected_items', 'schematic_parity'):
        insist(not drc[group], f'DRC {group}: {drc[group]}')
    native, pins = native_pin_nets(verification / 'detector.net.xml')
    board = pcbnew.LoadBoard(str(kicad / (project + '.kicad_pcb')))
    matched = verify_pins(spec, board, pins)
    geometry = verify_geometry(spec, board)
    geometry.update(verify_finishing_copper(spec,board))
    geometry.update(verify_mounting_clearance(spec,board))
    checked_files = [*sorted(kicad.glob('*.kicad_sch')), kicad / (project + '.kicad_pcb'), kicad / (project + '.kicad_pro')]
    if (kicad / (project + '.kicad_dru')).is_file():
        checked_files.append(kicad / (project + '.kicad_dru'))
    summary = {'status': 'PASS', 'project': project, 'revision': spec.get('revision'),
        'kicad': pcbnew.GetBuildVersion(), 'erc_violations': 0, 'drc_violations': 0,
        'unconnected': 0, 'schematic_parity': 0, 'pin_net_matches': len(matched),
        'schematic_sheets': len(native.findall('design/sheet')), 'footprints': len(list(board.GetFootprints())),
        **geometry, 'sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in checked_files},
        'spec_sha256': hashlib.sha256((verification / 'design_manifest.json').read_bytes()).hexdigest(),
        'limitations': ['Unbuilt engineering prototype', 'No measured leakage, noise, stability, current gain, or imaging resolution',
            'CAD clearances are design constraints, not an insulation certification; component ratings require separate review']}
    (verification / 'check-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    return summary


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('package', type=Path)
    args = parser.parse_args()
    print(json.dumps(check(args.package), indent=2))
