#!/usr/bin/env python3
"""Preview native CAD, or verify then export and package a prototype design."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile
import xml.etree.ElementTree as ET
from check import check


def run(*args):
    subprocess.run([str(a) for a in args],check=True)


def include(path):
    return path.is_file() and not any(x in {'__pycache__','.history'} or x.endswith('-backups') for x in path.parts) and path.suffix not in {'.kicad_prl','.lck','.pyc','.pyo'} and not path.name.startswith(('~','routing_partial','pre-route'))


def normalize_sheet_names(root,spec):
    """KiCad 10 names hierarchy SVGs by title; publish stable sheet-id paths."""
    output=Path(root)/'exports';project=spec['project']
    candidates={}
    for path in output.glob(project+'*.svg'):
        for item in ET.parse(path).getroot().iter():
            if item.tag.endswith('}desc') and (item.text or '').startswith('File: '):
                candidates.setdefault(item.text[6:],[]).append(path)
    for sheet in spec.get('sheets',[]):
        stem=project+'_'+sheet['id'];target=output/(stem+'.svg')
        matches=candidates.get(stem+'.kicad_sch',[])
        if not matches:raise RuntimeError('Missing native sheet SVG: '+stem)
        source=next((p for p in matches if p.name.startswith(project+'-')),matches[0])
        if source!=target:shutil.copyfile(source,target)


def export(root,previews_only=False):
    root=Path(root).resolve(); spec=json.loads((root/'verification/design_manifest.json').read_text()); project=spec['project']
    k=root/'kicad';e=root/'exports';f=root/'fabrication'
    e.mkdir(exist_ok=True);f.mkdir(exist_ok=True)
    if not previews_only:check(root)
    run('kicad-cli','sch','export','pdf','-o',e/'schematic.pdf',k/(project+'.kicad_sch'))
    run('kicad-cli','sch','export','svg','-o',str(e)+'/',k/(project+'.kicad_sch'))
    normalize_sheet_names(root,spec)
    shutil.copyfile(e/(project+'.svg'),e/'schematic.svg')
    run('pdftoppm','-f','1','-singlefile','-scale-to','2100','-png',e/'schematic.pdf',e/'schematic')
    for name,layers in [('board-top','F.Cu,F.SilkS,Edge.Cuts'),('board-bottom','B.Cu,B.SilkS,Edge.Cuts'),('assembly','F.Fab,F.SilkS,Edge.Cuts')]:
        run('kicad-cli','pcb','export','svg','--mode-single','--fit-page-to-board','--exclude-drawing-sheet','-l',layers,'-o',e/(name+'.svg'),k/(project+'.kicad_pcb'))
    run('kicad-cli','pcb','render','--width','1800','--height','1200','--side','top','--quality','high','-o',e/'board-top.png',k/(project+'.kicad_pcb'))
    run('kicad-cli','pcb','render','--width','1800','--height','1200','--rotate','325,0,20','--quality','high','-o',e/'board-isometric.png',k/(project+'.kicad_pcb'))
    if previews_only:return
    run('kicad-cli','pcb','export','gerbers','-l','F.Cu,B.Cu,F.Mask,B.Mask,F.SilkS,B.SilkS,Edge.Cuts','--check-zones','-o',str(f)+'/',k/(project+'.kicad_pcb'))
    run('kicad-cli','pcb','export','drill','--excellon-separate-th','--generate-map','--map-format','pdf','--generate-report','-o',str(f)+'/',k/(project+'.kicad_pcb'))
    run('kicad-cli','pcb','export','pos','--format','csv','--units','mm','--smd-only','-o',e/'pick-and-place.csv',k/(project+'.kicad_pcb'))
    return package(root,verify_previous_exports=False)


def package(root,verify_previous_exports=True):
    """Refresh archive documentation/tools only when native hashes still pass."""
    root=Path(root).resolve();spec_path=root/'verification/design_manifest.json'
    spec=json.loads(spec_path.read_text());project=spec['project'];f=root/'fabrication'
    summary=json.loads((root/'verification/check-summary.json').read_text())
    if summary['status']!='PASS' or hashlib.sha256(spec_path.read_bytes()).hexdigest()!=summary['spec_sha256']:
        raise RuntimeError('Cannot package a changed or unverified design specification')
    for name,digest in summary['sha256'].items():
        if hashlib.sha256((root/'kicad'/name).read_bytes()).hexdigest()!=digest:
            raise RuntimeError('Native design changed since verification: '+name)
    if verify_previous_exports:
        previous=json.loads((root/'manifest.json').read_text())
        for name,digest in previous['manufacturing_sha256'].items():
            if hashlib.sha256((f/name).read_bytes()).hexdigest()!=digest:
                raise RuntimeError('Manufacturing export changed: '+name)
    with zipfile.ZipFile(root/'fabrication.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for p in sorted(f.iterdir()):
            if include(p):archive.write(p,p.name)
        if (root/'FABRICATION.md').is_file():archive.write(root/'FABRICATION.md','FABRICATION.md')
    # Package a self-contained regeneration toolchain with this exact spec.
    tools=root/'tools';tools.mkdir(exist_ok=True)
    for name in ['cad.py','router.py','check.py','primitives.py','export.py','README.md']:
        source=Path(__file__).resolve().parent/name
        if source.resolve()!=(tools/name).resolve():shutil.copyfile(source,tools/name)
    (root/'design-spec.json').write_text(json.dumps(spec,indent=2)+'\n')
    files=[('detector-design.zip','Complete editable design'),('README.md','Wiring and commissioning'),('bom.csv','Exact component BOM'),
        ('exports/schematic.pdf','Complete schematic PDF'),('exports/board-top.png','Top PCB render'),('exports/board-isometric.png','PCB isometric'),
        ('exports/assembly.svg','Assembly drawing'),('fabrication.zip','Prototype Gerbers and drills'),('verification/check-summary.json','Native checks'),
        ('kicad/'+project+'.kicad_pro','Editable KiCad project')]
    for sheet in spec.get('sheets',[]):files.append(('exports/'+project+'_'+sheet['id']+'.svg',sheet['title']))
    for path,_ in files:
        if path!='detector-design.zip' and not (root/path).is_file():raise RuntimeError('Missing packaged deliverable: '+path)
    manifest={'project':project,'revision':spec.get('revision'),'status':'Unbuilt engineering prototype; native electrical and geometry checks passed',
        'boardPreview':'exports/board-top.png','boardIsometric':'exports/board-isometric.png',
        'files':[{'path':p,'label':label} for p,label in files],
        'manufacturing_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(f.iterdir()) if include(p)}}
    (root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(root/'detector-design.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for folder in ['kicad','tools','exports','verification','firmware']:
            if (root/folder).is_dir():
                for p in sorted((root/folder).rglob('*')):
                    if include(p):archive.write(p,p.relative_to(root))
        for name in ['README.md','POWER.md','FABRICATION.md','bom.csv','budget.csv','design-spec.json','manifest.json','fabrication.zip']:
            if (root/name).is_file():archive.write(root/name,name)
    return manifest


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('package',type=Path);parser.add_argument('--previews-only',action='store_true')
    parser.add_argument('--package-only',action='store_true',help='Refresh archive documents/tools after checking native and fabrication hashes')
    args=parser.parse_args()
    package(args.package) if args.package_only else export(args.package,args.previews_only)
