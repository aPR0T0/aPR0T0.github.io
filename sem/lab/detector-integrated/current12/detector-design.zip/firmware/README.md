# Specimen-current host firmware

This is the original ESP32_LMC662_scan sketch for the LMC662 / ADS1115 circuit. Use the separate DAC80502 scan board and its documented firmware/library setup. J3.1 connects to ESP32 GND, J3.3 SDA to GPIO21, J3.4 SCL to GPIO22; leave J3.2 ADC reference output and J3.5 RDY open with the polling sketch. Both host and detector must be powered while the direct I²C interface is connected. Use coordinated power; disconnect before independently power-cycling either side. Do not apply collector bias to this board.

The new onboard power layout has not been bench tested. Establish rail voltages, ADC scale, dark zero and settling before a beam measurement.

Full scan setup: https://apr0t0.github.io/sem/lab/scan.html
Original detector guide: https://apr0t0.github.io/sem/lab/current.html
