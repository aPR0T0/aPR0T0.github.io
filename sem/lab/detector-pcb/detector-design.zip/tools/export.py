#!/usr/bin/env python3
"""Verify and export KiCad artifacts, or repack checked files with --archives-only."""
from pathlib import Path
import subprocess,json,zipfile,shutil,hashlib,argparse
ROOT=Path(__file__).resolve().parents[1];NAME='lmc662_specimen_detector';K=ROOT/'kicad';E=ROOT/'exports';F=ROOT/'fabrication'
def run(*args):subprocess.run(args,check=True)

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--archives-only',action='store_true',help='Verify existing checked artifacts and repack the editable design ZIP without regenerating CAD, exports or fabrication files.')
args=parser.parse_args()

def include_in_archive(path):
    """Keep editable sources and checked outputs, excluding local CAD state."""
    relative=path.relative_to(ROOT)
    return (path.is_file()
            and not any(part in {'__pycache__','.history'} or part.endswith('-backups') for part in relative.parts)
            and path.suffix not in {'.kicad_prl','.lck','.pyc','.pyo'}
            and not path.name.startswith(('~','routing_partial'))
            and path.name not in {'.DS_Store','Thumbs.db'})

def verify_existing_artifacts():
    """Refuse to package stale CAD/fabrication checks; this path is read-only."""
    summary=json.loads((ROOT/'verification/check-summary.json').read_text())
    if summary.get('status') != 'PASS':
        raise RuntimeError('Existing CAD verification must pass before repackaging.')
    for name,expected in summary['sha256'].items():
        if hashlib.sha256((K/name).read_bytes()).hexdigest() != expected:
            raise RuntimeError('Stale CAD verification hash: '+name)
    manifest=json.loads((ROOT/'manifest.json').read_text())
    expected_files=manifest['manufacturing_sha256']
    actual_files={p.name for p in F.iterdir() if include_in_archive(p)}
    if actual_files != set(expected_files):
        raise RuntimeError('Manufacturing file list differs from the checked manifest.')
    for name,expected in expected_files.items():
        if hashlib.sha256((F/name).read_bytes()).hexdigest() != expected:
            raise RuntimeError('Stale manufacturing hash: '+name)
    expected_entries=set(expected_files)
    if (ROOT/'FABRICATION.md').is_file():
        expected_entries.add('FABRICATION.md')
    with zipfile.ZipFile(ROOT/'fabrication.zip') as archive:
        names=archive.namelist()
        if set(names) != expected_entries or len(names) != len(expected_entries):
            raise RuntimeError('Fabrication ZIP has missing, duplicate or unexpected members.')
        for name in names:
            path=ROOT/name if name == 'FABRICATION.md' else F/name
            if archive.read(name) != path.read_bytes():
                raise RuntimeError('Stale fabrication ZIP member: '+name)

if args.archives_only:
    verify_existing_artifacts()
else:
    run('/usr/bin/python3',str(ROOT/'tools/check.py'))
    run('kicad-cli','sch','export','pdf','-o',str(E/'schematic.pdf'),str(K/(NAME+'.kicad_sch')))
    run('kicad-cli','sch','export','svg','-o',str(E)+'/',str(K/(NAME+'.kicad_sch')))
    shutil.copyfile(E/(NAME+'.svg'),E/'schematic.svg')
    run('rsvg-convert','-w','2100','-o',str(E/'schematic.png'),str(E/'schematic.svg'))
    for name,layers in [('board-top','F.Cu,F.SilkS,Edge.Cuts'),('board-bottom','B.Cu,B.SilkS,Edge.Cuts'),('assembly','F.Fab,F.SilkS,Edge.Cuts')]:
     run('kicad-cli','pcb','export','svg','--mode-single','--fit-page-to-board','--exclude-drawing-sheet','-l',layers,'-o',str(E/(name+'.svg')),str(K/(NAME+'.kicad_pcb')))
    run('kicad-cli','pcb','render','--width','1600','--height','1100','--side','top','--quality','high','-o',str(E/'board-top.png'),str(K/(NAME+'.kicad_pcb')))
    run('kicad-cli','pcb','render','--width','1600','--height','1100','--rotate','325,0,20','--quality','high','-o',str(E/'board-isometric.png'),str(K/(NAME+'.kicad_pcb')))
    run('kicad-cli','pcb','export','gerbers','-l','F.Cu,B.Cu,F.Mask,B.Mask,F.SilkS,B.SilkS,Edge.Cuts','--check-zones','-o',str(F)+'/',str(K/(NAME+'.kicad_pcb')))
    run('kicad-cli','pcb','export','drill','--excellon-separate-th','--generate-map','--map-format','pdf','--generate-report','-o',str(F)+'/',str(K/(NAME+'.kicad_pcb')))
    run('kicad-cli','pcb','export','pos','--format','csv','--units','mm','--smd-only','-o',str(E/'pick-and-place.csv'),str(K/(NAME+'.kicad_pcb')))
    # Archive only checked manufacturing outputs, with explicit prototype status.
    files=sorted(p for p in F.iterdir() if include_in_archive(p))
    with zipfile.ZipFile(ROOT/'fabrication.zip','w',zipfile.ZIP_DEFLATED) as z:
     for p in files:z.write(p,p.name)
     if (ROOT/'FABRICATION.md').exists():z.write(ROOT/'FABRICATION.md','FABRICATION.md')
    manifest={'revision':'A0','status':'Unbuilt engineering prototype; electrical geometry checks passed','boardPreview':'exports/board-top.png','boardIsometric':'exports/board-isometric.png','files':[{'path':p,'label':label} for p,label in [('detector-design.zip','Complete editable design and verification archive'),('README.md','Assembly, wiring and commissioning guide'),('POWER.md','Clean battery supply wiring'),('bom.csv','Editable PCB bill of materials'),('budget.csv','Detector budget allowances'),('exports/schematic.svg','Zoomable schematic'),('exports/schematic.pdf','Schematic PDF'),('exports/board-top.svg','Top copper and silkscreen'),('exports/board-bottom.svg','Bottom copper'),('exports/assembly.svg','Assembly drawing'),('exports/board-isometric.png','3D board view'),('kicad/lmc662_specimen_detector.kicad_pro','KiCad project'),('kicad/lmc662_specimen_detector.kicad_sch','Editable KiCad schematic'),('kicad/lmc662_specimen_detector.kicad_pcb','Routed KiCad PCB'),('fabrication.zip','Checked Gerbers and drill archive'),('verification/check-summary.json','ERC, DRC, parity and mathematics checks')]],'manufacturing_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
    (ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(ROOT/'detector-design.zip','w',zipfile.ZIP_DEFLATED) as z:
 for directory in ['kicad','tools','exports','verification']:
  for p in sorted((ROOT/directory).rglob('*')):
   if include_in_archive(p):z.write(p,p.relative_to(ROOT))
 for name in ['README.md','POWER.md','FABRICATION.md','bom.csv','budget.csv','manifest.json','fabrication.zip']:z.write(ROOT/name,name)
print(('Design archive repacked; existing CAD and manufacturing files preserved.' if args.archives_only else 'Exports and archives ready.')+f' {len(z.namelist())} design entries.')
