#!/usr/bin/env python3
"""Reproducible, project-local generator; run /usr/bin/python3 tools/generate.py."""
from helpers import *
from types import SimpleNamespace
import csv,subprocess,sys,xml.etree.ElementTree as ET
SIZE=(88,60)
for d in [OUT,LIB,ROOT/'exports',ROOT/'fabrication',ROOT/'verification']: d.mkdir(exist_ok=True)
P=[]
def part(ref,value,symbol,footprint,nets,at,sch,angle=0,mpn='',purpose='',extras=None,datasheet=''):
 p=SimpleNamespace(ref=ref,value=value,symbol=symbol,footprint=footprint,nets={str(k):v for k,v in nets.items()},at=at,sch_at=sch,sch_angle=angle,mpn=mpn,manufacturer='',buy='',buy_alt='',purpose=purpose,extras=extras or {},datasheet=datasheet,sheet='main');P.append(p);return p
R='Resistor_SMD:R_0805_2012Metric';C='Capacitor_SMD:C_0805_2012Metric'
part('U1','LMC662AIM','DualOpAmp','Package_SO:SOIC-8_3.9x4.9mm_P1.27mm',{1:'TIA',2:'SUM',3:'AGND',4:'-5VA',5:'VBIAS',6:'INV',7:'ADC_DRIVE',8:'+5VA'},(28.475,25.175,0),(81.28,60.96),mpn='LMC662AIMX/NOPB',purpose='Dual CMOS TIA / attenuator; solder directly, no socket',datasheet='https://www.ti.com/lit/ds/symlink/lmc662.pdf',extras={'manual_wires':True})
part('R1','100M 1%','R','Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal',{1:'SUM',2:'TIA'},(22,24.54,90),(81.28,43.18),90,mpn='HVA05FA100M',purpose='100M axial 6x2.5mm body; tolerance calibrates',extras={'manual_wires':True})
part('C1','10p C0G','C','Capacitor_THT:C_Disc_D3.0mm_W1.6mm_P2.50mm',{1:'SUM',2:'TIA'},(18,24.54,90),(81.28,30.48),90,purpose='TIA stability, tau=1ms nominal; real input capacitance must be tested',extras={'manual_wires':True})
part('J1','SPECIMEN / SHIELD','Conn2','Connector_PinHeader_2.54mm:PinHeader_1x02_P2.54mm_Vertical',{1:'SUM',2:'AGND'},(10,24.54,0),(30.48,66.04),purpose='Direct solder PTFE coax preferred; 1 specimen, 2 shield/chamber',extras={'manual_wires':True})
# Conditioning stage: matched nominal ratios, baseline/gain measured at commissioning.
part('R2','40.2k 0.1%','R',R,{1:'TIA',2:'INV'},(41,26,0),(137.16,88.9),90,purpose='Attenuator input',extras={'manual_wires':True})
part('R3','10.0k 0.1%','R',R,{1:'INV',2:'ADC_DRIVE'},(41,22,0),(172.72,68.58),90,purpose='Attenuator feedback',extras={'manual_wires':True})
part('R4','15.0k 0.1%','R',R,{1:'+3V3',2:'VBIAS'},(40,34,0),(119.38,121.92),purpose='VBIAS upper divider')
part('R5','10.0k 0.1%','R',R,{1:'VBIAS',2:'AGND'},(35,37,0),(119.38,147.32),purpose='VBIAS lower divider')
part('C2','1u 10V X7R','C',C,{1:'VBIAS',2:'AGND'},(40,39,0),(137.16,147.32),purpose='Quiet 1.32V filter')
part('R6','1.00k 0.1%','R',R,{1:'+3V3',2:'VMID'},(57,32,0),(241.3,132.08),purpose='ADC midpoint divider upper / rail bleeder')
part('R7','1.00k 0.1%','R',R,{1:'VMID',2:'AGND'},(57,36,0),(241.3,157.48),purpose='ADC midpoint divider lower')
part('C3','10u 10V X7R','C',C,{1:'VMID',2:'AGND'},(62,36,0),(259.08,157.48),purpose='1.65V reference filter')
part('R8','820R','R',R,{1:'ADC_DRIVE',2:'AIN0'},(53,22,0),(220.98,60.96),90,purpose='ADC overload current limit; downstream of sensitive node')
part('C4','100n','C',C,{1:'AIN0',2:'AGND'},(58,25,0),(238.76,91.44),purpose='ADC local RC filter')
part('D1','BAT54S','BAT54S','Package_TO_SOT_SMD:SOT-23',{1:'AGND',2:'+3V3',3:'AIN0'},(57,17,0),(215.9,93.98),purpose='ADC-only Schottky clamp; never on SUM',mpn='BAT54S',extras={'field_at':(208.28,81.28)},datasheet='https://assets.nexperia.com/documents/data-sheet/BAT54S.pdf')
part('U2','ADS1115IDGS','ADC','Package_SO:TSSOP-10_3x3mm_P0.5mm',{1:'AGND',2:'RDY',3:'AGND',4:'AIN0',5:'VMID',6:'AGND',7:'AGND',8:'+3V3',9:'SDA',10:'SCL'},(68,24,0),(294.64,71.12),mpn='ADS1115IDGSR',extras={'field_at':(279.4,43.18)},purpose='Differential AIN0-AIN1; I2C0x48; PGA +/-256mV 128SPS defaults',datasheet='https://www.ti.com/lit/ds/symlink/ads1115.pdf')
part('R9','4.7k','R',R,{1:'+3V3',2:'SDA'},(72,34,0),(284.48,132.08),purpose='I2C pull-up')
part('R10','4.7k','R',R,{1:'+3V3',2:'SCL'},(78,34,0),(302.26,132.08),purpose='I2C pull-up')
part('R11','10k','R',R,{1:'+3V3',2:'RDY'},(72,38,0),(320.04,132.08),purpose='Optional ready open-drain pull-up')
part('C5','100n','C',C,{1:'+3V3',2:'AGND'},(73,26,0),(337.82,91.44),purpose='ADC local bypass')
part('C6','1u 10V','C',C,{1:'+3V3',2:'AGND'},(77,30,0),(355.6,91.44),purpose='ADC local bulk bypass')
part('J3','ESP32 I2C / REF','Conn5','Connector_PinHeader_2.54mm:PinHeader_1x05_P2.54mm_Vertical',{1:'AGND',2:'+3V3',3:'SDA',4:'SCL',5:'RDY'},(81,16,0),(381,137.16),purpose='1GND 2REF3V3OUT 3GPIO21 4GPIO22 5RDY optional (NC default); ESP powered separately')
# External clean bipolar source -> local ADC low-voltage regulator.
part('J2','CLEAN +/-5V','Conn3','Connector_PinHeader_2.54mm:PinHeader_1x03_P2.54mm_Vertical',{1:'+5VA',2:'AGND',3:'-5VA'},(12,44,0),(35.56,198.12),purpose='1+5V 2star0V 3-5V. 4.5..5.5V each; no HV')
part('U3','MCP1700-3302E/TO','LDO','Package_TO_SOT_THT:TO-92_Inline',{1:'AGND',2:'+5VA',3:'+3V3'},(60,46,180),(203.2,200.66),mpn='MCP1700-3302E/TO',extras={'field_at':(218.44,185.42)},purpose='3.3V ADC supply derived from +5V; max input6V',datasheet='https://www.microchip.com/content/dam/mchp/documents/APID/ProductDocuments/DataSheets/MCP1700-Data-Sheet-20001826F.pdf')
part('C7','1u 10V','C',C,{1:'+5VA',2:'AGND'},(52,43,0),(177.8,220.98),purpose='LDO input bypass')
part('C8','1u 10V','C',C,{1:'+3V3',2:'AGND'},(65,42,0),(228.6,220.98),purpose='LDO required output capacitor')
part('C9','100n','C',C,{1:'+5VA',2:'AGND'},(33,17,0),(78.74,220.98),purpose='LMC positive rail local bypass')
part('C10','100n','C',C,{1:'AGND',2:'-5VA'},(28,34,0),(101.6,220.98),purpose='LMC negative rail local bypass')
part('C11','10u 16V','CP','Capacitor_THT:CP_Radial_D5.0mm_P2.00mm',{1:'+5VA',2:'AGND'},(23,43,0),(129.54,198.12),purpose='Positive rail bulk; positive lead to+5V')
part('C12','10u 16V','CP','Capacitor_THT:CP_Radial_D5.0mm_P2.00mm',{1:'AGND',2:'-5VA'},(23,51,0),(129.54,228.6),purpose='Negative rail bulk; positive lead toAGND')
for ref,net,at,sch in [('TP1','TIA',(27,12,0),(101.6,99.06)),('TP2','ADC_DRIVE',(49,16,0),(195.58,48.26)),('TP3','VMID',(60,30,0),(276.86,157.48)),('TP4','AGND',(45,48,0),(259.08,220.98))]:
 part(ref,net,'TestPoint','TestPoint:TestPoint_THTPad_D2.0mm_Drill1.0mm', {1:net},at,sch,purpose='Low impedance measurement only')
for i,(x,y) in enumerate([(4,4),(84,4),(4,56),(84,56)],1):part('H'+str(i),'M3','MountingHole','MountingHole:MountingHole_3.2mm_M3',{},(x,y,0),(289.56+i*20.32,238.76),purpose='3.2mm unplated mounting hole')
# Local symbols, using explicit reviewed amplifier and ADC pin maps.
syms={}
for new,(lib,old) in {'R':('Device','R'),'C':('Device','C'),'CP':('Device','C_Polarized'),'BAT54S':('Diode','BAT54S'),'TestPoint':('Connector','TestPoint'),'MountingHole':('Mechanical','MountingHole'),'PWR_FLAG':('power','PWR_FLAG'),'LDO':('Regulator_Linear','MCP1700x-330xxTO')}.items():
 s=stock_symbol(lib,old);s[1]=new
 for sec in children(s,'symbol'):sec[1]=new+sec[1][len(old):]
 syms[new]=s
syms['DualOpAmp']=opamp_symbol('DualOpAmp',[(3,2,1),(5,6,7)],(8,4))
syms['ADC']=box_symbol('ADC',[(4,'AIN0','input'),(5,'AIN1','input'),(6,'AIN2','input'),(7,'AIN3','input'),(1,'ADDR','input')],[(8,'VDD','power_in'),(3,'GND','power_in'),(9,'SDA','bidirectional'),(10,'SCL','input'),(2,'ALERT_RDY','open_collector')],step=7.62)
for n in (2,3,5):syms['Conn'+str(n)]=box_symbol('Conn'+str(n),[(i,str(i),'passive') for i in range(1,n+1)],[],'J',width=3.81)
lib=[A('kicad_symbol_lib'),form('(version 20250114)'),form('(generator "kicad_symbol_editor")')]+list(syms.values())
(OUT/'Detector.kicad_sym').write_text(emit(lib)+'\n')
(OUT/'sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "Detector") (type "KiCad") (uri "${KIPRJMOD}/Detector.kicad_sym") (options "") (descr "Reviewed detector symbols")))\n')
for p in P:
 lib,name=p.footprint.split(':');src=SYS_FOOTPRINTS/(lib+'.pretty')/(name+'.kicad_mod');(LIB/(name+'.kicad_mod')).write_text(src.read_text().replace('${KICAD9_3DMODEL_DIR}','${KICAD10_3DMODEL_DIR}'))
for ref in ('R1','C1','J1'):
 p=next(p for p in P if p.ref==ref);path=LIB/(p.footprint.split(':')[-1]+'.kicad_mod');tree=parse(path.read_text())
 tree=[v for v in tree if not (isinstance(v,list) and v and v[0] in ('fp_line','fp_rect','fp_circle','fp_arc','fp_poly') and child(v,'layer') and child(v,'layer')[1]=='F.SilkS')]
 path.write_text(emit(tree)+'\n')
(OUT/'fp-lib-table').write_text('(fp_lib_table (version 7) (lib (name "Detector") (type "KiCad") (uri "${KIPRJMOD}/Detector.pretty") (options "") (descr "Local footprints")))\n')
sch=Schematic(PROJECT,'LMC662 specimen-current detector / Rev A0',syms)
sch.note('SPECIMEN CURRENT / LOW-VOLTAGE READOUT', (15.24,12.7),2.0)
sch.note('01  GUARDED TRANSIMPEDANCE', (15.24,17.78),1.5)
sch.note('02  ADC CONDITIONING', (116.84,17.78),1.5)
sch.note('03  DIFFERENTIAL ADC / ESP32', (241.3,17.78),1.5)
for p in P:
 if p.ref=='U1':
  sch.add_part(p,1,(81.28,60.96)); sch.add_part(p,2,(172.72,88.9)); sch.add_part(p,3,(83.82,187.96))
 else:sch.add_part(p)
# Hand wired TIA (real parallel feedback paths visible).
sch.wire([(24.13,63.5),(20.32,63.5),(20.32,81.28),(63.5,81.28),(63.5,63.5),(73.66,63.5)])
sch.label('SUM',(35.56,81.28));sch.wire([(24.13,68.58),(22.86,68.58),(22.86,91.44)]);sch.label('AGND',(22.86,91.44))
sch.wire([(73.66,58.42),(68.58,58.42)]);sch.label('AGND',(68.58,58.42),180)
sch.wire([(88.9,60.96),(101.6,60.96)]);sch.label('TIA',(101.6,60.96))
# Rotated R/C pin1 left, pin2 right in this orientation.
for yy,span in [(43.18,3.81),(30.48,3.81)]:
 sch.wire([(81.28-span,yy),(63.5,yy),(63.5,63.5)])
 sch.wire([(81.28+span,yy),(96.52,yy),(96.52,60.96)])
for pnt in [(63.5,43.18),(63.5,63.5),(96.52,43.18),(96.52,60.96)]:sch.items.append(f'(junction (at {xy(pnt)}) (diameter 0) (color 0 0 0 0) (uuid "{sch.ident("junction")}"))')
# U1B drawn feedback loop and input resistor.
sch.wire([(133.35,88.9),(124.46,88.9)]);sch.label('TIA',(124.46,88.9),180)
sch.wire([(140.97,88.9),(153.67,88.9),(153.67,91.44),(165.1,91.44)])
sch.wire([(168.91,68.58),(153.67,68.58),(153.67,88.9)])
sch.wire([(176.53,68.58),(187.96,68.58),(187.96,88.9),(180.34,88.9)])
sch.label('ADC_DRIVE',(187.96,88.9));sch.label('INV',(153.67,91.44))
for pnt in [(153.67,88.9),(187.96,88.9)]:sch.items.append(f'(junction (at {xy(pnt)}) (diameter 0) (color 0 0 0 0) (uuid "{sch.ident("junction")}"))')
# U1B and power unit label stubs; all passives carry named nets.
for unit,origin in [(2,(172.72,88.9)),(3,(83.82,187.96))]:
 for pin1 in symbol_pins(syms['DualOpAmp'],unit):
  n=child(pin1,'number')[1]
  if unit==2 and n in ('6','7'):continue
  pa=child(pin1,'at');pt=transform(float(pa[1]),float(pa[2]),origin,0);ang=float(pa[3]);end=(pt[0]-5.08*math.cos(math.radians(ang)),pt[1]+5.08*math.sin(math.radians(ang)));sch.wire([pt,end]);sch.label(P[0].nets[n],end,180 if ang==0 else 0)
sch.note('V_TIA = +I_abs R1 for net electron deposition\nR1 || C1: tau = 1ms, pole = 159Hz (nominal)\nGuard SUM on both sides at chamber 0V.\nNo clamp or test probe on picoampere node.',(15.24,111.76),1.15)
sch.note('V_A0 = 1.648358 - (10 / 40.2) V_TIA\nV_A1 = 1.650V nominal; dark-zero is mandatory.\nPGA +/-256mV: 0.3141pA per raw code at 100M.\nMeasure gain; this is not measured sensitivity.',(154.94,119.38),1.08)
sch.note('04  QUIET POWER / BYPASS', (15.24,172.72),1.5)
sch.note('J3: 1 GND, 2 REF3V3 OUT, 3 SDA/GPIO21,\n4 SCL/GPIO22, 5 RDY (leave unconnected by default).\nPower ESP32 separately; common ground.\nREF3V3 is not an ESP32 power output.',(289.56,177.8),1.15)
sch.note('J2 external clean +/-5V; each rail magnitude 4.5..5.5V.\nTwo floating regulated sources in series; midpoint = chamber ground.\nADC supply follows +5V via U3. Power and check rails before attaching specimen.',(15.24,248.92),1.1)
sch.note('UNBUILT PROTOTYPE - no measured leakage/noise/stability/resolution claim.\nSpecimen insulated from chamber mechanically, held near 0V by U1A.\nElectronics in shielded atmospheric box at feedthrough. NEVER connect to gun HV.',(200.66,248.92),1.1)
for i,(net,pos) in enumerate([('+5VA',(45.72,233.68)),('-5VA',(66.04,233.68)),('AGND',(86.36,233.68))],1):sch.power_flag(net,pos,i)
sch.save()
# Native netlist is the connectivity source for the board.
subprocess.run(['kicad-cli','sch','export','netlist','--format','kicadxml','-o',str(ROOT/'verification/detector.net.xml'),str(OUT/(PROJECT+'.kicad_sch'))],check=True)
if '--schematic-only' in sys.argv: sys.exit(0)
board=pcbnew.BOARD();board.SetCopperLayerCount(2);board.SetFileName(str(OUT/(PROJECT+'.kicad_pcb')))
settings=board.GetDesignSettings();settings.m_TrackMinWidth=pcbnew.FromMM(.18);settings.m_MinClearance=pcbnew.FromMM(.18);settings.m_CopperEdgeClearance=pcbnew.FromMM(.5);settings.SetBoardThickness(pcbnew.FromMM(1.6))
netnames=sorted({n for p in P for n in p.nets.values() if n}); nets={}
for idx,n in enumerate(netnames,1):ni=pcbnew.NETINFO_ITEM(board,n,idx);board.Add(ni);nets[n]=ni
for p in P:
 name=p.footprint.split(':')[-1];f=pcbnew.FootprintLoad(str(LIB),name);f.SetFPID(pcbnew.LIB_ID('Detector',name));f.SetReference(p.ref);f.SetValue(p.value);f.SetPosition(vec(*p.at[:2]));f.SetOrientationDegrees(p.at[2]);f.m_Uuid.Clone(pcbnew.KIID(uid('footprint:'+p.ref)));f.SetPath(pcbnew.KIID_PATH('/'+uid('root')+'/'+uid('symbol:'+p.ref+':1')));f.Value().SetVisible(False)
 for pad in f.Pads():
  if pad.GetNumber() and p.nets.get(pad.GetNumber()):pad.SetNet(nets[p.nets[pad.GetNumber()]])
 if p.ref.startswith('H'):f.SetAttributes(f.GetAttributes()|pcbnew.FP_EXCLUDE_FROM_BOM|pcbnew.FP_EXCLUDE_FROM_POS_FILES)
 for key,val in {'MPN':p.mpn,'Manufacturer':p.manufacturer,'Buy_Mouser':p.buy,'Buy_DigiKey':p.buy_alt,'Datasheet':p.datasheet,'Function':p.purpose}.items():
  f.SetField(key,val);f.GetField(key).SetVisible(False);f.GetField(key).SetLayer(pcbnew.F_Fab)
 board.Add(f)
for a,b in [((0,0),(88,0)),((88,0),(88,60)),((88,60),(0,60)),((0,60),(0,0))]:
 s=pcbnew.PCB_SHAPE();s.SetShape(pcbnew.SHAPE_T_SEGMENT);s.SetStart(vec(*a));s.SetEnd(vec(*b));s.SetLayer(pcbnew.Edge_Cuts);s.SetWidth(pcbnew.FromMM(.1));board.Add(s)
def seg(net,a,b,layer=pcbnew.F_Cu,width=.25):
 t=pcbnew.PCB_TRACK(board);t.SetStart(vec(*a));t.SetEnd(vec(*b));t.SetLayer(layer);t.SetWidth(pcbnew.FromMM(width));t.SetNet(nets[net]);board.Add(t)
# A compact, single straight summing node. Closed ground guard on both faces.
seg('SUM',(10,24.54),(26,24.54),width=.25)
for layer in (pcbnew.F_Cu,pcbnew.B_Cu):
 points=[(7.5,23.35),(24.4,23.35),(24.4,23.9),(27.6,23.9),(27.6,26.0),(7.5,26.0),(7.5,23.35)]
 for a,b in zip(points,points[1:]):seg('AGND',a,b,layer,width=.25)
 # Solder mask openings expose the guard copper; clean after assembly.
 for a,b in zip(points,points[1:]):
  s=pcbnew.PCB_SHAPE();s.SetShape(pcbnew.SHAPE_T_SEGMENT);s.SetStart(vec(*a));s.SetEnd(vec(*b));s.SetLayer(pcbnew.F_Mask if layer==pcbnew.F_Cu else pcbnew.B_Mask);s.SetWidth(pcbnew.FromMM(.4));board.Add(s)
seg('AGND',(26,25.81),(26,26),width=.25)
for pos in [(7.5,23.35),(27.6,26)]:
 v=pcbnew.PCB_VIA(board);v.SetPosition(vec(*pos));v.SetWidth(pcbnew.FromMM(.6));v.SetDrill(pcbnew.FromMM(.3));v.SetViaType(pcbnew.VIATYPE_THROUGH);v.SetLayerPair(pcbnew.F_Cu,pcbnew.B_Cu);v.SetNet(nets['AGND']);board.Add(v)
pcb_text(board,'SPECIMEN CURRENT / A0',44,5,1.5,width=.2)
pcb_text(board,'LMC662 + ADS1115 | UNBUILT',44,8,1.0)
pcb_text(board,'NO HIGH VOLTAGE',17,35,1.0)
pcb_text(board,'1 SIG / 2 SHIELD',12,20,.8)
for label,yy in [('+5',44),('0V',46.54),('-5',49.08)]:pcb_text(board,label,7,yy,.8)
pcb_text(board,'CLEAN +/-5V ONLY',34,56.5,.9)
pcb_text(board,'REF3V3 OUT ONLY',72,46.5,.8)
pcb_text(board,'J3 1:GND 2:REF 3:SDA 4:SCL 5:RDY',65,50,.8)
# Keep digital/supply copper off the input corridor; source routing honors guard copper.
pcbnew.SaveBoard(str(OUT/(PROJECT+'.kicad_pcb')),board)
project={'meta':{'filename':PROJECT+'.kicad_pro','version':3},'board':{'design_settings':{'meta':{'version':2},'drc_exclusions':[],'rules':{'min_clearance':.18,'min_track_width':.18,'min_copper_edge_clearance':.5,'min_hole_clearance':.2,'min_hole_to_hole':.2,'min_through_hole_diameter':.3,'min_via_diameter':.6,'min_via_annular_width':.15,'min_silk_clearance':.1,'min_text_height':.8,'min_text_thickness':.12,'min_resolved_spokes':2},'rule_severities':{'courtyards_overlap':'error','missing_courtyard':'warning','unconnected_items':'error','shorting_items':'error','clearance':'error','silk_overlap':'warning','silk_over_copper':'warning'}}},'erc':{'erc_exclusions':[],'meta':{'version':0}},'net_settings':{'meta':{'version':4},'classes':[{'name':'Default','clearance':.18,'track_width':.18,'via_diameter':.6,'via_drill':.3,'bus_width':12,'wire_width':6,'schematic_color':[0,0,0,0]}]},'text_variables':{'ASSEMBLY_STATUS':'UNBUILT PROTOTYPE'}}
(OUT/(PROJECT+'.kicad_pro')).write_text(json.dumps(project,indent=2)+'\n')
(ROOT/'verification/design_manifest.json').write_text(json.dumps({'project':PROJECT,'date':DATE,'board_mm':SIZE,'parts':[vars(p) for p in P]},indent=2)+'\n')
with (ROOT/'bom.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['Reference','Value','Quantity','MPN_or_procurement_spec','Footprint','Function','Datasheet'])
 for p in P:w.writerow([p.ref,p.value,1,p.mpn or p.value,p.footprint,p.purpose,p.datasheet])
print('Generated schematic and guarded board seed. Run tools/route_board.py --preserve-seed next.')
