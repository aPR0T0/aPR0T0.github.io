#!/usr/bin/env python3
"""Conservative two-layer grid router writing native KiCad track/via objects.

Uses real footprint pad coordinates and separate PGND/AGND routing regions.
All resulting geometry is checked again by KiCad DRC, which is authoritative.
This is a low-voltage PCB router; its spacing is not an HV insulation design.
"""

import argparse
from array import array
from collections import defaultdict
import heapq
import itertools
import json
import math
from pathlib import Path
import time

import pcbnew

BOARD_SIZE=(88,60)
PROJECT="lmc662_specimen_detector"

ROOT = Path(__file__).resolve().parents[1]
FILE = ROOT / "kicad" / (PROJECT + ".kicad_pcb")
GRID = .10
NX = round(BOARD_SIZE[0] / GRID) + 1
NY = round(BOARD_SIZE[1] / GRID) + 1
N = NX * NY
HARD = 1 << 62
CLEARANCE = .18
MARGIN = .025
VIA_DIAMETER = .6
VIA_DRILL = .3
WIDTHS = (.18, .25, .35, .5)
PRIMARY = set()
POWER={"+5VA","-5VA","+3V3"}
WIDTH={"+5VA":.25,"-5VA":.25,"+3V3":.25,"AGND":.25}
LAYERS = (pcbnew.F_Cu, pcbnew.B_Cu)


def vec(x, y):
    return pcbnew.VECTOR2I(pcbnew.FromMM(x), pcbnew.FromMM(y))


def mm(v):
    return pcbnew.ToMM(v)


def bounds(box):
    return mm(box.GetX()), mm(box.GetY()), mm(box.GetRight()), mm(box.GetBottom())


def overlaps(a, b, pad=0):
    return not (a[2]+pad < b[0] or b[2]+pad < a[0] or a[3]+pad < b[1] or b[3]+pad < a[1])


class Router:
    def __init__(self, board):
        self.board = board
        self.masks = {w: [array("Q", [0]) * N, array("Q", [0]) * N] for w in WIDTHS}
        self.via_masks = [array("Q", [0]) * N, array("Q", [0]) * N]
        self.via_pad_forbid = bytearray(N)
        self.via_hole_forbid = bytearray(N)
        self.via_positions = {}
        self.pads = defaultdict(list)
        self.net_codes = {}
        self.report = {}
        self.steps = [(1, 0, 10), (-1, 0, 10), (0, 1, 10), (0, -1, 10),
                      (1, 1, 14), (1, -1, 14), (-1, 1, 14), (-1, -1, 14)]
        self.draw_initial_obstacles()
        self.seed_obstacles()

    def seed_obstacles(self):
        # Honor hand-routed summing node and grounded guards on both faces.
        for t in self.board.GetTracks():
            code=t.GetNetCode();bit=1<<code
            if isinstance(t,pcbnew.PCB_VIA):
                x,y=mm(t.GetPosition().x),mm(t.GetPosition().y)
                radius=mm(t.GetWidth(pcbnew.F_Cu))/2
                for w,masks in self.masks.items():
                    ix=self.raster_capsule(x,y,x,y,radius+CLEARANCE+w/2+MARGIN)
                    for mask in masks:self.mark(mask,ix,bit)
                ix=self.raster_capsule(x,y,x,y,radius+CLEARANCE+VIA_DIAMETER/2+MARGIN)
                for mask in self.via_masks:self.mark(mask,ix,bit)
                self.via_positions[round(y/GRID)*NX+round(x/GRID)]=t.GetNetname()
            else:
                a,b=t.GetStart(),t.GetEnd();coords=(mm(a.x),mm(a.y),mm(b.x),mm(b.y));radius=mm(t.GetWidth())/2;layer=LAYERS.index(t.GetLayer())
                for w,masks in self.masks.items():self.mark(masks[layer],self.raster_capsule(*coords,radius+CLEARANCE+w/2+MARGIN),bit)
                self.mark(self.via_masks[layer],self.raster_capsule(*coords,radius+CLEARANCE+VIA_DIAMETER/2+MARGIN),bit)
        # SUM is already a single short line joining all four pads.
        self.pads.pop('SUM',None)
        self.pads['AGND'].append({'xy':(round(27.6/GRID),round(26/GRID)), 'real':(27.6,26), 'layers':[0,1], 'pin':'Guard.1'})

    @staticmethod
    def raster_rect(x1, y1, x2, y2, inflate):
        lo_x = max(0, math.ceil((x1-inflate)/GRID))
        hi_x = min(NX-1, math.floor((x2+inflate)/GRID))
        lo_y = max(0, math.ceil((y1-inflate)/GRID))
        hi_y = min(NY-1, math.floor((y2+inflate)/GRID))
        # Rectangular expansion deliberately overestimates rounded corners.
        return [y*NX+x for y in range(lo_y, hi_y+1) for x in range(lo_x, hi_x+1)]

    @staticmethod
    def raster_capsule(x1, y1, x2, y2, radius):
        lo_x = max(0, math.floor((min(x1, x2)-radius)/GRID))
        hi_x = min(NX-1, math.ceil((max(x1, x2)+radius)/GRID))
        lo_y = max(0, math.floor((min(y1, y2)-radius)/GRID))
        hi_y = min(NY-1, math.ceil((max(y1, y2)+radius)/GRID))
        dx, dy = x2-x1, y2-y1
        l2 = dx*dx + dy*dy
        r2 = radius*radius
        out = []
        for y in range(lo_y, hi_y+1):
            yy = y*GRID
            for x in range(lo_x, hi_x+1):
                xx = x*GRID
                t = max(0., min(1., ((xx-x1)*dx + (yy-y1)*dy)/l2)) if l2 else 0.
                if (xx-x1-t*dx)**2 + (yy-y1-t*dy)**2 <= r2:
                    out.append(y*NX+x)
        return out

    @staticmethod
    def mark(mask, indices, value):
        for i in indices:
            mask[i] |= value

    def draw_initial_obstacles(self):
        for width, masks in self.masks.items():
            inset = .5 + width/2 + MARGIN
            for masks1 in masks:
                for y in range(NY):
                    for x in range(NX):
                        if min(x*GRID, y*GRID, BOARD_SIZE[0]-x*GRID, BOARD_SIZE[1]-y*GRID) < inset:
                            masks1[y*NX+x] |= HARD
        for footprint in self.board.GetFootprints():
            for pad in footprint.Pads():
                net = pad.GetNetname()
                code = pad.GetNetCode()
                if code >= 62:
                    raise ValueError("Router bitset supports fewer than 62 named nets")
                bit = (1 << code) if code else HARD
                box = bounds(pad.GetBoundingBox())
                pad_layers = [i for i, layer in enumerate(LAYERS) if pad.IsOnLayer(layer)]
                if pad.GetAttribute() == pcbnew.PAD_ATTRIB_NPTH:
                    cx, cy = mm(pad.GetPosition().x), mm(pad.GetPosition().y)
                    # M3 washer keepout: 3.2 mm radius, not just the 1.6 mm hole.
                    box = (cx-3.2, cy-3.2, cx+3.2, cy+3.2)
                    bit, pad_layers = HARD, [0, 1]
                for width, masks in self.masks.items():
                    indices = self.raster_rect(*box, CLEARANCE+width/2+MARGIN)
                    for layer in pad_layers:
                        self.mark(masks[layer], indices, bit)
                indices = self.raster_rect(*box, CLEARANCE+VIA_DIAMETER/2+MARGIN)
                for layer in pad_layers:
                    self.mark(self.via_masks[layer], indices, bit)
                # Never make via-in-pad, including on the same net.
                for i in self.raster_rect(*box, VIA_DIAMETER/2+.15):
                    self.via_pad_forbid[i] = 1
                if net and not net.startswith("unconnected-"):
                    self.net_codes[net] = code
                    pos = pad.GetPosition()
                    x, y = round(mm(pos.x)/GRID), round(mm(pos.y)/GRID)
                    self.pads[net].append({"xy": (x, y), "real": (mm(pos.x), mm(pos.y)),
                                           "layers": pad_layers, "pin": footprint.GetReference()+"."+pad.GetNumber()})
        # Avoid drilling through fixed functional legends. References will be
        # placed anew after routing, so they do not constrain the copper.
        for item in self.board.GetDrawings():
            if isinstance(item, pcbnew.PCB_TEXT) and item.GetLayer() == pcbnew.F_SilkS:
                for i in self.raster_rect(*bounds(item.GetBoundingBox()), .65):
                    self.via_pad_forbid[i] = 1

    def add_segment(self, net, a, b, layer, width):
        if math.dist(a, b) < 1e-7:
            return
        t = pcbnew.PCB_TRACK(self.board)
        t.SetStart(vec(*a))
        t.SetEnd(vec(*b))
        t.SetWidth(pcbnew.FromMM(width))
        t.SetLayer(LAYERS[layer])
        t.SetNetCode(self.net_codes[net])
        self.board.Add(t)
        bit = 1 << self.net_codes[net]
        for req_width, masks in self.masks.items():
            indices = self.raster_capsule(*a, *b, width/2+CLEARANCE+req_width/2+MARGIN)
            self.mark(masks[layer], indices, bit)
        indices = self.raster_capsule(*a, *b, width/2+CLEARANCE+VIA_DIAMETER/2+MARGIN)
        self.mark(self.via_masks[layer], indices, bit)
        self.report[net]["length_mm"] += math.dist(a, b)
        self.report[net]["segments"] += 1

    def add_via(self, net, x, y):
        i = y*NX+x
        if i in self.via_positions:
            assert self.via_positions[i] == net
            return
        v = pcbnew.PCB_VIA(self.board)
        v.SetPosition(vec(x*GRID, y*GRID))
        v.SetWidth(pcbnew.FromMM(VIA_DIAMETER))
        v.SetDrill(pcbnew.FromMM(VIA_DRILL))
        v.SetViaType(pcbnew.VIATYPE_THROUGH)
        v.SetLayerPair(pcbnew.F_Cu, pcbnew.B_Cu)
        v.SetNetCode(self.net_codes[net])
        self.board.Add(v)
        bit = 1 << self.net_codes[net]
        for req_width, masks in self.masks.items():
            indices = self.raster_capsule(x*GRID, y*GRID, x*GRID, y*GRID, VIA_DIAMETER/2+CLEARANCE+req_width/2+MARGIN)
            for mask in masks:
                self.mark(mask, indices, bit)
        indices = self.raster_capsule(x*GRID, y*GRID, x*GRID, y*GRID, VIA_DIAMETER+CLEARANCE+MARGIN)
        for mask in self.via_masks:
            self.mark(mask, indices, bit)
        for p in self.raster_capsule(x*GRID, y*GRID, x*GRID, y*GRID, VIA_DRILL+.25+MARGIN):
            self.via_hole_forbid[p] = 1
        self.via_positions[i] = net
        self.report[net]["vias"] += 1

    def search(self, net, start, goal):
        width = WIDTH.get(net, .18)
        masks = self.masks[width]
        foreign = ((1 << 63)-1) ^ (1 << self.net_codes[net])
        gx, gy = goal["xy"]
        sx, sy = start["xy"]
        lo_x, hi_x = (5, NX-6)
        goals = {layer*N + gy*NX+gx for layer in goal["layers"]}
        via0, via1 = self.via_masks
        seq = itertools.count()
        best, parent, heap = {}, {}, []

        def h(x, y):
            dx, dy = abs(x-gx), abs(y-gy)
            return 10*max(dx, dy)+4*min(dx, dy)

        for layer in start["layers"]:
            i = sy*NX+sx
            if masks[layer][i] & foreign:
                continue
            state = layer*N+i
            best[state] = 0
            heapq.heappush(heap, (h(sx, sy), next(seq), 0, state))
        visited = 0
        while heap:
            _, _, cost, state = heapq.heappop(heap)
            if best.get(state) != cost:
                continue
            if state in goals:
                path = [state]
                while state in parent:
                    state = parent[state]
                    path.append(state)
                path.reverse()
                return [(s//N, (s % N) % NX, (s % N)//NX) for s in path], visited
            layer, index = divmod(state, N)
            y, x = divmod(index, NX)
            mask = masks[layer]
            visited += 1
            for dx, dy, dcost in self.steps:
                xx, yy = x+dx, y+dy
                if not lo_x <= xx <= hi_x or not 4 <= yy < NY-4:
                    continue
                i2 = yy*NX+xx
                if mask[i2] & foreign:
                    continue
                # Do not cut a diagonal across the corner of an obstacle.
                if dx and dy and ((mask[y*NX+xx] & foreign) or (mask[yy*NX+x] & foreign)):
                    continue
                nxt = layer*N+i2
                # Prefer the front for signal copper, leaving more back-plane
                # continuity. Ground trees prefer the back copper.
                penalty = (1 if layer else 0) if net not in ("AGND", "PGND") else (0 if layer else 1)
                nc = cost+dcost+penalty
                if nc < best.get(nxt, 1e15):
                    best[nxt] = nc
                    parent[nxt] = state
                    heapq.heappush(heap, (nc+h(xx, yy), next(seq), nc, nxt))
            reuse = self.via_positions.get(index) == net
            if (reuse or (not self.via_pad_forbid[index] and not self.via_hole_forbid[index])) and not ((via0[index] | via1[index]) & foreign):
                nxt = (1-layer)*N+index
                nc = cost+(0 if reuse else 140)
                if nc < best.get(nxt, 1e15):
                    best[nxt] = nc
                    parent[nxt] = state
                    heapq.heappush(heap, (nc+h(x, y), next(seq), nc, nxt))
        raise RuntimeError(f"No route for {net}: {start['pin']} -> {goal['pin']} ({visited} states). Adjust placement or routing order.")

    def commit_path(self, net, start, goal, path):
        width = WIDTH.get(net, .18)
        self.add_segment(net, start["real"], (path[0][1]*GRID, path[0][2]*GRID), path[0][0], width)
        anchor = path[0]
        previous = path[0]
        last_direction = None
        for point in path[1:]:
            direction = (point[0]-previous[0], point[1]-previous[1], point[2]-previous[2])
            if point[0] != previous[0]:
                self.add_segment(net, (anchor[1]*GRID, anchor[2]*GRID), (previous[1]*GRID, previous[2]*GRID), previous[0], width)
                self.add_via(net, point[1], point[2])
                anchor = point
                last_direction = None
            elif last_direction is not None and direction != last_direction:
                self.add_segment(net, (anchor[1]*GRID, anchor[2]*GRID), (previous[1]*GRID, previous[2]*GRID), previous[0], width)
                anchor = previous
            previous = point
            last_direction = direction if direction[0] == 0 else None
        self.add_segment(net, (anchor[1]*GRID, anchor[2]*GRID), (previous[1]*GRID, previous[2]*GRID), previous[0], width)
        self.add_segment(net, (previous[1]*GRID, previous[2]*GRID), goal["real"], previous[0], width)

    def route_net(self, net):
        pads = self.pads[net]
        self.report.setdefault(net, {"pads": len(pads), "width_mm": WIDTH.get(net, .18), "length_mm": 0., "vias": 0, "segments": 0})
        connected = [pads[0]]
        remaining = list(pads[1:])
        states = 0
        while remaining:
            _, ni, ci = min((math.dist(p["xy"], q["xy"]), i, j)
                            for i, p in enumerate(remaining) for j, q in enumerate(connected))
            start, goal = remaining.pop(ni), connected[ci]
            path, visited = self.search(net, start, goal)
            self.commit_path(net, start, goal, path)
            states += visited
            connected.append(start)
        self.report[net]["length_mm"] = round(self.report[net]["length_mm"], 3)
        print(f"{net:16s} {len(pads):2d} pads  {self.report[net]['length_mm']:7.1f} mm  {self.report[net]['vias']:2d} vias  {states:7d} search states", flush=True)

    def run(self):
        self.fanout_ics()
        def order(net):
            if net in ("AGND", "PGND"):
                return (4, len(self.pads[net]), net)
            if net in ("SUM", "TIA", "INV", "VBIAS"):
                return (0, len(self.pads[net]), net)
            if net in POWER or net in ("+5VA", "COIL_LOW"):
                return (1, len(self.pads[net]), net)
            return (2, len(self.pads[net]), net)
        for net in sorted(self.pads, key=order):
            self.route_net(net)
        return self.report

    def fanout_ics(self):
        """Give IC pads an accessible two-layer anchor before long routes.

        This prevents an early long track from enclosing a later op-amp input
        in the narrow channel between adjacent SOIC pins and local bypasses.
        Vias are outside solder pads; adjacent same-net pins can share a via.
        """
        groups = []
        for net, pads in self.pads.items():
            self.report.setdefault(net, {"pads": len(pads), "width_mm": WIDTH.get(net, .18), "length_mm": 0., "vias": 0, "segments": 0})
            for pad in pads:
                ref, number = pad["pin"].split(".")
                is_ic = ref in ("U2",)
                is_smd_ground = net in ("AGND", "PGND") and len(pad["layers"]) == 1
                if is_ic:
                    groups.append((0 if is_ic else 1, ref, int(number), net, pad))
        for _, ref, number, net, pad in sorted(groups):
            foreign = ((1 << 63)-1) ^ (1 << self.net_codes[net])
            sx, sy = pad["xy"]
            lo_x, hi_x = (5, NX-6)
            candidates = []
            # Prefer sharing an existing short feedback/power-ground anchor.
            for i, vnet in self.via_positions.items():
                y, x = divmod(i, NX)
                d = math.hypot(x-sx, y-sy)
                if vnet == net and d <= 18:
                    candidates.append((d*.7, x, y, True))
            for radius in range(3, 29):
                for dx, dy in itertools.product(range(-radius, radius+1), repeat=2):
                    if max(abs(dx), abs(dy)) != radius:
                        continue
                    x, y = sx+dx, sy+dy
                    if not lo_x <= x <= hi_x or not 5 <= y < NY-5:
                        continue
                    i = y*NX+x
                    if self.via_pad_forbid[i] or self.via_hole_forbid[i]:
                        continue
                    if (self.via_masks[0][i] | self.via_masks[1][i]) & foreign:
                        continue
                    # Mainly horizontal fanout keeps the closely pitched pads
                    # from crossing each other's escape tracks.
                    candidates.append((math.hypot(dx, dy)+abs(dy)*.45, x, y, False))
                if len(candidates) > 40:
                    break
            found = False
            for _, x, y, reuse in sorted(candidates):
                goal = {"xy": (x, y), "real": (x*GRID, y*GRID),
                        "layers": [0, 1] if reuse else [0], "pin": "fanout"}
                try:
                    path, _ = self.search(net, pad, goal)
                except RuntimeError:
                    continue
                self.commit_path(net, pad, goal, path)
                self.add_via(net, x, y)
                pad["xy"] = (x, y)
                pad["real"] = (x*GRID, y*GRID)
                pad["layers"] = [0, 1]
                found = True
                break
            if not found:
                raise RuntimeError(f"No local fanout for {ref}.{number} ({net})")
        print(f"IC/ground escape routing complete: {len(self.via_positions)} shared/non-VIP vias", flush=True)


def add_zones(board):
    # A full connection on header return pads avoids a one-spoke sliver
    # between the neighboring signal pads. This is an intentional local
    # override; other through-hole pads retain ordinary thermal relief.
    for f in board.GetFootprints():
        if f.GetReference() in ("J4", "J5"):
            for p in f.Pads():
                if p.GetNetname() == "AGND":
                    p.SetLocalZoneConnection(pcbnew.ZONE_CONNECTION_FULL)
    # Each return gets a front and back pour. They never meet on this board.
    for net, x1, x2 in [("AGND", 36, BOARD_SIZE[0]-.7)]:
        n = board.FindNet(net)
        for layer in LAYERS:
            z = pcbnew.ZONE(board)
            z.SetLayer(layer)
            z.SetNetCode(n.GetNetCode())
            z.SetLocalClearance(pcbnew.FromMM(.3))
            z.SetThermalReliefGap(pcbnew.FromMM(.3))
            z.SetThermalReliefSpokeWidth(pcbnew.FromMM(.3))
            z.SetPadConnection(pcbnew.ZONE_CONNECTION_THERMAL)
            z.SetMinThickness(pcbnew.FromMM(.25))
            z.SetIslandRemovalMode(pcbnew.ISLAND_REMOVAL_MODE_ALWAYS)
            poly = z.Outline()
            poly.NewOutline()
            for x, y in [(x1, .7), (x2, .7), (x2, BOARD_SIZE[1]-.7), (x1, BOARD_SIZE[1]-.7)]:
                poly.Append(int(pcbnew.FromMM(x)), int(pcbnew.FromMM(y)))
            # Keep the same M3 washer clearance as the trace router.
            for f in board.GetFootprints():
                if f.GetReference().startswith("H"):
                    x, y = mm(f.GetPosition().x), mm(f.GetPosition().y)
                    if x1 < x < x2:
                        hole_index = poly.NewHole(0)
                        for a in range(0, 360, 15):
                            xx = x+3.35*math.cos(math.radians(a))
                            yy = y+3.35*math.sin(math.radians(a))
                            poly.Append(int(pcbnew.FromMM(xx)), int(pcbnew.FromMM(yy)), 0, hole_index)
            board.Add(z)
    filler = pcbnew.ZONE_FILLER(board)
    filler.Fill(board.Zones())


def place_reference_labels(board):
    """Keep all reference designators visible and clear of bodies/pads/text."""
    fixed = []
    for item in board.GetDrawings():
        if item.GetLayer() in (pcbnew.F_SilkS,pcbnew.F_Mask):
            fixed.append(bounds(item.GetBoundingBox()))
    bodies = [bounds(f.GetBoundingBox(False, False)) for f in board.GetFootprints()]
    # Avoid holes in the mask from vias when printing references.
    for track in board.GetTracks():
        if isinstance(track, pcbnew.PCB_VIA):
            x, y = mm(track.GetPosition().x), mm(track.GetPosition().y)
            r = mm(track.GetWidth(pcbnew.F_Cu))/2+.15
            fixed.append((x-r, y-r, x+r, y+r))
    for fp in sorted(board.GetFootprints(), key=lambda f: (0 if f.GetReference().startswith(("U", "K", "J", "RV")) else 1, f.GetReference())):
        ref = fp.Reference()
        ref.SetTextAngle(pcbnew.EDA_ANGLE(0, pcbnew.DEGREES_T))
        ref.SetTextSize(vec(.8, .8))
        ref.SetTextThickness(pcbnew.FromMM(.13))
        ref.SetVisible(True)
        b = bounds(fp.GetBoundingBox(False, False))
        cx, cy = (b[0]+b[2])/2, (b[1]+b[3])/2
        tw = max(1.4, len(ref.GetText())*.8)
        candidates = []
        for d in [.8, 1.3, 1.8, 2.4, 3.0, 4.0, 5.0]:
            for dx in [0, -1.5, 1.5, -3.0, 3.0]:
                candidates.extend([(cx+dx, b[1]-d), (cx+dx, b[3]+d)])
            candidates.extend([(b[0]-tw/2-d, cy), (b[2]+tw/2+d, cy)])
        placed = False
        for x, y in candidates:
            ref.SetPosition(vec(x, y))
            box = bounds(ref.GetBoundingBox())
            if min(box[0], box[1]) < .6 or box[2] > BOARD_SIZE[0]-.6 or box[3] > BOARD_SIZE[1]-.6:
                continue
            if any(overlaps(box, obstacle, .15) for obstacle in bodies+fixed):
                continue
            fixed.append(box)
            placed = True
            break
        if not placed:
            raise RuntimeError("No clear silkscreen reference location for " + fp.GetReference())


def remove_unused_fanout_vias(board):
    """Remove temporary escape vias that final routing only used on one side."""
    tracks = [t for t in board.GetTracks() if not isinstance(t, pcbnew.PCB_VIA)]
    removed = 0
    for v in list(board.GetTracks()):
        if not isinstance(v, pcbnew.PCB_VIA) or v.GetNetname() in ("AGND", "PGND"):
            continue
        p = v.GetPosition()
        layers = {t.GetLayer() for t in tracks if t.GetNetCode() == v.GetNetCode()
                  and (t.GetStart() == p or t.GetEnd() == p)}
        if len(layers) < 2:
            board.Remove(v)
            removed += 1
    return removed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reroute", action="store_true")
    parser.add_argument("--preserve-seed",action="store_true")
    parser.add_argument("--finish-only", action="store_true", help="Only add pours/position reference labels to existing routing")
    parser.add_argument("--no-zones", action="store_true")
    args = parser.parse_args()
    board = pcbnew.LoadBoard(str(FILE))
    if not args.finish_only:
        if list(board.GetTracks()) and not args.reroute and not args.preserve_seed:
            raise SystemExit("Board already has routing. Use --reroute deliberately or --finish-only.")
        if args.reroute:
            for item in list(board.GetTracks()) + list(board.Zones()):
                board.Remove(item)
        started = time.monotonic()
        router = Router(board)
        try:
            report = router.run()
        except Exception:
            pcbnew.SaveBoard(str(ROOT / "verification/routing_partial.kicad_pcb"), board)
            raise
        pcbnew.SaveBoard(str(FILE), board)
        (ROOT / "verification/routing.json").write_text(json.dumps({"grid_mm": GRID, "clearance_mm": CLEARANCE,
            "via_diameter_mm": VIA_DIAMETER, "via_drill_mm": VIA_DRILL,
            "seconds": round(time.monotonic()-started, 3), "nets": report}, indent=2) + "\n")
    removed = remove_unused_fanout_vias(board)
    if not args.no_zones:
        for zone in list(board.Zones()):
            board.Remove(zone)
        add_zones(board)
    place_reference_labels(board)
    pcbnew.SaveBoard(str(FILE), board)
    if "(pts)" in FILE.read_text():
        raise RuntimeError("Empty polygon contour in generated board")
    report_path = ROOT / "verification/routing.json"
    if report_path.exists():
        data = json.loads(report_path.read_text())
        counts = defaultdict(int)
        for t in board.GetTracks():
            if isinstance(t, pcbnew.PCB_VIA):
                counts[t.GetNetname()] += 1
        data["removed_unused_fanout_vias"] = removed
        for net, info in data["nets"].items():
            info["vias"] = counts[net]
        report_path.write_text(json.dumps(data, indent=2) + "\n")
    print("Saved native routed PCB. Run KiCad DRC and the independent connectivity audit.")


if __name__ == "__main__":
    main()
