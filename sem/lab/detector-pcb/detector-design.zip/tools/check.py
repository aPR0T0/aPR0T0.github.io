#!/usr/bin/env python3
"""Independent native-netlist, PCB-net and mathematical checks; no exclusions."""
from pathlib import Path
import json,math,hashlib,subprocess,xml.etree.ElementTree as ET
import pcbnew
ROOT=Path(__file__).resolve().parents[1];NAME='lmc662_specimen_detector';K=ROOT/'kicad';V=ROOT/'verification'
subprocess.run(['kicad-cli','sch','erc','--format','json','-o',str(V/'erc.json'),str(K/(NAME+'.kicad_sch'))],check=True)
subprocess.run(['kicad-cli','pcb','drc','--format','json','--schematic-parity','-o',str(V/'drc.json'),str(K/(NAME+'.kicad_pcb'))],check=True)
subprocess.run(['kicad-cli','sch','export','netlist','--format','kicadxml','-o',str(V/'detector.net.xml'),str(K/(NAME+'.kicad_sch'))],check=True)
erc=json.loads((V/'erc.json').read_text());drc=json.loads((V/'drc.json').read_text())
ercv=[v for s in erc['sheets'] for v in s['violations']]
assert not ercv,ercv
for k in ('violations','unconnected_items','schematic_parity'):assert not drc[k],drc[k]
man=json.loads((V/'design_manifest.json').read_text())
expected={(p['ref'],k):n for p in man['parts'] for k,n in p['nets'].items()}
actual={}
for n in ET.parse(V/'detector.net.xml').findall('nets/net'):
 for a in n.findall('node'):
  if not a.get('ref').startswith('#'):actual[(a.get('ref'),a.get('pin'))]=n.get('name')
assert expected==actual,(expected,actual)
b=pcbnew.LoadBoard(str(K/(NAME+'.kicad_pcb')))
board={(f.GetReference(),p.GetNumber()):p.GetNetname() for f in b.GetFootprints() for p in f.Pads() if p.GetNumber()}
assert expected==board,(expected,board)
# Explicit IC pin audit, independent of generation helpers.
pins={'U1':['TIA','SUM','AGND','-5VA','VBIAS','INV','ADC_DRIVE','+5VA'],'U2':['AGND','RDY','AGND','AIN0','VMID','AGND','AGND','+3V3','SDA','SCL'],'U3':['AGND','+5VA','+3V3'],'D1':['AGND','+3V3','AIN0']}
for ref,names in pins.items():
 for i,n in enumerate(names,1):assert board[(ref,str(i))]==n,(ref,i,n)
sumtracks=[t for t in b.GetTracks() if t.GetNetname()=='SUM'];assert len(sumtracks)==1
assert abs(pcbnew.ToMM(sumtracks[0].GetLength())-16)<1e-6
assert sumtracks[0].GetLayer()==pcbnew.F_Cu
assert all(not isinstance(t,pcbnew.PCB_VIA) for t in sumtracks)
assert sorted(k for k,n in board.items() if n=='SUM')==[('C1','1'),('J1','1'),('R1','1'),('U1','2')]
# No zones under input or amplifier. Guard routing is the deliberate exception.
for z in b.Zones():assert pcbnew.ToMM(z.GetBoundingBox().GetX())>=35.99
alpha=10000/40200;rf=100e6;cf=10e-12;vplus=3.3*10000/25000;vmid=3.3/2
zero=(1+alpha)*vplus-vmid
checks={'attenuation':alpha,'adc_zero_V':zero,'TIA_tau_s':rf*cf,'feedback_pole_Hz':1/(2*math.pi*rf*cf),'PGA256mV_LSB_pA':.256/32768/(alpha*rf)*1e12,'ADC_A0_for_TIA_minus5p5_V':(1+alpha)*vplus+alpha*5.5,'ADC_A0_for_TIA_plus5p5_V':(1+alpha)*vplus-alpha*5.5,'ideal_positive_current_span_nA':(.256+zero)/(alpha*rf)*1e9}
assert 0<checks['ADC_A0_for_TIA_plus5p5_V']<checks['ADC_A0_for_TIA_minus5p5_V']<3.3
assert abs(checks['PGA256mV_LSB_pA']-.3140625)<1e-9
report={'status':'PASS','date':'2026-09-11','kicad':pcbnew.GetBuildVersion(),'erc_violations':len(ercv),'drc_violations':len(drc['violations']),'unconnected':len(drc['unconnected_items']),'schematic_parity':len(drc['schematic_parity']),'pin_net_matches':len(board),'footprints':len(list(b.GetFootprints())),'tracks':len([t for t in b.GetTracks() if not isinstance(t,pcbnew.PCB_VIA)]),'vias':len([t for t in b.GetTracks() if isinstance(t,pcbnew.PCB_VIA)]),'math':checks,'sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [K/(NAME+'.kicad_sch'),K/(NAME+'.kicad_pcb')]},'limitations':['No hardware fabricated or tested','No measured input leakage, noise, stability, settling, gain or imaging resolution','LMC662 / ADS1115 models are design calculations, not a transistor-level circuit simulation']}
(V/'check-summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
