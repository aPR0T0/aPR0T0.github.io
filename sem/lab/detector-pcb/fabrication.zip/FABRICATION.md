# Fabrication notes — detector A0

Unbuilt prototype. These files passed the archived KiCad 10 ERC, PCB DRC, unconnected-net and schematic-parity checks. They are not evidence of measured detector performance.

- Board: 88 × 60 mm; 2 copper layers; 1.6 mm FR-4; 35 µm copper.
- Minimum track / clearance: 0.18 / 0.18 mm.
- Vias: 0.60 mm pad, 0.30 mm finished drill; ordinary through vias.
- Four 3.20 mm NPTH mounting holes; keep mounting hardware off copper.
- Use the separate PTH and NPTH Excellon drill files. No blind/buried vias.
- Solder mask on both faces with the supplied deliberate guard-ring openings. Do not automatically cover those exposed ground guards.
- The input area intentionally has no general copper plane and reduced body silkscreen; reference labels and assembly drawing identify parts.
- ENIG is preferred for the exposed guard and fine-pitch assembly; lead-free HASL can be evaluated for a low-cost hand-built prototype.
- Final assembly requires low-residue processing followed by thorough cleaning/drying, especially around J1, R1, C1 and U1 input pins.
- Confirm the actual C1 lead pitch and body envelope before ordering/assembly. Do not substitute an ADS1115 breakout or DIP LMC662 into these footprints.

The archive contains seven Gerber layers and separate PTH/NPTH drills; drill-map PDFs are explanatory. Inspect Gerbers at the manufacturer's viewer before placing an order. The included fabrication files do not include the external battery regulator assemblies, enclosure, vacuum feedthrough or specimen mount.
