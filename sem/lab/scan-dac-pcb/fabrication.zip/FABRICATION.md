# Fabrication — A0 unbuilt prototype

60 × 45 mm; two copper layers; nominal1.6 mm FR-4;1oz copper. The project uses0.15 mm minimum track/clearance,0.6/0.3 mm plated vias, and3.2 mm unplated mounting holes. Preserve the generated Edge.Cuts and separate plated/nonplated drill files. The board carries only3.3V logic and0…2.5V analog signals. No high-voltage insulation rating is claimed.

The exact U1 package is TI DRX0010A,10-pin2.5×2.5mm WSON,0.5mm pitch, **no central exposed pad**. Its extended pads differ from generic WSON footprints. The stock KiCad footprint was compared with TI's land-pattern dimensions and numbered orientation. RN1 is the eight-terminal Vishay ACAS0612 convex array; it has no exposed center pad. The local Vishay_ACAS0612_IPC footprint follows [Vishay28950, IPC table](https://www.vishay.com/doc?28950):1.0mm pad length,0.6mm opposite-pad gap,0.4mm inner-pad width,0.6mm outer-pad width,0.8mm inner-center pitch and0.4mm gap between inner and outer lands. Outer lands are shifted0.1mm outward, as in the recommended geometry.

Use paste/stencil/reflow assembly and inspect fine-pitch joints; this is not a breadboard-compatible or easy socket-mounted package. U2 must be OPA333DBV SOT-23-5, not the SC70 variant. Consult the manufacturers' actual packaging and reflow instructions before assembly.

F.Paste is supplied for the stencil. Review pick-and-place rotations against the assembly drawing and package pin1 indicators with the assembler before placement. Headers and testpoints are through-hole parts installed after reflow. Fit pin1 indicators consistently on all cables.

`verification/check-summary.json` identifies the native schematic/PCB hashes checked before export. `manifest.json` lists hashes of all manufacturing outputs. Passing checks means no reported CAD ERC/DRC/connectivity errors at that revision; no manufactured board or imaging performance has been validated.

Assembly and low-voltage commissioning instructions are in README.md. Keep external scan amplifiers and electron-gun power disconnected during the initial bench tests.
