# Helpers adapted from the repository's KiCad generator; standalone copy.
import copy,json,math,re,uuid
from pathlib import Path
import pcbnew
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'kicad'
LIB=OUT/'ScanDAC.pretty'
SYS_SYMBOLS=Path('/usr/share/kicad/symbols')
SYS_FOOTPRINTS=Path('/usr/share/kicad/footprints')
PROJECT='dac80502_scan'
DATE='2026-09-11'
REVISION='A0 - UNBUILT'
NAMESPACE=uuid.UUID('fb558dc0-9bb7-54d5-a640-10b2c3b97a23')
def uid(name): return str(uuid.uuid5(NAMESPACE,name))
def assigned_footprint(p): return 'ScanDAC:'+p.footprint.split(':')[-1] if p.footprint else ''
_symbol_cache={}
class Atom(str):
    """An unquoted S-expression token."""

def parse(text):
    tokens = re.findall(r'"(?:\\.|[^"\\])*"|[()]|[^\s()]+', text)
    stack, roots = [], []
    for t in tokens:
        if t == "(":
            node = []
            if stack:
                stack[-1].append(node)
            else:
                roots.append(node)
            stack.append(node)
        elif t == ")":
            stack.pop()
        else:
            value = json.loads(t) if t.startswith('"') else Atom(t)
            stack[-1].append(value)
    if stack or len(roots) != 1:
        raise ValueError("Malformed S-expression")
    return roots[0]

def emit(node, level=0):
    if isinstance(node, Atom):
        return str(node)
    if isinstance(node, str):
        return json.dumps(node, ensure_ascii=False)
    if not isinstance(node, list):
        return str(node)
    if not any(isinstance(x, list) for x in node):
        return "(" + " ".join(emit(x) for x in node) + ")"
    chunks = []
    for i, x in enumerate(node):
        if isinstance(x, list):
            chunks.append("\n" + "  " * (level + 1) + emit(x, level + 1))
        else:
            chunks.append((" " if i else "") + emit(x, level))
    return "(" + "".join(chunks) + ")"

def children(node, name):
    return [n for n in node if isinstance(n, list) and n and n[0] == name]

def child(node, name):
    result = children(node, name)
    return result[0] if result else None

def A(text):
    return Atom(str(text))

def form(text):
    return parse(text)

def stock_symbol(lib, name):
    if lib not in _symbol_cache:
        tree = parse((SYS_SYMBOLS / (lib + ".kicad_sym")).read_text())
        _symbol_cache[lib] = {s[1]: s for s in children(tree, "symbol")}
    raw = copy.deepcopy(_symbol_cache[lib][name])
    parent = child(raw, "extends")
    if not parent:
        return raw
    base = stock_symbol(lib, parent[1])
    old = base[1]
    base[1] = name
    for section in children(base, "symbol"):
        section[1] = name + section[1][len(old):]
    props = {p[1]: p for p in children(raw, "property")}
    base = [n for n in base if not (isinstance(n, list) and n and n[0] == "property" and n[1] in props)]
    base.extend(props.values())
    return base

def pin(number, name, x, y, orientation, kind="passive", length=2.54):
    return form(f'(pin {kind} line (at {x} {y} {orientation}) (length {length})'
                f' (name {json.dumps(name)} (effects (font (size 1.0 1.0))))'
                f' (number "{number}" (effects (font (size 1.0 1.0)))))')

def custom_base(name, reference="U"):
    return form(f'(symbol "{name}" (pin_names (offset 0.5)) (in_bom yes) (on_board yes)'
                f' (property "Reference" "{reference}" (at 0 10.16 0) (effects (font (size 1.27 1.27))))'
                f' (property "Value" "{name}" (at 0 7.62 0) (effects (font (size 1.27 1.27))))'
                ' (property "Footprint" "" (at 0 0 0) (effects (font (size 1.0 1.0)) (hide yes)))'
                ' (property "Datasheet" "" (at 0 0 0) (effects (font (size 1.0 1.0)) (hide yes))))')

def box_symbol(name, left, right, reference="U", width=12.7, step=5.08):
    sym = custom_base(name, reference)
    count = max(len(left), len(right))
    halfh = max(7.62, count * step / 2)
    graphics = [A("symbol"), name + "_0_1",
                form(f'(rectangle (start {-width} {halfh}) (end {width} {-halfh})'
                     ' (stroke (width 0.254) (type default)) (fill (type background)))')]
    pins = [A("symbol"), name + "_1_1"]
    for side, items in [(-1, left), (1, right)]:
        for i, (number, pname, ptype) in enumerate(items):
            y = (len(items) - 1) * step / 2 - i * step
            pins.append(pin(number, pname, side * (width + 2.54), y,
                            0 if side < 0 else 180, ptype))
    sym.extend([graphics, pins])
    return sym

def opamp_symbol(name, triples, power_pins):
    sym = custom_base(name)
    for u, (plus, minus, output) in enumerate(triples, 1):
        sec = [A("symbol"), f"{name}_{u}_1"]
        sec.append(form('(polyline (pts (xy -5.08 5.08) (xy -5.08 -5.08)'
                        ' (xy 5.08 0) (xy -5.08 5.08))'
                        ' (stroke (width 0.254) (type default)) (fill (type background)))'))
        sec.extend([pin(plus, "+", -7.62, 2.54, 0, "input"),
                    pin(minus, "-", -7.62, -2.54, 0, "input"),
                    pin(output, "OUT", 7.62, 0, 180, "output")])
        sym.append(sec)
    punit = len(triples) + 1
    sym.append([A("symbol"), f"{name}_{punit}_1",
                pin(power_pins[0], "V+", 0, 5.08, 270, "power_in", 2.54),
                pin(power_pins[1], "V-", 0, -5.08, 90, "power_in", 2.54),
                form('(rectangle (start -2.54 2.54) (end 2.54 -2.54)'
                     ' (stroke (width 0.254) (type default)) (fill (type background)))')])
    return sym

def symbol_pins(sym, unit):
    pins = []
    for s in children(sym, "symbol"):
        m = re.search(r"_(\d+)_(\d+)$", s[1])
        if m and int(m.group(1)) in (0, unit) and int(m.group(2)) in (0, 1):
            pins.extend(children(s, "pin"))
    return pins

def fmt(n):
    return f"{n:.5f}".rstrip("0").rstrip(".") if n else "0"

def xy(p):
    return f"{fmt(p[0])} {fmt(p[1])}"

def transform(x, y, origin, angle):
    r = math.radians(angle)
    return (origin[0] + x * math.cos(r) - y * math.sin(r),
            origin[1] - x * math.sin(r) - y * math.cos(r))

class Schematic:
    def __init__(self, name, title, symbols, page="1", sheet_key=None, root_name=PROJECT):
        self.name = name
        self.title = title
        self.page = page
        self.root_name = root_name
        self.sheet_key = sheet_key
        self.root_uuid = uid("root" if root_name == PROJECT else "root:" + root_name)
        self.uuid = self.root_uuid if sheet_key is None else uid("file:" + name)
        self.symbols = symbols
        self.used = set()
        self.items = []
        self.counter = 0
        self.pin_wires = set()
        self.ref_uuids = {}

    def ident(self, prefix):
        self.counter += 1
        return uid(self.name + ":" + prefix + ":" + str(self.counter))

    def wire(self, points):
        for a, b in zip(points, points[1:]):
            if math.dist(a, b) < 1e-6:
                continue
            self.items.append(f'(wire (pts (xy {xy(a)}) (xy {xy(b)}))'
                              f' (stroke (width 0) (type default)) (uuid "{self.ident("wire")}"))')

    def label(self, net, point, angle=0):
        # Native global labels are the intentional inter-sheet net mechanism.
        self.items.append(f'(global_label {json.dumps(net)} (shape bidirectional) (at {xy(point)} {angle})'
                          f' (effects (font (size 1.0 1.0)) (justify {"right" if angle == 180 else "left"}))'
                          f' (uuid "{self.ident("label")}")'
                          f' (property "Intersheetrefs" "${{INTERSHEET_REFS}}" (at {xy(point)} {angle})'
                          ' (effects (font (size 1 1)) (hide yes))))')

    def note(self, text, point, size=1.4):
        self.items.append(f'(text {json.dumps(text)} (at {xy(point)} 0)'
                          f' (effects (font (size {size} {size})) (justify left top))'
                          f' (uuid "{self.ident("note")}"))')

    def line(self, a, b):
        self.items.append(f'(polyline (pts (xy {xy(a)}) (xy {xy(b)}))'
                          ' (stroke (width 0.254) (type default)) (fill (type none))'
                          f' (uuid "{self.ident("graphic")}"))')

    def add_part(self, p, unit=1, origin=None, angle=None, buffer=False):
        name = p.symbol
        self.used.add(name)
        origin = p.sch_at if origin is None else origin
        angle = p.sch_angle if angle is None else angle
        instance_uuid = uid(f"symbol:{p.ref}:{unit}")
        self.ref_uuids.setdefault(p.ref, instance_uuid)
        libname = "ScanDAC:" + name
        footprint = assigned_footprint(p)
        # Place fields away from component pins; hide long procurement strings.
        field_x, field_y = origin[0] + 3.81, origin[1] - 2.54
        if name in ("QuadOpAmp", "DualOpAmp"):
            power_unit = 5 if name == "QuadOpAmp" else 3
            if unit == power_unit:
                field_x, field_y = origin[0] + 6.35, origin[1] - 2.54
            else:
                field_x, field_y = origin[0], origin[1] - 10.16
        elif name in ("Conn2", "Conn3", "Conn4", "Conn5", "Conn6"):
            field_x, field_y = origin[0] - 3.81, origin[1] - int(name[-1])*2.54 - 7.62
        elif name in ("IsolatedDC", "REF5040", "LM78L05_SO8"):
            field_x, field_y = origin[0], origin[1] - 17.78
        elif name == "RelayDPDT":
            field_x, field_y = origin[0] - 2.54, origin[1] - 10.16
        elif name in ("D", "Zener", "TVS"):
            if angle in (90, 270):
                field_x, field_y = origin[0] + 10.16, origin[1] - 2.54
            else:
                field_x, field_y = origin[0] - 3.81, origin[1] - 7.62
        elif name == "Pot":
            field_x, field_y = origin[0] - 17.78, origin[1] - 2.54
        elif name in ("PMOS_GDS", "NMOS_GSD", "NPN_BEC"):
            field_x, field_y = origin[0] + 8.89, origin[1] - 5.08
        elif name == "Switch":
            field_x, field_y = origin[0] - 3.81, origin[1] - 10.16
        elif angle in (90, 270):
            field_x, field_y = origin[0] - 3.81, origin[1] - 7.62
        if "field_at" in p.extras:
            field_x, field_y = p.extras["field_at"]
        props = []
        for key, val, dy, hidden in [
            ("Reference", p.ref, 0, False), ("Value", p.value, 2.54, False),
            ("Footprint", footprint, 0, True), ("Datasheet", p.datasheet, 0, True),
            ("MPN", p.mpn, 0, True), ("Manufacturer", p.manufacturer, 0, True),
            ("Buy_Mouser", p.buy if p.mpn else "", 0, True),
            ("Buy_DigiKey", p.buy_alt if p.mpn else "", 0, True),
            ("Function", p.purpose, 0, True),
        ]:
            props.append(f'(property {json.dumps(key)} {json.dumps(val)}'
                         f' (at {fmt(field_x)} {fmt(field_y + dy)} {angle})'
                         ' (effects (font (size 1.1 1.1)) (justify left)'
                         + (' (hide yes)' if hidden else '') + '))')
        path = "/" + self.root_uuid
        if self.sheet_key:
            path += "/" + uid("sheet:" + self.sheet_key)
        symbol = f'(symbol (lib_id "{libname}") (at {xy(origin)} {angle}) (unit {unit})'
        symbol += f' (in_bom {"no" if p.symbol in ("MountingHole","TestPoint") else "yes"}) (on_board {"no" if p.extras.get("external") else "yes"}) (dnp no)'
        symbol += f' (uuid "{instance_uuid}")\n' + "\n".join(props)
        for pn in symbol_pins(self.symbols[name], unit):
            number = child(pn, "number")[1]
            symbol += f'\n(pin "{number}" (uuid "{uid(f"pin:{p.ref}:{unit}:{number}")}"))'
        symbol += f'\n(instances (project "{self.root_name}" (path "{path}" (reference "{p.ref}") (unit {unit}))))'
        symbol += ')'
        self.items.append(symbol)
        pin_numbers = set()
        for pn in symbol_pins(self.symbols[name], unit):
            number = child(pn, "number")[1]
            pin_numbers.add(number)
            if number not in p.nets:
                raise ValueError(f"{p.ref}: symbol pin {number} missing from design data")
            if p.extras.get("manual_wires"):
                continue
            pa = child(pn, "at")
            point = transform(float(pa[1]), float(pa[2]), origin, angle)
            net = p.nets[number]
            if net is None:
                self.items.append(f'(no_connect (at {xy(point)}) (uuid "{self.ident("nc")}"))')
                continue
            # Draw real feedback loops on the unity-gain buffers.
            if buffer and child(pn, "name")[1] == "-":
                continue
            if buffer and pn[1] == "output":
                junction = (origin[0] + 12.7, origin[1])
                self.wire([point, junction])
                self.label(net, junction, 0)
                self.wire([junction, (junction[0], origin[1] + 10.16),
                           (origin[0] - 10.16, origin[1] + 10.16),
                           (origin[0] - 10.16, origin[1] + 2.54),
                           (origin[0] - 7.62, origin[1] + 2.54)])
                self.items.append(f'(junction (at {xy(junction)}) (diameter 0)'
                                  f' (color 0 0 0 0) (uuid "{self.ident("junction")}"))')
                continue
            pa_angle = (float(pa[3]) + angle) % 360
            rad = math.radians(pa_angle)
            end = (point[0] - 5.08 * math.cos(rad), point[1] + 5.08 * math.sin(rad))
            signature = (round(point[0], 5), round(point[1], 5), net)
            if signature not in self.pin_wires:
                self.pin_wires.add(signature)
                self.wire([point, end])
                # Keep vertical labels horizontal, extending right of the node.
                self.label(net, end, 180 if abs(pa_angle) < .1 else 0)
        return pin_numbers

    def power_flag(self, net, point, index):
        name = "PWR_FLAG"
        self.used.add(name)
        s_id = uid("flag:" + net)
        ref = f"#FLG{index:02d}"
        path = "/" + uid("root")
        self.items.append(f'(symbol (lib_id "ScanDAC:PWR_FLAG") (at {xy(point)} 0) (unit 1)'
                          f' (in_bom no) (on_board yes) (dnp no) (uuid "{s_id}")'
                          f' (property "Reference" "{ref}" (at {xy(point)} 0) (effects (font (size 1 1)) (hide yes)))'
                          f' (property "Value" "PWR_FLAG" (at {point[0]} {point[1]-4} 0) (effects (font (size 1 1))))'
                          f' (instances (project "{PROJECT}" (path "{path}" (reference "{ref}") (unit 1)))))')
        self.wire([point, (point[0], point[1] + 2.54)])
        self.label(net, (point[0], point[1] + 2.54), 0)

    def save(self):
        libs = []
        for name in sorted(self.used):
            sym = copy.deepcopy(self.symbols[name])
            sym[1] = "ScanDAC:" + name
            libs.append(emit(sym))
        header = f'(kicad_sch (version 20250114) (generator "eeschema") (uuid "{self.uuid}")'
        header += ' (paper "A3")'
        header += f' (title_block (title {json.dumps(self.title)}) (date "{DATE}") (rev "{REVISION}")'
        header += ' (company "DAC80502 precision scan module")'
        header += (' (comment 1 "LOW VOLTAGE ONLY - never connect to gun HV")' if self.root_name == PROJECT
                   else ' (comment 1 "HIGH-VOLTAGE SYSTEM WIRING / offboard equipment")')
        header += ' (comment 2 "Unbuilt engineering prototype / see ../README.md"))'
        content = header + '\n(lib_symbols\n' + '\n'.join(libs) + ')\n'
        content += '\n'.join(self.items)
        if self.sheet_key is None:
            content += '\n(sheet_instances (path "/" (page "1")))'
        content += '\n(embedded_fonts no)\n)\n'
        # Catch premature root closure as well as ordinary syntax errors;
        # KiCad can otherwise read an empty first root and ignore trailing data.
        parse(content)
        (OUT / (self.name + ".kicad_sch")).write_text(content)

def vec(x, y):
    return pcbnew.VECTOR2I(pcbnew.FromMM(x), pcbnew.FromMM(y))

def pcb_text(board, text, x, y, height=1.0, layer=pcbnew.F_SilkS, width=.15):
    t = pcbnew.PCB_TEXT(board)
    t.SetText(text)
    t.SetPosition(vec(x, y))
    t.SetTextSize(vec(height, height))
    t.SetTextThickness(pcbnew.FromMM(width))
    t.SetLayer(layer)
    board.Add(t)
    return t
