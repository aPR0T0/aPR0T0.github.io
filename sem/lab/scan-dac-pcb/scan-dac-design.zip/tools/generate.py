#!/usr/bin/env python3
"""Generate native schematic and placed board. Run /usr/bin/python3 tools/generate.py."""
from helpers import *
from types import SimpleNamespace
import csv, subprocess
SIZE=(60,45)
for d in [OUT,LIB,ROOT/'exports',ROOT/'fabrication',ROOT/'verification']:d.mkdir(exist_ok=True)
P=[]
def part(ref,value,symbol,footprint,nets,at,sch,angle=0,mpn='',purpose='',datasheet='',extras=None):
 p=SimpleNamespace(ref=ref,value=value,symbol=symbol,footprint=footprint,nets={str(k):v for k,v in nets.items()},at=at,sch_at=sch,sch_angle=angle,mpn=mpn,manufacturer='',buy='',buy_alt='',purpose=purpose,datasheet=datasheet,extras=extras or {},sheet='main');P.append(p);return p
R='Resistor_SMD:R_0805_2012Metric';C='Capacitor_SMD:C_0805_2012Metric';HDR='Connector_PinHeader_2.54mm:'
DAC='https://www.ti.com/lit/ds/symlink/dac80502.pdf';OPA='https://www.ti.com/lit/ds/symlink/opa333.pdf';RN='https://www.vishay.com/docs/28959/acas0612.pdf'
part('U1','DAC80502DRXT','DAC','Package_SON:Texas_DRX_WSON-10_2.5x2.5mm_P0.5mm',{1:'+3V3',2:'X_RAW',3:'AGND',4:'AGND',5:'AGND',6:'SCLK',7:'SYNC',8:'SDIN',9:'Y_RAW',10:'VREF_2V5'},(27,20,0),(121.92,68.58),mpn='DAC80502DRXT',purpose='16bit X/Y; SPI2C and RSTSEL grounded; DRX has no central exposed pad',datasheet=DAC,extras={'field_at':(106.68,40.64)})
part('U2','OPA333DBVR','Buffer','Package_TO_SOT_SMD:SOT-23-5',{1:'CENTER_RAW',2:'AGND',3:'DIV_1V25',4:'CENTER_RAW',5:'+3V3'},(43,28,180),(256.54,170.18),mpn='OPA333DBVR',purpose='Unity-gain center buffer; feedback before output isolation resistor',datasheet=OPA,extras={'field_at':(248.92,157.48)})
part('RN1','ACAS / 4x10k matched','Network','ScanDAC:Vishay_ACAS0612_IPC',{1:'VREF_2V5',2:'DIV_1V25',3:'DIV_1V25',4:'VREF_2V5',5:'DIV_1V25',6:'AGND',7:'AGND',8:'DIV_1V25'},(35,28,0),(165.1,170.18),mpn='ACASA1002S1002P100',purpose='Matched 5k/5k divider: R1||R4 upper, R2||R3 lower;0.05%matching/15ppm tracking;calibrate',datasheet=RN,extras={'field_at':(147.32,139.7)})
part('J1','ESP32 / CLEAN 3V3','Conn6',HDR+'PinHeader_1x06_P2.54mm_Vertical',{1:'+3V3',2:'AGND',3:'SCLK_IN',4:'SDIN_IN',5:'SYNC_IN',6:'BLANK'},(7,12,0),(35.56,66.04),purpose='1 clean3V3 IN; 2 GND; 3 GPIO18; 4 GPIO23; 5 GPIO27; 6 GPIO25 blank high')
part('J2','ANALOG TO EXT AMPS','Conn6',HDR+'PinHeader_1x06_P2.54mm_Vertical',{1:'X_OUT',2:'AGND',3:'Y_OUT',4:'AGND',5:'CENTER_OUT',6:'AGND'},(53,14,0),(373.38,73.66),purpose='1 X;2 ground;3 Y;4 ground;5 center1.25V;6 ground. High-impedance external inputs only')
part('J3','BLANK OUT / GND','Conn2',HDR+'PinHeader_1x02_P2.54mm_Vertical',{1:'BLANK',2:'AGND'},(12,35,90),(43.18,208.28),purpose='1 active-high BLANK to external interface;2 ground. Independent hardware interlock required')
for ref,net_in,net_out,pos,sch in [('R1','SCLK_IN','SCLK',(16,17,0),(66.04,109.22)),('R2','SDIN_IN','SDIN',(16,22,0),(66.04,132.08)),('R3','SYNC_IN','SYNC',(16,27,0),(66.04,154.94))]:
 part(ref,'1k','R',R,{1:net_in,2:net_out},pos,sch,90,purpose='SPI series resistor; use short cable and SPI1MHz; no powered input while module off')
part('R4','47k','R',R,{1:'+3V3',2:'SYNC'},(23,30,90),(109.22,152.4),purpose='SYNC inactive-high pull-up')
part('R5','100k','R',R,{1:'SCLK',2:'AGND'},(22,25,90),(109.22,119.38),purpose='SCLK idle-low pull-down')
part('R6','10k','R',R,{1:'+3V3',2:'BLANK'},(12,30,0),(43.18,182.88),purpose='Active-high blank at reset while3V3present; external blanking must fail closed when supply absent')
for ref,raw,out,pos,sch in [('R7','X_RAW','X_OUT',(38,16,0),(294.64,53.34)),('R8','Y_RAW','Y_OUT',(38,21,0),(294.64,78.74)),('R9','CENTER_RAW','CENTER_OUT',(47,31.5,0),(314.96,170.18))]:
 part(ref,'49.9R 0.1%','R',R,{1:raw,2:out},pos,sch,90,purpose='Output isolation; high-impedance external amplifier input; calibrate load error')
part('C1','100n 16V X7R','C',C,{1:'+3V3',2:'AGND'},(23,17,90),(88.9,220.98),purpose='DAC local supply bypass')
part('C2','4.7u 16V X7R','C',C,{1:'+3V3',2:'AGND'},(19,11,0),(119.38,220.98),purpose='Supply bulk near input')
part('C3','1u 16V X7R','C',C,{1:'VREF_2V5',2:'AGND'},(31,17,90),(187.96,68.58),purpose='DAC reference bypass; effective capacitance must exceed150nF at2.5V')
part('C4','1u 16V X7R','C',C,{1:'DIV_1V25',2:'AGND'},(40,34,0),(208.28,200.66),purpose='Divider filter; 5k||5k * 1u =2.5ms')
part('C5','100n 16V X7R','C',C,{1:'+3V3',2:'AGND'},(46.5,25.5,90),(256.54,220.98),purpose='Buffer local supply bypass')
for ref,net,pos,sch in [('TP1','VREF_2V5',(34,10,0),(226.06,63.5)),('TP2','CENTER_OUT',(46,37,0),(360.68,175.26)),('TP3','AGND',(30,37,0),(340.36,208.28))]:
 part(ref,net,'TestPoint','TestPoint:TestPoint_THTPad_D2.0mm_Drill1.0mm',{1:net},pos,sch,purpose='Low-voltage bench measurement')
for i,(x,y) in enumerate([(4,4),(56,4),(4,41),(56,41)],1):part('H'+str(i),'M3','MountingHole','MountingHole:MountingHole_3.2mm_M3',{},(x,y,0),(294.64+i*20.32,238.76),purpose='Unplated mounting hole')
syms={}
for new,(lib,old) in {'R':('Device','R'),'C':('Device','C'),'TestPoint':('Connector','TestPoint'),'MountingHole':('Mechanical','MountingHole'),'PWR_FLAG':('power','PWR_FLAG')}.items():
 s=stock_symbol(lib,old);s[1]=new
 for sec in children(s,'symbol'):sec[1]=new+sec[1][len(old):]
 syms[new]=s
syms['DAC']=box_symbol('DAC',[(6,'SCLK','input'),(8,'SDIN','input'),(7,'SYNC','input'),(5,'SPI2C','input'),(3,'RSTSEL','input')],[(1,'VDD','power_in'),(10,'VREFIO','output'),(2,'VOUTA','output'),(9,'VOUTB','output'),(4,'AGND','power_in')],step=7.62)
syms['Buffer']=opamp_symbol('Buffer',[(3,4,1)],(5,2))
syms['Network']=custom_base('Network','RN')
sec=[A('symbol'),'Network_0_1',form('(rectangle (start -12.7 17.78) (end 12.7 -20.32) (stroke (width .254) (type default)) (fill (type background)))')]
pins=[A('symbol'),'Network_1_1']
for i in range(4):
 y=12.7-i*7.62;pins+=[pin(i+1,'R'+str(i+1),-15.24,y,0),pin(8-i,'R'+str(i+1),15.24,y,180)]
 sec.append(form(f'(polyline (pts (xy -12.7 {y}) (xy -5.08 {y}) (xy -5.08 {y+1.27}) (xy 5.08 {y+1.27}) (xy 5.08 {y-1.27}) (xy -5.08 {y-1.27}) (xy -5.08 {y}) (xy 12.7 {y})) (stroke (width .254) (type default)) (fill (type none)))'))
syms['Network']+=[sec,pins]
for n in [2,6]:syms['Conn'+str(n)]=box_symbol('Conn'+str(n),[(i,str(i),'passive') for i in range(1,n+1)],[],'J',width=3.81)
(OUT/'ScanDAC.kicad_sym').write_text(emit([A('kicad_symbol_lib'),form('(version 20250114)'),form('(generator "kicad_symbol_editor")')]+list(syms.values()))+'\n')
(OUT/'sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "ScanDAC") (type "KiCad") (uri "${KIPRJMOD}/ScanDAC.kicad_sym") (options "") (descr "Reviewed scan symbols")))\n')
# ACAS-specific lands from Vishay28950 p2, IPC recommendation. Outer pads
# deliberately offset0.1mm outward to preserve the specified0.4mm inner gap.
netfp=parse((SYS_FOOTPRINTS/'Resistor_SMD.pretty/R_Array_Convex_4x0603.kicad_mod').read_text())
netfp[1]='Vishay_ACAS0612_IPC';child(netfp,'descr')[1]='Vishay ACAS0612; doc28950 IPC lands; G0.6 Y1 X0.6 U0.4 Z2.6 I0.4 P0.8mm'
for pp in children(netfp,'property'):
 if pp[1]=='Value':pp[2]='Vishay_ACAS0612_IPC'
for pad in children(netfp,'pad'):
 n=int(pad[1]);outer=n in (1,4,5,8);xx=-.8 if n<=4 else .8
 yy={1:-1.3,2:-.4,3:.4,4:1.3,5:1.3,6:.4,7:-.4,8:-1.3}[n]
 child(pad,'at')[1:3]=[A(xx),A(yy)];child(pad,'size')[1:3]=[A(1.0),A(.6 if outer else .4)]
for g in children(netfp,'fp_line'):
 if child(g,'layer')[1]=='F.Fab':
  for key in ['start','end']:
   q=child(g,key)
   if abs(float(q[1]))==.8:q[1]=A(.75 if float(q[1])>0 else -.75)
(LIB/'Vishay_ACAS0612_IPC.kicad_mod').write_text(emit(netfp).replace('${KICAD9_3DMODEL_DIR}','${KICAD10_3DMODEL_DIR}')+'\n')
for p in P:
 lib,name=p.footprint.split(':')
 if lib=='ScanDAC':continue
 src=SYS_FOOTPRINTS/(lib+'.pretty')/(name+'.kicad_mod');(LIB/(name+'.kicad_mod')).write_text(src.read_text().replace('${KICAD9_3DMODEL_DIR}','${KICAD10_3DMODEL_DIR}'))
# Exact DRX vendor STEP model is not installed. Use project package-outline preview.
p=LIB/'Texas_DRX_WSON-10_2.5x2.5mm_P0.5mm.kicad_mod'
s=p.read_text().replace('${KICAD10_3DMODEL_DIR}/Package_SON.3dshapes/Texas_DRX_WSON-10_2.5x2.5mm_P0.5mm.step','${KIPRJMOD}/ScanDAC.3dshapes/DAC80502_DRX.wrl')
p.write_text(s)
(OUT/'fp-lib-table').write_text('(fp_lib_table (version 7) (lib (name "ScanDAC") (type "KiCad") (uri "${KIPRJMOD}/ScanDAC.pretty") (options "") (descr "Local footprints")))\n')
sch=Schematic(PROJECT,'DAC80502 16-bit scan module / Rev A0',syms)
sch.note('PRECISION X / Y SCAN | LOW-VOLTAGE MODULE',(15.24,12.7),2.0)
sch.note('01 ESP32 SPI / BLANK',(15.24,25.4),1.4);sch.note('02 16-BIT DAC',(99.06,25.4),1.4);sch.note('03 OUTPUTS TO EXTERNAL AMPLIFIERS',(261.62,25.4),1.4)
for p in P:
 if p.ref=='U2':
  sch.add_part(p,1,buffer=True); q=copy.deepcopy(p);q.extras={'field_at':(266.7,193.04)};sch.add_part(q,2,(256.54,195.58))
 else:sch.add_part(p)
sch.note('04 TRACKING CENTER REFERENCE',(144.78,124.46),1.4)
sch.note('RN1: (R1 || R4) upper / (R2 || R3) lower\nVcenter = VREFIO / 2 =1.25V nominal\nOPA333 feedback before R9; external load changes\nconnector voltage, so calibrate with actual amplifier.',(157.48,233.68),1.0)
sch.note('RSTSEL = GND: code zero at reset. At3.3V the DAC\nreference divider MUST be configured before use.\nKeep beam blank throughout power/reset/configuration.\nNo separate LDAC pin: GPIO26 remains unused.',(99.06,91.44),1.0)
sch.note('J2 only carries 0..2.5V X/Y and1.25Vcenter.\nExternal difference amplifiers implement:\nVplate =100*(Vout - Vcenter), nominal example.\nThe amplifiers, their supplies, plates and independent\nblanking hardware are NOT on this board.',(264.16,101.6),1.0)
sch.note('J1: 1 clean3.3V IN; 2 GND; 3 GPIO18 SCLK;\n4 GPIO23 MOSI;5 GPIO27 SYNC;6 GPIO25 BLANK.\nSPI1MHz/mode1. Common3V3power domain; short leads.\nDo not power this from the detector reference output.',(15.24,238.76),1.0)
sch.note('J3: external active-high blanking interface.\n10k pull-up works only while module3V3 exists.\nExternal interlock must hold blank if supply is lost.',(15.24,215.9),1.0)
sch.note('UNBUILT PROTOTYPE | No measured noise, linearity or beam-position accuracy.\nUse precision instruments for calibration; a nominal16bit code step is not imaging resolution.',(15.24,264.16),1.0)
for i,(n,at) in enumerate([('+3V3',(78.74,185.42)),('AGND',(99.06,185.42))],1):sch.power_flag(n,at,i)
sch.save()
subprocess.run(['kicad-cli','sch','export','netlist','--format','kicadxml','-o',str(ROOT/'verification/scan.net.xml'),str(OUT/(PROJECT+'.kicad_sch'))],check=True)
import sys
if '--schematic-only' in sys.argv:sys.exit(0)
board=pcbnew.BOARD();board.SetCopperLayerCount(2);board.SetFileName(str(OUT/(PROJECT+'.kicad_pcb')))
settings=board.GetDesignSettings();settings.m_TrackMinWidth=pcbnew.FromMM(.15);settings.m_MinClearance=pcbnew.FromMM(.15);settings.m_CopperEdgeClearance=pcbnew.FromMM(.5);settings.SetBoardThickness(pcbnew.FromMM(1.6))
nets={}
for idx,n in enumerate(sorted({n for p in P for n in p.nets.values() if n}),1):ni=pcbnew.NETINFO_ITEM(board,n,idx);board.Add(ni);nets[n]=ni
for p in P:
 name=p.footprint.split(':')[-1];f=pcbnew.FootprintLoad(str(LIB),name);f.SetFPID(pcbnew.LIB_ID('ScanDAC',name));f.SetReference(p.ref);f.SetValue(p.value);f.SetPosition(vec(*p.at[:2]));f.SetOrientationDegrees(p.at[2]);f.m_Uuid.Clone(pcbnew.KIID(uid('footprint:'+p.ref)));f.SetPath(pcbnew.KIID_PATH('/'+uid('root')+'/'+uid('symbol:'+p.ref+':1')));f.Value().SetVisible(False)
 for pad in f.Pads():
  if pad.GetNumber() and p.nets.get(pad.GetNumber()):pad.SetNet(nets[p.nets[pad.GetNumber()]])
 if p.ref.startswith('H'):f.SetAttributes(f.GetAttributes()|pcbnew.FP_EXCLUDE_FROM_BOM|pcbnew.FP_EXCLUDE_FROM_POS_FILES)
 for key,val in {'MPN':p.mpn,'Manufacturer':p.manufacturer,'Buy_Mouser':p.buy,'Buy_DigiKey':p.buy_alt,'Datasheet':p.datasheet,'Function':p.purpose}.items():f.SetField(key,val);f.GetField(key).SetVisible(False);f.GetField(key).SetLayer(pcbnew.F_Fab)
 board.Add(f)
for a,b in [((0,0),(60,0)),((60,0),(60,45)),((60,45),(0,45)),((0,45),(0,0))]:
 s=pcbnew.PCB_SHAPE();s.SetShape(pcbnew.SHAPE_T_SEGMENT);s.SetStart(vec(*a));s.SetEnd(vec(*b));s.SetLayer(pcbnew.Edge_Cuts);s.SetWidth(pcbnew.FromMM(.1));board.Add(s)
# Fixed outward fanout preserves the 0.5mm-pitch WSON escape channels.
fp=next(f for f in board.GetFootprints() if f.GetReference()=='U1')
anchors={1:(24.3,18.7),2:(24.3,19.6),3:(24.3,21.1),4:(24.3,21.1),5:(24.3,21.1),6:(29.7,21.6),7:(29.7,20.7),8:(29.7,19.8),9:(29.7,18.9),10:(29.7,18.0)}
seen=set()
for pad in fp.Pads():
 i=int(pad.GetNumber());q=pad.GetPosition();a=(pcbnew.ToMM(q.x),pcbnew.ToMM(q.y));end=anchors[i]
 points=[a,(24.8,a[1]),(24.8,21.1),end] if i in (3,4,5) else [a,(25.3 if i<=5 else 28.7,a[1]),end]
 for a,b in zip(points,points[1:]):
  if a==b:continue
  t=pcbnew.PCB_TRACK(board);t.SetStart(vec(*a));t.SetEnd(vec(*b));t.SetLayer(pcbnew.F_Cu);t.SetWidth(pcbnew.FromMM(.15));t.SetNet(pad.GetNet());board.Add(t)
 if end not in seen:
  seen.add(end);v=pcbnew.PCB_VIA(board);v.SetPosition(vec(*end));v.SetWidth(pcbnew.FromMM(.6));v.SetDrill(pcbnew.FromMM(.3));v.SetViaType(pcbnew.VIATYPE_THROUGH);v.SetLayerPair(pcbnew.F_Cu,pcbnew.B_Cu);v.SetNet(pad.GetNet());board.Add(v)
pcb_text(board,'DAC80502 / XY16 / A0',30,4,1.15)
pcb_text(board,'3.3V ONLY | UNBUILT',30,7,.9)
pcb_text(board,'1:3V3 2:GND',12,8.5,.8)
pcb_text(board,'J2: X G Y G C G',44,40.5,.8)
pcb_text(board,'C = 1.25V CENTER',43,43,.8)
pcb_text(board,'J3: BLANK GND',15,40.5,.8)
pcbnew.SaveBoard(str(OUT/(PROJECT+'.kicad_pcb')),board)
project={'meta':{'filename':PROJECT+'.kicad_pro','version':3},'board':{'design_settings':{'meta':{'version':2},'drc_exclusions':[],'rules':{'min_clearance':.15,'min_track_width':.15,'min_copper_edge_clearance':.5,'min_hole_clearance':.2,'min_hole_to_hole':.2,'min_through_hole_diameter':.3,'min_via_diameter':.6,'min_via_annular_width':.15,'min_silk_clearance':.1,'min_text_height':.8,'min_text_thickness':.12,'min_resolved_spokes':2},'rule_severities':{'courtyards_overlap':'error','missing_courtyard':'warning','unconnected_items':'error','shorting_items':'error','clearance':'error','silk_overlap':'warning','silk_over_copper':'warning'}}},'erc':{'erc_exclusions':[],'meta':{'version':0}},'net_settings':{'meta':{'version':4},'classes':[{'name':'Default','clearance':.15,'track_width':.15,'via_diameter':.6,'via_drill':.3,'bus_width':12,'wire_width':6,'schematic_color':[0,0,0,0]}]},'text_variables':{'ASSEMBLY_STATUS':'UNBUILT PROTOTYPE'}}
(OUT/(PROJECT+'.kicad_pro')).write_text(json.dumps(project,indent=2)+'\n')
(ROOT/'verification/design_manifest.json').write_text(json.dumps({'project':PROJECT,'date':DATE,'board_mm':SIZE,'parts':[vars(p) for p in P]},indent=2)+'\n')
with (ROOT/'bom.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['Reference','Value','Quantity','MPN_or_procurement_spec','Footprint','Function','Datasheet'])
 for p in P:w.writerow([p.ref,p.value,1,p.mpn or p.value,p.footprint,p.purpose,p.datasheet])
print('Generated schematic and placed low-voltage PCB. Route with tools/route_board.py.')
