#!/usr/bin/env python3
"""Independent KiCad checks, explicit IC/connector pin audit, and arithmetic."""
from pathlib import Path
import json, math, hashlib, subprocess, xml.etree.ElementTree as ET
import pcbnew
ROOT=Path(__file__).resolve().parents[1];NAME='dac80502_scan';K=ROOT/'kicad';V=ROOT/'verification'
for command in [
 ['kicad-cli','sch','erc','--format','json','-o',str(V/'erc.json'),str(K/(NAME+'.kicad_sch'))],
 ['kicad-cli','pcb','drc','--format','json','--schematic-parity','-o',str(V/'drc.json'),str(K/(NAME+'.kicad_pcb'))],
 ['kicad-cli','sch','export','netlist','--format','kicadxml','-o',str(V/'scan.net.xml'),str(K/(NAME+'.kicad_sch'))]]:subprocess.run(command,check=True)
erc=json.loads((V/'erc.json').read_text());drc=json.loads((V/'drc.json').read_text());ercv=[v for s in erc['sheets'] for v in s['violations']]
assert not ercv,ercv
for k in ('violations','unconnected_items','schematic_parity'):assert not drc[k],drc[k]
man=json.loads((V/'design_manifest.json').read_text())
expected={(p['ref'],k):n for p in man['parts'] for k,n in p['nets'].items()}
actual={}
for n in ET.parse(V/'scan.net.xml').findall('nets/net'):
 for a in n.findall('node'):
  if not a.get('ref').startswith('#'):actual[(a.get('ref'),a.get('pin'))]=n.get('name')
assert expected==actual, {'missing_or_changed':{str(k):[v,actual.get(k)] for k,v in expected.items() if actual.get(k)!=v}}
b=pcbnew.LoadBoard(str(K/(NAME+'.kicad_pcb')))
board={(f.GetReference(),p.GetNumber()):p.GetNetname() for f in b.GetFootprints() for p in f.Pads() if p.GetNumber()}
assert expected==board
# Independent explicit mappings from the three vendor datasheets and connector contract.
pins={'U1':['+3V3','X_RAW','AGND','AGND','AGND','SCLK','SYNC','SDIN','Y_RAW','VREF_2V5'],
'U2':['CENTER_RAW','AGND','DIV_1V25','CENTER_RAW','+3V3'],
'RN1':['VREF_2V5','DIV_1V25','DIV_1V25','VREF_2V5','DIV_1V25','AGND','AGND','DIV_1V25'],
'J1':['+3V3','AGND','SCLK_IN','SDIN_IN','SYNC_IN','BLANK'],
'J2':['X_OUT','AGND','Y_OUT','AGND','CENTER_OUT','AGND'],
'J3':['BLANK','AGND']}
for ref,names in pins.items():
 for i,n in enumerate(names,1):assert board[(ref,str(i))]==n,(ref,i,n)
u1=next(f for f in b.GetFootprints() if f.GetReference()=='U1')
assert sorted(int(p.GetNumber()) for p in u1.Pads())==list(range(1,11)), 'DRX must not have a fabricated central exposed pad'
assert u1.GetFPID().GetLibItemName()=='Texas_DRX_WSON-10_2.5x2.5mm_P0.5mm'
# DRX pad ordering/pitch audit, independent of KiCad symbol matching.
xy={int(p.GetNumber()):(pcbnew.ToMM(p.GetPosition().x-u1.GetPosition().x),pcbnew.ToMM(p.GetPosition().y-u1.GetPosition().y)) for p in u1.Pads()}
for i in range(1,6):assert xy[i][0]<0 and abs(xy[i][1]-(-1+(i-1)*.5))<1e-6
for i in range(6,11):assert xy[i][0]>0 and abs(xy[i][1]-(1-(i-6)*.5))<1e-6
# Vishay28950 IPC pad dimensions, independently read from final board.
rn=next(f for f in b.GetFootprints() if f.GetReference()=='RN1')
assert rn.GetFPID().GetLibItemName()=='Vishay_ACAS0612_IPC'
assert len(list(rn.Pads()))==8
for pad in rn.Pads():
 n=int(pad.GetNumber());outer=n in (1,4,5,8)
 assert abs(abs(pcbnew.ToMM(pad.GetPosition().x-rn.GetPosition().x))-.8)<1e-6
 assert abs(abs(pcbnew.ToMM(pad.GetPosition().y-rn.GetPosition().y))-(1.3 if outer else .4))<1e-6
 assert abs(pcbnew.ToMM(pad.GetSize().x)-1)<1e-6
 assert abs(pcbnew.ToMM(pad.GetSize().y)-(.6 if outer else .4))<1e-6
parts={p['ref']:p for p in man['parts']}
assert parts['RN1']['mpn']=='ACASA1002S1002P100'
assert parts['C3']['value']=='1u 16V X7R'
assert parts['R6']['nets']=={'1':'+3V3','2':'BLANK'} and parts['R6']['value']=='10k'
assert parts['R4']['nets']=={'1':'+3V3','2':'SYNC'}
for ref,raw,out in [('R7','X_RAW','X_OUT'),('R8','Y_RAW','Y_OUT'),('R9','CENTER_RAW','CENTER_OUT')]:assert parts[ref]['nets']=={'1':raw,'2':out}
# Calculated nominal behavior only, not a circuit simulation or a tolerance guarantee.
reference=2.5;divider=2;gain=2;code_count=65536;external_gain=100
step=reference/divider*gain/code_count
upper=1/(1/10000+1/10000);lower=upper
checks={'reference_V':reference,'DAC_bits':16,'nominal_DAC_LSB_uV':step*1e6,'nominal_center_V':reference*lower/(upper+lower),'nominal_max_code_V':step*65535,'external_example_gain':external_gain,'nominal_plate_LSB_mV':step*external_gain*1000,'divider_load_mA':reference/(upper+lower)*1000,'divider_filter_tau_ms':(upper*lower/(upper+lower))*1e-6*1000,'GAIN_register_hex':'0x0103','SYNC_register_hex':'0x0003','software_LDAC_hex':'0x0010','RSTSEL':'GND','SPI_mode':1,'SPI_clock_Hz':1000000,'startup_blanked_settle_ms':100}
assert abs(checks['nominal_center_V']-1.25)<1e-12
assert abs(checks['nominal_DAC_LSB_uV']-38.14697265625)<1e-9
assert checks['divider_load_mA']<5
report={'status':'PASS','date':'2026-09-11','kicad':pcbnew.GetBuildVersion(),'erc_violations':len(ercv),'drc_violations':len(drc['violations']),'unconnected':len(drc['unconnected_items']),'schematic_parity':len(drc['schematic_parity']),'pin_net_matches':len(board),'footprints':len(list(b.GetFootprints())),'tracks':len([t for t in b.GetTracks() if not isinstance(t,pcbnew.PCB_VIA)]),'vias':len([t for t in b.GetTracks() if isinstance(t,pcbnew.PCB_VIA)]),'math':checks,'sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [K/(NAME+'.kicad_sch'),K/(NAME+'.kicad_pcb')]},'limitations':['Unbuilt; no hardware measurements','Scan amplifiers, supplies, independent interlock, ESP32 and detector board external','DAC code step is not effective accuracy or image resolution','Center and outputs require gain/offset/loading/noise/settling calibration','DRC/ERC do not establish analogue performance or equipment safety']}
(V/'check-summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
