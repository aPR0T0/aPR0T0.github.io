#!/usr/bin/python3 -I
"""Unprivileged GTK companion. The root helper alone holds the signing key."""
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import threading
import urllib.error
import urllib.request
from urllib.parse import parse_qs, quote, urlsplit
import webbrowser

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gio, GLib, Gtk

sys.path.insert(0, "/opt/agent-remote-fingerprint")
from helper import origin

try:
    gi.require_version("Secret", "1")
    from gi.repository import Secret
    SCHEMA = Secret.Schema.new("app.agentremote.fingerprint", Secret.SchemaFlags.NONE, {"origin": Secret.SchemaAttributeType.STRING})
except (ValueError, ImportError):
    Secret = None

HELPER = "/opt/agent-remote-fingerprint/helper.py"
SETTINGS = Path(os.environ.get("XDG_CONFIG_HOME", str(Path.home() / ".config"))) / "agent-remote-fingerprint" / "settings.json"


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def request(relay, path, body, key):
    req = urllib.request.Request(relay + path, data=json.dumps(body).encode(), headers={"Authorization": "Bearer " + key, "Content-Type": "application/json"}, method="POST")
    opener = urllib.request.build_opener(NoRedirect, urllib.request.ProxyHandler({}))
    try:
        with opener.open(req, timeout=12) as response:
            data = response.read(524289)
            if len(data) > 524288:
                raise ValueError("The relay response is too large.")
            return json.loads(data)
    except urllib.error.HTTPError as error:
        try:
            message = json.loads(error.read(4096)).get("error", "Relay rejected the request.")
        except Exception:
            message = "Relay rejected the request."
        raise ValueError(str(message)[:700]) from None


def helper(body, scanning):
    process = subprocess.Popen(["/usr/bin/pkexec", "--disable-internal-agent", HELPER], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
    timer = threading.Timer(55, lambda: process.stdout.close())
    timer.daemon = True
    timer.start()
    try:
        process.stdin.write(json.dumps(body))
        process.stdin.close()
        result = None
        for _ in range(4):
            line = process.stdout.readline(16385)
            if not line:
                break
            value = json.loads(line)
            if value.get("event") == "scan":
                scanning()
            else:
                result = value
                break
        process.wait(timeout=12)
        if not result or process.returncode:
            raise ValueError((result or {}).get("error", "Fingerprint helper is unavailable. Check its installation and Polkit permission."))
        return result
    finally:
        timer.cancel()
        process.stdout.close()


class FingerprintApp(Gtk.Application):
    def __init__(self, relay="", smoke=False):
        super().__init__(application_id="app.agentremote.Fingerprint", flags=Gio.ApplicationFlags.NON_UNIQUE)
        self.initial_relay = relay
        self.smoke = smoke
        self.cancelled = threading.Event()

    def do_activate(self):
        self.window = Gtk.ApplicationWindow(application=self, title="Agent Remote · Laptop fingerprint")
        self.window.set_default_size(470, 520)
        self.window.connect("close-request", self.close)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        for name in ("top", "bottom", "start", "end"):
            getattr(box, "set_margin_" + name)(24)
        self.window.set_child(box)
        heading = Gtk.Label(label="Unlock with your laptop fingerprint", wrap=True, xalign=0)
        heading.add_css_class("title-2")
        box.append(heading)
        box.append(Gtk.Label(label="The fingerprint stays with fprintd on this laptop. Confirm the relay address before scanning.", wrap=True, xalign=0))
        self.url = Gtk.Entry(placeholder_text="https://laptop.tailnet.ts.net")
        self.key = Gtk.PasswordEntry(show_peek_icon=True)
        self.code = Gtk.PasswordEntry(show_peek_icon=True)
        for label, field in (("Relay HTTPS address", self.url), ("Relay API key · blank uses the saved key", self.key), ("Device-link code · first connection only", self.code)):
            box.append(Gtk.Label(label=label, xalign=0))
            box.append(field)
        try:
            saved = json.loads(SETTINGS.read_text()).get("origin", "")
        except (OSError, ValueError):
            saved = ""
        self.url.set_text(self.initial_relay or saved)
        self.remember = Gtk.CheckButton(label="Save relay key in the desktop keyring")
        self.remember.set_sensitive(Secret is not None)
        box.append(self.remember)
        self.feedback = Gtk.Label(label="First use: copy a device-link code from your unlocked phone. Requires relay 0.6.0 or newer.", wrap=True, xalign=0)
        self.feedback.set_selectable(True)
        box.append(self.feedback)
        self.button = Gtk.Button(label="Scan fingerprint & open workspace")
        self.button.add_css_class("suggested-action")
        self.button.connect("clicked", self.start)
        box.append(self.button)
        self.window.present()
        if self.smoke:
            GLib.timeout_add(800, lambda: (self.window.close(), False)[1])

    def close(self, _window):
        self.cancelled.set()
        self.key.set_text("")
        self.code.set_text("")
        return False

    def message(self, text):
        if not self.cancelled.is_set():
            self.feedback.set_label(text)
        return False

    def finish(self, message):
        if not self.cancelled.is_set():
            self.button.set_sensitive(True)
            self.message(message)
        return False

    def start(self, _button):
        try:
            relay = origin(self.url.get_text())
        except ValueError as error:
            self.message(str(error))
            return
        self.button.set_sensitive(False)
        key = self.key.get_text()
        code = self.code.get_text().strip()
        remember = self.remember.get_active()
        self.key.set_text("")
        self.code.set_text("")
        self.message("Requesting a secure challenge from " + relay)
        threading.Thread(target=self.login, args=(relay, key, code, remember), daemon=True).start()

    def login(self, relay, key, code, remember):
        token = None
        opened = False
        try:
            if not key and Secret:
                key = Secret.password_lookup_sync(SCHEMA, {"origin": relay}, None) or ""
            if not 32 <= len(key) <= 512:
                raise ValueError("Enter the relay API key for the first login. Saving it in the desktop keyring is optional.")
            pub = helper({"action": "public-key", "origin": relay}, lambda: None)["publicKey"]
            body = {"publicKey": pub, "name": "Linux fingerprint · " + os.uname().nodename[:55], "platform": "linux"}
            if code:
                body["enrollmentToken"] = code
            challenge = request(relay, "/api/native/auth/options", body, key)
            if self.cancelled.is_set():
                return
            signed = helper({"action": "sign", "origin": relay, "payload": challenge["payload"]}, lambda: GLib.idle_add(self.message, "Touch your enrolled finger on the Xiaomi/laptop reader…"))
            if self.cancelled.is_set():
                return
            verified = request(relay, "/api/native/auth/verify", {"challengeId": challenge["challengeId"], "signature": signed["signature"]}, key)
            token = verified["token"]
            if not isinstance(token, str) or not re.fullmatch(r"arn_[A-Za-z0-9_-]{43}", token):
                raise ValueError("Invalid login response.")
            if self.cancelled.is_set():
                return
            if remember and Secret:
                Secret.password_store_sync(SCHEMA, {"origin": relay}, Secret.COLLECTION_DEFAULT, "Agent Remote relay key · " + relay, key, None)
            SETTINGS.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            fd = os.open(SETTINGS, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW, 0o600)
            with os.fdopen(fd, "w") as file:
                json.dump({"origin": relay}, file)
            ticket = request(relay, "/api/native/auth/browser-ticket", {}, token)["ticket"]
            if not isinstance(ticket, str) or not re.fullmatch(r"[A-Za-z0-9_-]{43}", ticket):
                raise ValueError("Invalid browser handoff.")
            if self.cancelled.is_set():
                return
            opened = webbrowser.open(relay + "/#desktop=" + quote(ticket, safe=""))
            if not opened:
                raise ValueError("Could not open the browser. Check your default browser and scan again.")
            GLib.idle_add(self.finish, "Fingerprint verified. Your workspace is opening in the browser; the link is single-use and expires in 30 seconds.")
        except Exception as error:
            message = str(error) if isinstance(error, ValueError) else "Could not complete fingerprint login. Check the relay URL, network, and helper installation."
            if code:
                message += " If the code was claimed, create a fresh device-link code before retrying."
            GLib.idle_add(self.finish, message)
        finally:
            if token and not opened:
                try:
                    request(relay, "/api/auth/logout", {}, token)
                except Exception:
                    pass


def initial_origin(args):
    if not args:
        return ""
    value = args[0]
    url = urlsplit(value)
    if url.scheme != "agent-remote-fingerprint" or url.netloc != "unlock" or url.path not in ("", "/") or url.fragment:
        raise ValueError("Invalid fingerprint launcher link.")
    params = parse_qs(url.query, strict_parsing=True)
    if set(params) != {"relay"} or len(params["relay"]) != 1:
        raise ValueError("Only a relay origin can be passed to the launcher.")
    return origin(params["relay"][0])


if __name__ == "__main__":
    if os.geteuid() == 0:
        raise SystemExit("Run the fingerprint companion as your normal desktop user.")
    try:
        smoke = sys.argv[1:] == ["--smoke-test"]
        FingerprintApp("" if smoke else initial_origin(sys.argv[1:]), smoke).run([sys.argv[0]])
    except ValueError:
        raise SystemExit("Invalid Agent Remote fingerprint link.")
