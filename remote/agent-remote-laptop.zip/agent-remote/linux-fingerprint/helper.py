#!/usr/bin/python3 -I
"""Fixed-purpose root helper. No networking, passwords, shell, or raw prints."""
import base64
import fcntl
import hashlib
import json
import os
from pathlib import Path
import pwd
import re
import resource
import select
import signal
import stat
import sys
import time
from urllib.parse import urlsplit

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec

STATE = Path("/var/lib/agent-remote-fingerprint")


def origin(value):
    if not isinstance(value, str) or len(value) > 2000:
        raise ValueError("Enter the relay HTTPS origin.")
    url = urlsplit(value.strip())
    if url.scheme != "https" or not url.hostname or url.username is not None or url.password is not None or url.path not in ("", "/") or url.query or url.fragment:
        raise ValueError("Use only your relay HTTPS origin, without paths or credentials.")
    host = url.hostname.encode("idna").decode("ascii").lower()
    if not re.fullmatch(r"[a-z0-9.-]+", host):
        raise ValueError("Use the relay's HTTPS hostname.")
    port = url.port
    return "https://" + host + (":" + str(port) if port and port != 443 else "")


def encoded(data):
    return base64.urlsafe_b64encode(data).decode().rstrip("=")


def public_key(key):
    return encoded(key.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo))


def validate_payload(payload, relay, key, now=None):
    if not isinstance(payload, str) or not re.fullmatch(r"[A-Za-z0-9_-]{50,12000}", payload):
        raise ValueError("Invalid fingerprint challenge.")
    raw = base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4))
    value = json.loads(raw)
    if not isinstance(value, dict) or set(value) != {"protocol", "origin", "challengeId", "nonce", "credentialId", "kind", "expiresAt"}:
        raise ValueError("Unexpected challenge fields.")
    if value["protocol"] != "agent-remote/linux-auth/v1" or value["origin"] != relay or value["kind"] not in ("register", "authenticate"):
        raise ValueError("The challenge does not belong to this Linux login and relay.")
    if value["credentialId"] != hashlib.sha256(public_key(key).encode()).hexdigest():
        raise ValueError("The challenge belongs to another device key.")
    if not all(isinstance(value[name], str) and re.fullmatch(r"[A-Za-z0-9_-]{43}", value[name]) for name in ("challengeId", "nonce")):
        raise ValueError("Invalid challenge nonce.")
    now = time.time() * 1000 if now is None else now
    expiry = value["expiresAt"]
    if type(expiry) not in (int, float) or not now < expiry <= now + 180_000:
        raise ValueError("The fingerprint challenge expired. Check the laptop clock and try again.")
    return raw


def secure_directory(path):
    path.mkdir(mode=0o700, exist_ok=True)
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o077:
        raise PermissionError("Fingerprint key directory must be root-owned and private.")


def load_key(uid, relay):
    secure_directory(STATE)
    directory = STATE / str(uid)
    secure_directory(directory)
    lock = os.open(directory / ".lock", os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        fcntl.flock(lock, fcntl.LOCK_EX)
        path = directory / (hashlib.sha256(relay.encode()).hexdigest() + ".pem")
        if not path.exists():
            if len(list(directory.glob("*.pem"))) >= 20:
                raise ValueError("This user already has 20 relay keys.")
            key = ec.generate_private_key(ec.SECP256R1())
            data = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            with os.fdopen(fd, "wb") as file:
                file.write(data)
                file.flush()
                os.fsync(file.fileno())
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
        with os.fdopen(fd, "rb") as file:
            info = os.fstat(file.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o077 or info.st_size > 4096:
                raise PermissionError("Fingerprint key must be a private root-owned file.")
            key = serialization.load_pem_private_key(file.read(), password=None)
        if not isinstance(key, ec.EllipticCurvePrivateKey) or not isinstance(key.curve, ec.SECP256R1):
            raise ValueError("Invalid device key.")
        return key
    finally:
        os.close(lock)


def verify_fingerprint(username, notify=lambda: None):
    import gi
    from gi.repository import Gio, GLib
    service = "net.reactivated.Fprint"
    interface = service + ".Device"
    # Use the actual system bus, never a caller-selected private/virtual bus.
    bus = Gio.DBusConnection.new_for_address_sync("unix:path=/run/dbus/system_bus_socket", Gio.DBusConnectionFlags.AUTHENTICATION_CLIENT | Gio.DBusConnectionFlags.MESSAGE_BUS_CONNECTION, None, None)
    context = GLib.MainContext.new()
    context.push_thread_default()
    loop = GLib.MainLoop.new(context, False)
    path = None
    claimed = False
    subscription = None
    started = False
    matched = False
    source = None

    def call(target, iface, method, signature=None, values=()):
        return bus.call_sync(service, target, iface, method, GLib.Variant(signature, values) if signature else None, None, Gio.DBusCallFlags.NONE, 8000, None).unpack()

    try:
        paths, = call("/net/reactivated/Fprint/Manager", service + ".Manager", "GetDevices")
        if not paths:
            raise ValueError("No fingerprint reader is available. Check fprintd and its driver.")
        path = paths[0]
        for candidate in paths:
            props, = call(candidate, "org.freedesktop.DBus.Properties", "GetAll", "(s)", (interface,))
            if props.get("name") == "FPC MOH Fingerprint Sensor":
                path = candidate
                break
        fingers, = call(path, interface, "ListEnrolledFingers", "(s)", (username,))
        if not fingers:
            raise ValueError("Enroll a finger in the laptop's Fingerprint Security app first.")
        call(path, interface, "Claim", "(s)", (username,))
        claimed = True

        def signal(_bus, _sender, _path, _interface, _name, parameters, _data):
            nonlocal matched
            if parameters.get_type_string() != "(sb)":
                return
            status, done = parameters.unpack()
            if done:
                matched = status == "verify-match"
                loop.quit()

        subscription = bus.signal_subscribe(service, interface, "VerifyStatus", path, None, Gio.DBusSignalFlags.NONE, signal, None)
        call(path, interface, "VerifyStart", "(s)", ("any",))
        started = True
        notify()
        deadline = time.monotonic() + 40
        poll = select.poll()
        poll.register(1, select.POLLERR | select.POLLHUP)

        def timeout(_data):
            if time.monotonic() >= deadline or poll.poll(0):
                loop.quit()
                return False
            return True

        source = GLib.timeout_source_new(200)
        source.set_callback(timeout, None)
        source.attach(context)
        loop.run()
        if not matched:
            raise ValueError("Fingerprint not verified. Try your enrolled finger again.")
    finally:
        if source:
            source.destroy()
        if started:
            try:
                call(path, interface, "VerifyStop")
            except Exception:
                pass
        if claimed:
            try:
                call(path, interface, "Release")
            except Exception:
                pass
        if subscription is not None:
            bus.signal_unsubscribe(subscription)
        bus.close_sync(None)
        context.pop_thread_default()


def main():
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    uid = int(os.environ.get("PKEXEC_UID", "0"))
    if os.geteuid() != 0 or uid < 1000:
        raise PermissionError("Launch this helper through its installed Polkit action as a desktop user.")
    user = pwd.getpwuid(uid)
    raw = sys.stdin.buffer.read(16_385)
    if len(raw) > 16_384:
        raise ValueError("Helper request is too large.")
    request = json.loads(raw)
    if not isinstance(request, dict) or set(request) - {"action", "origin", "payload"}:
        raise ValueError("Invalid helper request.")
    relay = origin(request.get("origin"))
    if request.get("action") not in ("public-key", "sign"):
        raise ValueError("Unknown helper action.")
    key = load_key(uid, relay)
    if request["action"] == "public-key":
        return {"publicKey": public_key(key)}
    validate_payload(request.get("payload"), relay, key)
    verify_fingerprint(user.pw_name, lambda: print(json.dumps({"event": "scan", "origin": relay}), flush=True))
    raw = validate_payload(request["payload"], relay, key)
    return {"signature": encoded(key.sign(raw, ec.ECDSA(hashes.SHA256())))}


if __name__ == "__main__":
    def timed_out(_signal, _frame):
        raise ValueError("Fingerprint helper timed out.")
    signal.signal(signal.SIGALRM, timed_out)
    signal.alarm(90)
    try:
        print(json.dumps(main()), flush=True)
    except Exception as error:
        message = str(error) if isinstance(error, (ValueError, PermissionError)) else "Fingerprint helper failed. Check the reader and installation."
        print(json.dumps({"error": message}), flush=True)
        sys.exit(1)
    finally:
        signal.alarm(0)
