#!/usr/bin/python3 -I
"""One administrator-approved installation; no PAM or fprintd changes."""
import json
import os
from pathlib import Path
import pwd
import stat
import subprocess
import sys
import tempfile

TARGET = Path("/opt/agent-remote-fingerprint")
POLICY = Path("/usr/share/polkit-1/actions/app.agentremote.fingerprint.policy")
DESKTOP = Path("/usr/share/applications/agent-remote-fingerprint.desktop")
policy = """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE policyconfig PUBLIC "-//freedesktop//DTD PolicyKit Policy Configuration 1.0//EN" "http://www.freedesktop.org/standards/PolicyKit/1/policyconfig.dtd">
<policyconfig><vendor>Agent Remote</vendor>
<action id="app.agentremote.fingerprint"><description>Verify an Agent Remote fingerprint challenge</description>
<message>Authenticate to use Agent Remote's fingerprint helper</message>
<defaults><allow_any>no</allow_any><allow_inactive>no</allow_inactive><allow_active>yes</allow_active></defaults>
<annotate key="org.freedesktop.policykit.exec.path">/opt/agent-remote-fingerprint/helper.py</annotate>
</action></policyconfig>
"""
desktop = """[Desktop Entry]
Type=Application
Name=Agent Remote Fingerprint
Comment=Unlock your private relay with the laptop fingerprint reader
Exec=/usr/bin/python3 -I /opt/agent-remote-fingerprint/client.py %u
Icon=dialog-password
Terminal=false
Categories=Utility;Security;
MimeType=x-scheme-handler/agent-remote-fingerprint;
"""


def write(path, data, mode):
    if path.is_symlink():
        raise RuntimeError("Refusing an installation symlink: " + str(path))
    fd, temporary = tempfile.mkstemp(prefix=".agent-remote-", dir=path.parent)
    try:
        os.fchmod(fd, mode)
        with os.fdopen(fd, "wb") as file:
            file.write(data)
            file.flush()
            os.fsync(file.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def main():
    if os.geteuid() != 0:
        raise RuntimeError("Run: pkexec /usr/bin/python3 -I linux-fingerprint/install.py")
    uid = int(os.environ.get("PKEXEC_UID", "0"))
    if uid < 1000:
        raise RuntimeError("Launch the installer from your normal desktop user.")
    pwd.getpwuid(uid)
    source = Path(__file__).resolve().parent
    files = {name: (source / name).read_bytes() for name in ("helper.py", "client.py")}
    if TARGET.exists():
        info = TARGET.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
            raise RuntimeError("Existing installation directory is not root-protected.")
        marker = TARGET / "installed.json"
        if not marker.is_file() or json.loads(marker.read_text()).get("application") != "agent-remote-fingerprint":
            raise RuntimeError("Existing directory is not a recognized installation.")
    else:
        TARGET.mkdir(mode=0o755)
        if POLICY.exists() or DESKTOP.exists():
            raise RuntimeError("Existing policy/desktop files need review before installation.")
    for name, data in files.items():
        write(TARGET / name, data, 0o755 if name == "helper.py" else 0o644)
    write(TARGET / "installed.json", json.dumps({"application": "agent-remote-fingerprint", "version": 1}).encode(), 0o644)
    write(DESKTOP, desktop.encode(), 0o644)
    subprocess.run(["/usr/bin/desktop-file-validate", str(DESKTOP)], check=True)
    write(POLICY, policy.encode(), 0o644)
    subprocess.run(["/usr/bin/update-desktop-database", "/usr/share/applications"], check=True)
    print("Installed Agent Remote Fingerprint. Open it from your application launcher.")


if __name__ == "__main__":
    main()
