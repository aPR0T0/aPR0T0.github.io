#!/usr/bin/python3 -I
"""Explicit interactive scanner test. Does not log in or access relay data."""
import base64
import hashlib
import json
import secrets
import sys
import time
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec

sys.path.insert(0, "/opt/agent-remote-fingerprint")
from client import helper
from helper import origin, encoded

if len(sys.argv) != 2:
    raise SystemExit("Usage: python3 -I linux-fingerprint/check_hardware.py https://your-relay.ts.net")
relay = origin(sys.argv[1])
public = helper({"action": "public-key", "origin": relay}, lambda: None)["publicKey"]
claim = {"protocol": "agent-remote/linux-auth/v1", "origin": relay, "challengeId": secrets.token_urlsafe(32), "nonce": secrets.token_urlsafe(32), "credentialId": hashlib.sha256(public.encode()).hexdigest(), "kind": "authenticate", "expiresAt": int(time.time() * 1000) + 120000}
payload = json.dumps(claim).encode()
result = helper({"action": "sign", "origin": relay, "payload": encoded(payload)}, lambda: print("Touch your enrolled finger on the laptop reader now (40-second timeout).", flush=True))
decode = lambda value: base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))
key = serialization.load_der_public_key(decode(public))
key.verify(decode(result["signature"]), payload, ec.ECDSA(hashes.SHA256()))
print("Verified: the enrolled fingerprint produced a valid, origin-bound P-256 signature. No relay login or model calls were made.")
