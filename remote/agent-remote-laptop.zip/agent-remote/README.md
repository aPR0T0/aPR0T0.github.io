# Agent Remote

**Latest Android release: [0.5.2 APK](releases/agent-remote-0.5.2.apk)** — device-link codes survive switching apps or locking the authorizing phone, while keeping their original five-minute expiry and one-use verification. **Update and restart the relay too; the APK alone cannot fix an older relay’s code expiry.** See [connecting any device](docs/CONNECT-ANY-DEVICE.md), the [chat guide](docs/CHATS.md), and the [chat-transfer guide](docs/TRANSFERS.md).

A private, installable phone app for your **OpenCode and Codex agents**. A quiet, ChatGPT Remote–inspired interface with all your computers in one workspace.

**Native Android APK:** [`releases/agent-remote-0.5.2.apk`](releases/agent-remote-0.5.2.apk). See the [Android setup guide](docs/ANDROID.md), [security/connection test report](docs/SECURITY-TEST-REPORT.md), and [iteration scores](docs/QUALITY.md). The Android app uses strong biometric-gated Keystore signing with no PIN fallback; the browser version below uses WebAuthn passkeys.

- Live working, waiting-for-input, ready, offline, and unattached states.
- Conversations, follow-up instructions, current-turn cancellation, native approval requests, and agent questions.
- Searchable chat history with nested subagents, cross-computer request lists, copyable messages, and per-chat editable drafts.
- Start tasks on a chosen computer, workspace, source, and model.
- Laptop-first pairing with a **unique name and ID**, an expiring code, and phone-side confirmation.
- **Relay API key + passkey verification**. No separate Agent Remote account or extra app password.
- Light/dark themes and an installable mobile PWA.
- A **step-by-step laptop setup GUI** with connection checks, phone pairing, and saved start/stop controls.

## Easiest setup: web wizard + $0 server hosting

**Start from any device:** [apr0t0.github.io/remote/](https://apr0t0.github.io/remote/). Save your Tailscale relay address there and open your private workspace. The page also has a Windows/macOS/Linux laptop kit with first-run and daily launchers. [Connect any device](docs/CONNECT-ANY-DEVICE.md) explains viewing access, adding laptops, and linking a browser from the existing Android app.

Run this on the laptop where your OpenCode and Codex agents live, with **Node.js 22.13+ (24 recommended)**:

```bash
npm ci
npm run setup:gui
```

The command opens a local browser wizard. It walks through **laptop checks → private connection → project folders → OpenCode/Codex → phone pairing → ready**. Choose **This laptop + Tailscale** to host everything on your laptop with Tailscale's free Personal plan and a supplied HTTPS hostname. Install Tailscale on the phone and laptop and sign in to the same account.

The wizard saves the configuration, generates or preserves the relay key, tests local agent endpoints, starts services, and waits for your phone to approve the laptop. It can also connect additional laptops to that relay.

After the one-time setup:

```bash
npm run local
```

Keep the launcher running and the laptop awake. **Server hosting is $0; model-provider/Codex usage and your laptop's electricity remain separate.** Tailscale Personal is for eligible personal, non-commercial use.

See the **[step-by-step setup guide](docs/SETUP.md)** for Tailscale activation, agent login, automatic startup, and troubleshooting. The terminal-only and Docker routes below are also available.

## How the connection works

```text
Phone / installed PWA ─── HTTPS + WebSocket ─── Private relay
                                                  ▲
                     outbound WSS, device token ──┤
                                                  │
                                            Laptop connector
                                             ├─ OpenCode HTTP APIs
                                             └─ Codex app-server
```

**Different Wi-Fi networks work when your relay has a reachable HTTPS address.** Each laptop connects outward, so it does not need an open inbound agent port. Your computers and the relay must be awake and online.

This is a single-owner, self-hosted app. The relay is a trusted part of the system: it can see the status and conversation data it forwards. HTTPS/WSS encrypts transport; the app does not implement end-to-end encryption through an untrusted relay.

## 1. Run locally

Requirements: **Node.js 22.13+ (24 recommended)** and npm. A Node 24 installation is already available on the development laptop; `.nvmrc` selects it.

From the `agent-remote` folder:

```bash
nvm use 24
npm ci
npm run setup
npm run dev
```

For a local preview, accept `http://localhost:5173` during setup, then open that URL. **Explore the demo** is a completely local preview: its example computers, conversations, and commands are simulated and clearly labeled.

`npm run setup` generates a random **relay access API key**, prints it once, and saves `.env` with owner-only permissions. Save the key in your password manager. This is the key you enter on your phone; it is separate from your OpenAI, Anthropic, or other model-provider keys.

For a production build served directly by the relay:

```bash
npm run build
npm start
```

Set `PUBLIC_URL` to the exact URL used in the browser. When serving locally without Vite, that is `http://localhost:4317`. For everyday phone use, choose your permanent HTTPS URL before enrolling the phone’s passkey.

### Biometric behavior

The first unlock with your correct API key creates a passkey. Later unlocks require the API key and a verified passkey assertion. Device passkeys, phone passkeys, and security keys are supported; a built-in fingerprint reader is optional. An already-unlocked phone or browser can authorize another device with a one-use link code from Settings. In the existing Android app, **Authorize another phone** also works for browser linking.

WebAuthn asks your phone to verify you. That can be fingerprint, Face ID, or the device PIN, according to the phone and browser. **A web app cannot force fingerprint-only verification.** A native Android/iOS wrapper would be needed for stricter biometric-only policy.

Use HTTPS on your phone. HTTP `localhost` works for development on the same computer; opening `http://192.168.x.x:5173` on a phone is not a WebAuthn-capable substitute for HTTPS.

## 2. Put the relay online

### Free: use your laptop + Tailscale Serve

Use `npm run setup:gui` and choose **This laptop + Tailscale**. The [setup guide](docs/SETUP.md) covers private HTTPS and saved startup with `npm run local`. This route needs no rented server or purchased domain.

### Docker + automatic HTTPS

Use an always-on VPS or server with Docker Engine and the **Docker Compose plugin**. Point a domain such as `remote.your-domain.com` at that server and make ports 80 and 443 reachable.

1. Copy this project to the server.
2. Run `npm run setup` there, entering `https://remote.your-domain.com`, or create `.env` from `.env.example` with your own cryptographically random key.
3. Add this line to `.env`:

   ```dotenv
   REMOTE_DOMAIN=remote.your-domain.com
   ```

4. From the project folder, run:

   ```bash
   docker compose up -d --build
   ```

5. Open `https://remote.your-domain.com` on the phone. Enter the relay API key, register the phone passkey, and add the app to the home screen.

Caddy obtains and renews the TLS certificate and forwards both HTTP and WebSocket connections. Relay state is in the `relay-data` volume; certificate state is in the Caddy volumes. Keep these volumes when updating.

The included Compose file runs a **single relay process** behind one trusted proxy. The relay’s data store is an atomically replaced private JSON file; it is not designed for multiple replicas sharing a volume.

### Existing HTTPS reverse proxy or private VPN

You can also run `npm start` behind an existing HTTPS proxy or a private VPN HTTPS service. Forward **all paths**, including `/live` and `/bridge`, to port 4317 with WebSocket support. Set:

```dotenv
PUBLIC_URL=https://your-stable-hostname
TRUST_PROXY=1
```

Use `TRUST_PROXY=1` only with exactly one trusted proxy hop. Direct local development uses `0`. A VPN-only hostname must be reachable by both the phone and the laptop connectors through that VPN.

## 3. Pair each laptop

Install this project and Node.js on every computer whose agents you want to see. The connector runs **on the same computer as the agents**, under the same OS user.

From that copy’s project folder:

```bash
npm ci
npm run connector -- pair
```

The wizard asks for:

1. Your relay’s HTTPS URL.
2. A unique computer **name**, such as `Studio Linux`.
3. A unique computer **ID**, such as `studio-linux-01`. You can accept its generated suggestion.
4. Project directories allowed for new remote tasks.
5. Optional explicit OpenCode and Codex server URLs.

It then displays a short pairing code. On your unlocked phone, choose **Connect a computer**, enter that code, check the name and ID, and attach the computer. Codes expire in 10 minutes and can be used only once.

The connector receives its own revocable token and saves it to:

```text
~/.config/agent-remote/connector.json
```

`XDG_CONFIG_HOME` and `--config /path/to/connector.json` are supported. The file is written with mode `0600` on Unix systems. The relay API key is never required on a laptop connector.

After pairing, the connector starts automatically. On subsequent runs:

```bash
npm run connector -- start
```

**Computers → disconnect** on the phone immediately revokes that connector token. Pair again to reconnect it. Reusing a device’s token from a second connector replaces the first connection.

## 4. Connect OpenCode and Codex

### OpenCode

The connector discovers listening OpenCode processes with `ps`/`lsof` on Linux/macOS and process/TCP metadata on Windows. Explicit URLs also work. New listeners are discovered about every 10 seconds; session status refreshes about every 3 seconds.

For a predictable endpoint, launch the TUI in your project folder with:

```bash
opencode --hostname 127.0.0.1 --port 4096
```

Or use a headless server:

```bash
opencode serve --hostname 127.0.0.1 --port 4096
```

Enter `http://127.0.0.1:4096` in the pairing wizard. An already-running TUI may use a random local port; discovery can find that listener. Starting a new `opencode serve` process creates a separate server, so connect the endpoint actually doing the work.

If your OpenCode server uses basic authentication, supply the same `OPENCODE_SERVER_PASSWORD` and optional `OPENCODE_SERVER_USERNAME` in the connector’s environment. Different sources may reference different environment-variable names in the connector JSON.

The connector includes current busy sessions even when they fall outside the most recent 200 sessions returned for a workspace. Duplicate sessions from shared local databases are consolidated, preferring the server actively running that session.

### Codex

Install the Codex CLI on the laptop and authenticate it there as you normally would. This app talks to the official app-server protocol and uses that computer’s Codex configuration.

For a shared controllable server:

```bash
codex app-server --listen ws://127.0.0.1:4500
```

Enter `ws://127.0.0.1:4500` during pairing, or let local listener discovery find it. With a Codex version that supports the remote terminal client, connect the terminal UI to the same server:

```bash
codex --remote ws://127.0.0.1:4500
```

If this listener uses bearer authentication, set `CODEX_REMOTE_TOKEN` in the connector environment, or reference a custom environment variable using `tokenEnv`. All direct agent endpoints in the connector must be loopback addresses; the relay connection supplies the cross-network transport.

Alternatively, enter `managed` during the Codex step of pairing. The connector then launches `codex app-server` over stdio for tasks started from the phone. A managed Codex server has the connector’s lifetime. `CODEX_BIN` can point to a specific installed Codex executable.

**What “all agents” means:** the app lists sessions from connected agent APIs and detects standalone OpenCode/Codex processes. All loaded Codex threads in a connected app-server are subscribed, including subagent sources. Recent stored Codex history is viewable, but a separate terminal process cannot be remotely controlled simply because it shares the same session database. Such processes/history are labeled **Not attached**. Run those sessions through a connected app-server for live control.

The Codex WebSocket/app-server interface is version-sensitive. The integration uses `initialize`, `thread/list`, `thread/loaded/list`, `thread/resume`, `thread/read`, `thread/start`, `turn/start`, `turn/steer`, `turn/interrupt`, model listing, and native approval/input requests. An unsupported request is displayed with its details for handling in the original client. Agent permissions and sandbox policies are inherited from the agent; phone controls do not select a bypass mode.

### Configure sources and workspaces later

With the web wizard, stop local services on **Ready to go**, edit **Your projects** or **Your agents**, then **Save & start**. You can also edit the laptop’s `connector.json` and restart its connector. See [`deploy/connector.example.json`](deploy/connector.example.json) for the shape. Keep its generated device token. If editing files externally, restart the setup launcher to load them.

Remote task creation is limited to the configured, canonical workspace paths. The connector rechecks paths before execution. Existing exposed agent sessions retain their existing project access. Model/provider secrets remain on the computer; only model names/IDs are returned to the phone’s model selector.

## Keep the laptop connector running

A sample Linux user service is included at [`deploy/agent-remote-connector.service`](deploy/agent-remote-connector.service). Adjust the working directory and Node.js path to match the laptop, then place it in `~/.config/systemd/user/` and run:

```bash
systemctl --user daemon-reload
systemctl --user enable --now agent-remote-connector.service
systemctl --user status agent-remote-connector.service
```

The service can load agent-server credentials from `~/.config/agent-remote/connector.env`. On macOS, use a LaunchAgent; on Windows, use a user Task Scheduler task running the same connector command. Configure the computer’s power settings to remain awake while remote tasks run.

## Privacy, persistence, and recovery

- The API key is used for the unlock ceremony and is not saved in browser storage. Model-provider credentials are never sent as app login credentials.
- Passkey challenges expire after five minutes and are single-use. The server verifies origin, RP ID, signature, and user verification.
- Login sessions use HttpOnly, SameSite=Strict cookies, with Secure enabled under HTTPS. They expire after 15 minutes without interaction and at most 12 hours after login. Automatic polling does not extend them.
- The phone also locks when returning after at least a minute in the background.
- Pairing tokens, device tokens, and the relay API key are checked as hashes. Only passkey public keys, credential counters, device token hashes, and device metadata are persisted.
- Conversation responses and snapshots are kept in memory and sent with `Cache-Control: no-store`. The service worker only caches a generic offline page and its stylesheet. It does not cache agent content.
- The relay can see forwarded content. Host it on a machine you trust and back up its private data directory/volume.

If you lose access to all enrolled passkeys or move to a different hostname, stop the relay and run this from its project folder:

```bash
npm run reset-passkeys
```

Confirm `RESET`, restart the relay, and enroll your phone again with the relay API key. For the Docker deployment:

```bash
docker compose stop relay
docker compose run --rm --no-deps relay npm run reset-passkeys
docker compose up -d relay
```

The reset is a local operator recovery action. Devices retain their pairing. To revoke a lost computer, disconnect it from the phone. To change the relay API key, replace `REMOTE_API_KEY` and restart the relay; new phone unlocks use the new key, and paired devices continue using their device-specific tokens.

## Development and verification

```bash
npm run build          # strict TypeScript, PWA icons, production UI
npm test               # relay authentication/routing, adapters, discovery
npm run test:e2e       # real WebAuthn verifier + virtual browser authenticator
npm run test:opencode  # isolated compatibility check against installed OpenCode
```

Browser tests use installed Google Chrome by default. To use Playwright’s bundled Chromium, install it with `npx playwright install chromium` and run `PLAYWRIGHT_CHANNEL=chromium npm run test:e2e`.

The browser suite covers enrollment, wrong-key rejection, challenge replay rejection, subsequent biometric unlock, pairing confirmation, live status, remote instructions, token revocation, mobile layouts, filters, demo tasks, themes, and the full setup-wizard pairing/restart flow. It uses temporary relay state and fixture agents. Setup tests exercise local-only access, configuration preservation, Tailscale command boundaries, and both agent handshakes. Physical phone biometrics and your chosen network route need an on-device check after deployment.

`test:opencode` launches an isolated local server, creates an empty test session, checks status/messages and automatic discovery, and cleans it up. It submits no model prompts. Codex protocol behavior is covered with a local app-server fixture; validate against the Codex CLI version installed on each laptop.

### Project layout

```text
src/                  Phone dashboard and conversations
src/setup/            Step-by-step laptop setup web UI
setup/                Local-only setup API and service lifecycle
server/               HTTPS-proxy-ready relay, passkeys, pairing, WebSockets
connector/            Laptop wizard, discovery, and OpenCode/Codex adapters
shared/               Runtime-validated messages and commands
deploy/               Caddy, source examples, Linux user service
tests/                Protocol integration and browser tests
```
