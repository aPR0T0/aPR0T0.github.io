import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { readlink } from 'node:fs/promises';
import { basename } from 'node:path';
import { userInfo } from 'node:os';
import type { Provider } from '../shared/types';

const exec = promisify(execFile);
export interface LocalProcess { pid: number; parentPid: number; provider: Provider; directory: string; firstSeen: number }
export interface Endpoint { pid: number; provider: Provider; url: string }
export interface Discovery { processes: LocalProcess[]; endpoints: Endpoint[]; warning?: string }
function providerFor(command: string): Provider | undefined {
  const name = basename(command.trim()).toLowerCase().replace(/\.exe$/, '');
  if (/^opencode(?:-.*)?$/.test(name)) return 'opencode';
  if (/^codex(?:-.*)?$/.test(name)) return 'codex';
}

export function parseProcesses(output: string): Omit<LocalProcess, 'directory' | 'firstSeen'>[] {
  return output.split('\n').flatMap((line) => {
    const match = line.trim().match(/^(\d+)\s+(\d+)\s+(.+)$/);
    if (!match) return [];
    const provider = providerFor(match[3]);
    return provider ? [{ pid: Number(match[1]), parentPid: Number(match[2]), provider }] : [];
  });
}
export function parseListeners(output: string): Endpoint[] {
  let pid = 0; let provider: Provider | undefined;
  const result: Endpoint[] = [];
  for (const line of output.split('\n')) {
    if (line.startsWith('p')) { pid = Number(line.slice(1)); provider = undefined; }
    if (line.startsWith('c')) provider = providerFor(line.slice(1));
    if (line.startsWith('n') && pid && provider) {
      const port = line.match(/:(\d+)$/)?.[1];
      if (port) result.push({ pid, provider, url: `${provider === 'opencode' ? 'http' : 'ws'}://127.0.0.1:${port}` });
    }
  }
  return result.filter((item, index) => result.findIndex((other) => other.url === item.url && other.pid === item.pid) === index);
}

export async function discover(): Promise<Discovery> {
  if (process.platform === 'win32') {
    try {
      const { stdout } = await exec('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', "$p = @(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(opencode|codex)(-.+)?\\.exe$' }); $listeners = @(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object { $_.OwningProcess -in $p.ProcessId }); @{ processes = @($p | Select-Object ProcessId,ParentProcessId,Name); listeners = @($listeners | Select-Object OwningProcess,LocalPort) } | ConvertTo-Json -Depth 4 -Compress"], { timeout: 8000, maxBuffer: 1024 * 1024, windowsHide: true });
      const value = JSON.parse(stdout) as { processes: { ProcessId: number; ParentProcessId: number; Name: string }[]; listeners: { OwningProcess: number; LocalPort: number }[] };
      const processes = value.processes.map((item) => ({ pid: item.ProcessId, parentPid: item.ParentProcessId, provider: providerFor(item.Name)!, directory: '', firstSeen: Date.now() })).filter((item) => !!item.provider);
      const endpoints = value.listeners.flatMap((item) => {
        const process = processes.find((process) => process.pid === item.OwningProcess);
        return process ? [{ pid: process.pid, provider: process.provider, url: `${process.provider === 'opencode' ? 'http' : 'ws'}://127.0.0.1:${item.LocalPort}` }] : [];
      });
      return { processes, endpoints };
    } catch { return { processes: [], endpoints: [], warning: 'Automatic Windows discovery is unavailable. Add explicit source URLs to connector.json.' }; }
  }
  let processes: LocalProcess[] = [];
  let warning: string | undefined;
  try {
    const { stdout } = await exec('ps', ['-u', String(userInfo().uid), '-o', 'pid=,ppid=,comm='], { timeout: 5000, maxBuffer: 2 * 1024 * 1024 });
    processes = parseProcesses(stdout).map((item) => ({ ...item, firstSeen: Date.now(), directory: '' }));
    // Only directory metadata is read. Command-line arguments and agent secrets are not scanned.
    if (process.platform === 'linux') for (const item of processes) item.directory = await readlink(`/proc/${item.pid}/cwd`).catch(() => '');
  } catch { warning = 'Process discovery is unavailable. Configured agent servers can still connect.'; }
  let endpoints: Endpoint[] = [];
  try {
    const { stdout } = await exec('lsof', ['-nP', '-a', '-u', userInfo().username, '-iTCP', '-sTCP:LISTEN', '-Fpcn'], { timeout: 6000, maxBuffer: 2 * 1024 * 1024 });
    endpoints = parseListeners(stdout);
  } catch (error) {
    if ((error as { code?: string | number }).code !== 1) warning = 'Install lsof for automatic server discovery, or configure source URLs explicitly.';
  }
  return { processes, endpoints, warning };
}
