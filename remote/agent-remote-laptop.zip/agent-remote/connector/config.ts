import { homedir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { mkdir, readFile, realpath, rename, writeFile } from 'node:fs/promises';
import { randomBytes } from 'node:crypto';
import { z } from 'zod';
import { deviceIdentitySchema, providerSchema } from '../shared/types';

export function validateLocalEndpoint(input: string, provider: 'opencode' | 'codex'): string {
  if (provider === 'codex' && input === 'stdio') return input;
  const url = new URL(input);
  const protocols = provider === 'opencode' ? ['http:', 'https:'] : ['ws:', 'wss:'];
  if (!protocols.includes(url.protocol) || !['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname) || url.username || url.password || url.search || url.hash || url.pathname !== '/') {
    throw new Error(`${provider === 'opencode' ? 'OpenCode' : 'Codex'} endpoints must be loopback URLs with no path or embedded credentials.`);
  }
  return url.origin;
}
const envName = z.string().regex(/^[A-Za-z_][A-Za-z0-9_]*$/);
export const sourceConfigSchema = z.object({
  id: z.string().regex(/^[a-zA-Z0-9_-]{1,100}$/),
  label: z.string().min(1).max(200),
  provider: providerSchema,
  url: z.string().max(2000),
  passwordEnv: envName.optional(),
  usernameEnv: envName.optional(),
  tokenEnv: envName.optional(),
}).superRefine((value, context) => {
  try { validateLocalEndpoint(value.url, value.provider); }
  catch (error) { context.addIssue({ code: 'custom', message: error instanceof Error ? error.message : 'Invalid endpoint' }); }
});
export type SourceConfig = z.infer<typeof sourceConfigSchema>;
export const connectorConfigSchema = z.object({
  version: z.literal(1),
  relayUrl: z.url().refine((value) => {
    const url = new URL(value);
    return (url.protocol === 'https:' || (url.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(url.hostname))) && !url.username && !url.password && !url.search && !url.hash && url.pathname === '/';
  }, 'The relay needs HTTPS, or localhost for development.'),
  device: deviceIdentitySchema,
  token: z.string().min(32),
  discover: z.boolean().default(true),
  workspaces: z.array(z.string().min(1)).max(100),
  sources: z.array(sourceConfigSchema).max(100),
}).superRefine((value, context) => {
  if (new Set(value.sources.map((source) => source.id)).size !== value.sources.length) context.addIssue({ code: 'custom', message: 'Source IDs must be unique.' });
  if (new Set(value.sources.map((source) => `${source.provider}:${source.url}`)).size !== value.sources.length) context.addIssue({ code: 'custom', message: 'Each source URL should only be configured once.' });
});
export type ConnectorConfig = z.infer<typeof connectorConfigSchema>;
export const defaultConfigPath = () => join(process.env.XDG_CONFIG_HOME || join(homedir(), '.config'), 'agent-remote', 'connector.json');
export async function loadConfig(path: string): Promise<ConnectorConfig> {
  const config = connectorConfigSchema.parse(JSON.parse(await readFile(path, 'utf8')));
  config.workspaces = [...new Set(await Promise.all(config.workspaces.map((workspace) => realpath(resolve(workspace)))))];
  return config;
}
export async function saveConfig(path: string, config: ConnectorConfig) {
  connectorConfigSchema.parse(config);
  await mkdir(dirname(path), { recursive: true, mode: 0o700 });
  const temporary = `${path}.${randomBytes(6).toString('hex')}.tmp`;
  await writeFile(temporary, `${JSON.stringify(config, null, 2)}\n`, { mode: 0o600, flag: 'wx' });
  await rename(temporary, path);
}
