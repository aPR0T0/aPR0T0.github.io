import { createInterface } from 'node:readline/promises';
import { stdin, stdout } from 'node:process';
import { existsSync } from 'node:fs';
import { realpath, stat } from 'node:fs/promises';
import { hostname, platform, homedir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { randomBytes } from 'node:crypto';
import { parseArgs } from 'node:util';
import { deviceIdentitySchema, type DeviceIdentity } from '../shared/types';
import { Connector, sourceId } from './runtime';
import { defaultConfigPath, loadConfig, saveConfig, validateLocalEndpoint, type ConnectorConfig, type SourceConfig } from './config';

const { values, positionals } = parseArgs({ options: { config: { type: 'string' }, help: { type: 'boolean', short: 'h' } }, allowPositionals: true });
const path = resolve(values.config || defaultConfigPath());
const command = positionals[0] || 'start';

async function request<T>(relay: string, path: string, body?: unknown, token?: string): Promise<T> {
  const response = await fetch(new URL(`/api${path}`, relay), { method: body === undefined ? 'GET' : 'POST', headers: { ...(body === undefined ? {} : { 'Content-Type': 'application/json' }), ...(token ? { Authorization: `Bearer ${token}` } : {}) }, ...(body === undefined ? {} : { body: JSON.stringify(body) }), signal: AbortSignal.timeout(12_000), redirect: 'error' });
  const value = await response.json() as T & { error?: string };
  if (!response.ok) throw new Error(value.error || `Relay returned HTTP ${response.status}.`);
  return value;
}
async function pair(): Promise<ConnectorConfig> {
  const prompt = createInterface({ input: stdin, output: stdout });
  let relayUrl: string;
  let identity: DeviceIdentity;
  let workspaces: string[];
  const sources: SourceConfig[] = [];
  try {
    console.log('\nAgent Remote · connect this computer\n');
    if (existsSync(path) && (await prompt.question('This computer has a saved pairing. Replace it? [y/N]: ')).trim().toLowerCase() !== 'y') throw new Error('Pairing cancelled. The existing connector configuration was preserved.');
    relayUrl = (await prompt.question('Relay URL (the HTTPS app URL on your phone): ')).trim();
    const url = new URL(relayUrl);
    if ((url.protocol !== 'https:' && !(url.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(url.hostname))) || url.username || url.password || url.pathname !== '/' || url.search || url.hash) throw new Error('Use an HTTPS relay origin, or localhost for development.');
    relayUrl = url.origin;
    const name = (await prompt.question(`Unique computer name [${hostname()}]: `)).trim() || hostname();
    const defaultId = `${name.toLowerCase().replace(/[^a-z0-9-]/g, '-').slice(0, 45)}-${randomBytes(3).toString('hex')}`;
    const id = (await prompt.question(`Unique computer ID [${defaultId}]: `)).trim() || defaultId;
    identity = deviceIdentitySchema.parse({ name, id, platform: platform() === 'darwin' ? 'macOS' : platform() === 'win32' ? 'Windows' : 'Linux' });
    const directories = (await prompt.question(`Project folders, comma-separated [${process.cwd()}]: `)).trim() || process.cwd();
    workspaces = [...new Set(await Promise.all(directories.split(',').map(async (directory) => {
      const expanded = directory.trim().replace(/^~(?=\/|$)/, homedir());
      const canonical = await realpath(resolve(expanded));
      if (!(await stat(canonical)).isDirectory()) throw new Error(`Workspace is not a directory: ${canonical}`);
      return canonical;
    })))];
    const opencode = (await prompt.question('OpenCode server URLs, comma-separated [auto-discover]: ')).trim();
    for (const input of opencode.split(',').map((value) => value.trim()).filter(Boolean)) {
      const url = validateLocalEndpoint(input, 'opencode');
      sources.push({ id: sourceId('opencode', url), label: `OpenCode · ${new URL(url).port || 'local'}`, provider: 'opencode', url, passwordEnv: 'OPENCODE_SERVER_PASSWORD', usernameEnv: 'OPENCODE_SERVER_USERNAME' });
    }
    const codex = (await prompt.question('Codex WebSocket URLs, or "managed" to launch codex app-server [auto-discover]: ')).trim();
    for (const input of codex.split(',').map((value) => value.trim()).filter(Boolean)) {
      const url = validateLocalEndpoint(input === 'managed' ? 'stdio' : input, 'codex');
      sources.push({ id: sourceId('codex', url), label: url === 'stdio' ? 'Codex · managed' : `Codex · ${new URL(url).port || 'local'}`, provider: 'codex', url, tokenEnv: 'CODEX_REMOTE_TOKEN' });
    }
  } finally { prompt.close(); }
  const pairing = await request<{ requestId: string; code: string; pollToken: string; expiresAt: number }>(relayUrl, '/pairing/request', identity);
  console.log(`\nOn your phone, open ${relayUrl}\nChoose Connect a computer and enter:\n\n  ${pairing.code}\n\nCheck the name: ${identity.name}\nCheck the ID:   ${identity.id}\n\nWaiting for your phone (expires in 10 minutes)…`);
  while (Date.now() < pairing.expiresAt) {
    await new Promise((resolve) => setTimeout(resolve, 2500));
    const result = await request<{ status: 'pending' | 'approved'; deviceToken?: string }>(relayUrl, `/pairing/${pairing.requestId}/poll`, undefined, pairing.pollToken);
    if (result.status === 'approved' && result.deviceToken) {
      const config: ConnectorConfig = { version: 1, relayUrl, device: identity, token: result.deviceToken, discover: true, workspaces, sources };
      await saveConfig(path, config);
      await request(relayUrl, `/pairing/${pairing.requestId}/ack`, {}, pairing.pollToken).catch(() => {});
      console.log(`\nPaired. Private connector configuration saved to ${path}\nStarting your connector. Keep this process running, or install the service described in README.md.\n`);
      return config;
    }
  }
  throw new Error('Pairing expired. Run the pairing command again.');
}

async function main() {
  if (values.help) { console.log('Agent Remote connector\n\n  npm run connector -- pair [--config /path/to/connector.json]\n  npm run connector -- start [--config /path/to/connector.json]\n\nPairing asks for the relay URL, unique computer name and ID, project folders, and agent sources.\nNo provider API keys are sent to the relay.'); return; }
  if (!['pair', 'start'].includes(command)) throw new Error('Choose either "pair" or "start". Use --help for usage.');
  if (command === 'start' && !existsSync(path)) throw new Error('This computer is not paired yet. Run npm run connector -- pair');
  const config = command === 'pair' ? await pair() : await loadConfig(path);
  const connector = new Connector(config, console.log, { stateDirectory: join(dirname(path), 'chat-data') });
  for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, () => { connector.stop(); });
  connector.start();
}
void main().catch((error) => { console.error(error instanceof Error ? error.message : 'Connector setup failed.'); process.exitCode = 1; });
