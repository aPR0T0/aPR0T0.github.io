import { createHash } from 'node:crypto';
import { realpath } from 'node:fs/promises';
import { join } from 'node:path';
import { WebSocket } from 'ws';
import { z } from 'zod';
import { bridgeMessageSchema, type Command, type LocalAgent, type Source } from '../shared/types';
import { bridgeCommandSchema, type BridgeCommand } from '../shared/transfers';
import { ChatDrafts } from './chat-drafts';
import { exportConversation } from '../shared/portable-chat';
import { type ConnectorConfig, type SourceConfig, validateLocalEndpoint } from './config';
import { discover, type Discovery } from './discovery';
import { type Adapter, sourceStatus } from './adapters/common';
import { OpenCodeAdapter } from './adapters/opencode';
import { CodexAdapter } from './adapters/codex';

const requestSchema = z.object({ type: z.literal('command'), requestId: z.string().uuid(), command: bridgeCommandSchema });
interface Entry { adapter: Adapter; agents: LocalAgent[]; status: Source; auto: boolean; seen: number; refreshing: boolean; updatedAt: number }
export const sourceId = (provider: string, url: string) => `${provider}-${createHash('sha256').update(url).digest('hex').slice(0, 12)}`;

export class Connector {
  private socket?: WebSocket;
  private adapters = new Map<string, Entry>();
  private agents = new Map<string, LocalAgent>();
  private routes = new Map<string, string>();
  private activeOwners = new Map<string, string>();
  private processes: Discovery = { processes: [], endpoints: [] };
  private processTimes = new Map<number, number>();
  private stopped = false;
  private scanning = false;
  private discoveryAt = 0;
  private retry = 1000;
  private reconnectTimer?: ReturnType<typeof setTimeout>;
  private refreshTimer?: ReturnType<typeof setInterval>;
  private changedTimer?: ReturnType<typeof setTimeout>;
  private inFlight = new Set<string>();
  private requestResults = new Map<string, unknown>();
  private lastWarning = '';
  private chats: ChatDrafts;
  onStopped: () => void = () => {};

  constructor(private config: ConnectorConfig, private log: (message: string) => void = console.log, options: { stateDirectory?: string } = {}) {
    const scope = createHash('sha256').update(`${config.device.id}\0${config.token}`).digest('hex');
    this.chats = new ChatDrafts(options.stateDirectory ? join(options.stateDirectory, scope) : undefined);
    for (const source of config.sources) this.addSource(source, false);
  }
  private addSource(source: SourceConfig, auto: boolean) {
    const adapter = source.provider === 'opencode' ? new OpenCodeAdapter(source, this.config.workspaces) : new CodexAdapter(source, () => this.changed());
    this.adapters.set(source.id, { adapter, agents: [], status: sourceStatus(source, false), auto, seen: Date.now(), refreshing: false, updatedAt: 0 });
  }
  start() {
    this.connect();
    this.refreshTimer = setInterval(() => void this.refresh(), 3000);
    void this.refresh();
  }
  status() {
    return {
      connected: this.socket?.readyState === WebSocket.OPEN && !this.stopped,
      stopped: this.stopped,
      sources: this.sourceStates(),
    };
  }
  private connect() {
    if (this.stopped) return;
    const url = new URL('/bridge', this.config.relayUrl);
    url.protocol = url.protocol === 'https:' ? 'wss:' : 'ws:';
    const socket = new WebSocket(url, { headers: { Authorization: `Bearer ${this.config.token}` }, handshakeTimeout: 10_000, maxPayload: 512 * 1024, perMessageDeflate: false });
    this.socket = socket;
    let terminal = false;
    let lastHeartbeat = Date.now();
    const watchdog = setInterval(() => {
      if (socket.readyState !== WebSocket.OPEN) return;
      if (Date.now() - lastHeartbeat > 35_000) socket.terminate();
      else socket.ping();
    }, 15_000);
    socket.on('ping', () => { lastHeartbeat = Date.now(); });
    socket.on('pong', () => { lastHeartbeat = Date.now(); });
    socket.on('open', () => {
      this.retry = 1000; this.log(`Connected: ${this.config.device.name} (${this.config.device.id})`);
      this.publish(); void this.refresh();
    });
    socket.on('unexpected-response', (_request, response) => {
      if (response.statusCode === 401 || response.statusCode === 403) {
        terminal = true; this.log('This connector is no longer authorized. Run the pairing command again.');
      }
      response.resume(); socket.terminate();
    });
    socket.on('message', (data) => {
      try {
        const message = JSON.parse(data.toString());
        if (message.type === 'connected') return;
        const request = requestSchema.parse(message);
        void this.execute(request);
      } catch { socket.close(1008, 'Invalid relay command'); }
    });
    socket.on('error', (error) => { this.log(`Relay connection: ${error.message}`); });
    socket.on('close', (code) => {
      clearInterval(watchdog);
      if (this.stopped) return;
      if (terminal || code === 4003 || code === 4002) { this.log(code === 4002 ? 'Another connector is using this device identity. This connector has stopped.' : 'Computer disconnected. Pair it again to reconnect.'); this.stop(); return; }
      this.log('Relay disconnected. Reconnecting automatically…');
      this.reconnectTimer = setTimeout(() => this.connect(), this.retry + Math.random() * this.retry * .25);
      this.retry = Math.min(this.retry * 2, 30_000);
    });
  }
  private send(message: unknown) {
    if (this.socket?.readyState === WebSocket.OPEN && this.socket.bufferedAmount < 4 * 1024 * 1024) this.socket.send(JSON.stringify(message));
  }
  private changed() {
    if (this.changedTimer || this.stopped) return;
    this.changedTimer = setTimeout(() => { this.changedTimer = undefined; this.send({ type: 'changed' }); void this.refresh(); }, 750);
  }

  private async scan() {
    if (!this.config.discover || Date.now() - this.discoveryAt < 10_000) return;
    this.discoveryAt = Date.now();
    this.processes = await discover();
    if (this.processes.warning && this.processes.warning !== this.lastWarning) { this.log(this.processes.warning); this.lastWarning = this.processes.warning; }
    for (const process of this.processes.processes) if (!this.processTimes.has(process.pid)) this.processTimes.set(process.pid, Date.now());
    for (const pid of this.processTimes.keys()) if (!this.processes.processes.some((process) => process.pid === pid)) this.processTimes.delete(pid);
    for (const endpoint of this.processes.endpoints) {
      const normalized = validateLocalEndpoint(endpoint.url, endpoint.provider);
      const existing = [...this.adapters.values()].find((entry) => entry.adapter.config.provider === endpoint.provider && validateLocalEndpoint(entry.adapter.config.url, endpoint.provider) === normalized);
      if (existing) { existing.seen = Date.now(); continue; }
      const id = sourceId(endpoint.provider, normalized);
      if (this.adapters.size >= 100) continue;
      this.addSource({ id, provider: endpoint.provider, url: normalized, label: `${endpoint.provider === 'opencode' ? 'OpenCode' : 'Codex'} · ${new URL(normalized).port}` }, true);
    }
    for (const [id, entry] of this.adapters) if (entry.auto && Date.now() - entry.seen > 60_000 && !this.processes.warning) { entry.adapter.close(); this.adapters.delete(id); }
  }
  async refresh() {
    if (this.stopped) return;
    if (!this.scanning) {
      this.scanning = true;
      void this.scan().catch((error) => this.log(`Discovery could not refresh: ${error instanceof Error ? error.message : 'Unknown error'}`)).finally(() => { this.scanning = false; });
    }
    // A stalled source must not hold up healthy sources or keep stale agents green.
    this.mergeAgents(); this.publish();
    await Promise.all([...this.adapters.values()].map(async (entry) => {
      if (entry.refreshing) return;
      entry.refreshing = true;
      try {
        const agents = await entry.adapter.refresh();
        if (this.stopped || this.adapters.get(entry.adapter.config.id) !== entry) return;
        entry.agents = agents; entry.status = sourceStatus(entry.adapter.config, true); entry.updatedAt = Date.now();
        for (const [key, owner] of this.activeOwners) if (owner === entry.adapter.config.id && !agents.some((agent) => `${agent.provider}:${agent.nativeId}` === key && ['working', 'waiting'].includes(agent.status))) this.activeOwners.delete(key);
        for (const agent of agents) if (['working', 'waiting'].includes(agent.status)) this.activeOwners.set(`${agent.provider}:${agent.nativeId}`, agent.sourceId);
      } catch (error) {
        entry.status = sourceStatus(entry.adapter.config, false, error instanceof Error ? error.message : 'Agent server is unavailable.');
        entry.agents = entry.agents.map((agent) => ({ ...agent, status: 'offline', approvals: [] }));
      } finally {
        entry.refreshing = false;
        if (!this.stopped) { this.mergeAgents(); this.publish(); }
      }
    }));
  }
  private fresh(entry: Entry) { return entry.status.connected && Date.now() - entry.updatedAt < 15_000; }
  private mergeAgents() {
    const groups = new Map<string, LocalAgent[]>();
    for (const entry of this.adapters.values()) for (const original of entry.agents) {
      const agent: LocalAgent = this.fresh(entry) ? original : { ...original, status: 'offline', approvals: [] };
      const key = `${agent.provider}:${agent.nativeId}`;
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key)!.push(agent);
    }
    const rank = (agent: LocalAgent) => agent.status === 'waiting' ? 5 : agent.status === 'working' ? 4 : agent.capabilities.prompt && agent.status !== 'offline' ? 3 : agent.status === 'offline' ? 0 : 1;
    this.agents.clear();
    for (const [key, candidates] of groups) {
      // Session databases can be shared by multiple local servers. Prefer the
      // server actually running a thread, and keep the chosen route stable.
      candidates.sort((a, b) => rank(b) - rank(a) || Number(b.id === this.routes.get(key)) - Number(a.id === this.routes.get(key)));
      const owner = this.activeOwners.get(key);
      let agent = owner ? candidates.find((candidate) => candidate.sourceId === owner) : candidates[0];
      if (!agent) agent = { ...candidates[0], status: 'unknown', preview: 'This session was running in another server. Reconnect that server to verify its state.', capabilities: { messages: candidates[0].capabilities.messages, prompt: false, stop: false }, approvals: [] };
      this.routes.set(key, agent.id); this.agents.set(agent.id, agent);
    }
    for (const key of this.routes.keys()) if (!groups.has(key)) this.routes.delete(key);
    const managed = new Set([...this.adapters.values()].map((entry) => entry.adapter.pid).filter((pid): pid is number => !!pid));
    for (const endpoint of this.processes.endpoints) if ([...this.adapters.values()].some((entry) => entry.status.connected && entry.adapter.config.provider === endpoint.provider && validateLocalEndpoint(entry.adapter.config.url, endpoint.provider) === validateLocalEndpoint(endpoint.url, endpoint.provider))) managed.add(endpoint.pid);
    for (const process of this.processes.processes) {
      if (managed.has(process.pid) || managed.has(process.parentPid)) continue;
      if (this.processes.processes.some((child) => child.parentPid === process.pid && child.provider === process.provider)) continue;
      const id = `process-${process.provider}:${process.pid}`;
      this.agents.set(id, { id, nativeId: String(process.pid), sourceId: `process-${process.provider}`, provider: process.provider, title: `${process.provider === 'opencode' ? 'OpenCode' : 'Codex'} · local process ${process.pid}`, directory: process.directory, status: 'unknown', preview: 'Process is running locally. Expose its local server and connect it to see live task status and send instructions.', updatedAt: this.processTimes.get(process.pid) || process.firstSeen, capabilities: { messages: false, prompt: false, stop: false }, approvals: [] });
    }
    const handoffs = this.chats.list([...this.agents.values()], this.sourceStates());
    for (const id of this.chats.hiddenNativeIds()) this.agents.delete(id);
    for (const handoff of handoffs) this.agents.set(handoff.id, handoff);
  }
  private sourceStates(): Source[] {
    return [...this.adapters.values()].map((entry) => ({ ...(this.fresh(entry) || !entry.status.connected ? entry.status : { ...entry.status, connected: false, error: 'Agent status is stale. Waiting for this server to respond.' }), canTransfer: this.chats.enabled }));
  }
  private publish() {
    const agents = [...this.agents.values()];
    // Keep active agents before bounded history when large shared stores exist.
    agents.sort((a, b) => Number(['working', 'waiting'].includes(b.status)) - Number(['working', 'waiting'].includes(a.status)) || b.updatedAt - a.updatedAt);
    const message = bridgeMessageSchema.safeParse({ type: 'snapshot', agents: agents.slice(0, 2000), sources: this.sourceStates(), workspaces: this.config.workspaces });
    if (message.success) this.send(message.data);
    else this.log(`Agent data could not be published: ${message.error.issues[0]?.path.join('.') || 'Invalid data'}`);
  }
  private async execute(request: z.infer<typeof requestSchema>) {
    if (this.requestResults.has(request.requestId)) { this.send(this.requestResults.get(request.requestId)); return; }
    if (this.inFlight.has(request.requestId)) return;
    if (this.inFlight.size >= 100) { this.send({ type: 'result', requestId: request.requestId, error: 'The connector is busy. Try again shortly.' }); return; }
    this.inFlight.add(request.requestId);
    let response: unknown;
    try {
      const result = await this.command(request.command);
      response = { type: 'result', requestId: request.requestId, result };
    } catch (error) { response = { type: 'result', requestId: request.requestId, error: (error instanceof Error ? error.message : 'The computer could not complete this request.').slice(0, 2000) }; }
    finally { this.inFlight.delete(request.requestId); }
    this.requestResults.set(request.requestId, response);
    if (this.requestResults.size > 200) this.requestResults.delete(this.requestResults.keys().next().value!);
    this.send(response);
    if (request.command.action !== 'agent.messages' && request.command.action !== 'source.options') void this.refresh();
  }
  private async allowedWorkspace(workspace: string) {
    if (!this.config.workspaces.includes(workspace) || await realpath(workspace) !== workspace) throw new Error('This workspace is not allowed by the computer’s connector configuration.');
  }
  private async command(command: BridgeCommand): Promise<unknown> {
    const agent = 'agentId' in command ? this.agents.get(command.agentId) : undefined;
    if ('agentId' in command && !agent) throw new Error('Agent not found. Refresh the dashboard.');
    const draft = agent ? this.chats.get(agent.id) : undefined;
    if (command.action === 'chat.export') {
      if (!this.chats.enabled) throw new Error('Update this connector to enable chat transfers.');
      if (draft?.phase === 'paused') return exportConversation(agent!, this.chats.detail(draft));
      if (draft && draft.phase !== 'active') throw new Error('This transferred chat is not ready to export.');
      const source = this.adapters.get(agent!.sourceId);
      if (!source || !this.fresh(source)) throw new Error('The source agent is offline or its status is stale.');
      const actualId = draft?.nativeAgentId || agent!.id;
      const before = (await source.adapter.refresh()).find((item) => item.id === actualId);
      if (!before || before.status !== 'idle' || before.approvals.length || !before.capabilities.messages) throw new Error('Finish or stop this turn before transferring its chat.');
      const detail = await source.adapter.execute({ action: 'agent.messages', agentId: actualId }, before);
      const after = (await source.adapter.refresh()).find((item) => item.id === actualId);
      if (!after || after.status !== 'idle' || after.approvals.length || after.updatedAt !== before.updatedAt) throw new Error('The source chat changed while exporting. Finish the turn and prepare a new transfer.');
      return exportConversation(after, detail);
    }
    const source = this.adapters.get('sourceId' in command ? command.sourceId : agent!.sourceId);
    if (command.action === 'agent.messages' && draft && draft.phase !== 'active') return this.chats.detail(draft);
    if (!source || !this.fresh(source)) throw new Error('This agent’s server is not connected or its status is stale.');
    if ('workspace' in command) await this.allowedWorkspace(command.workspace);
    if (command.action === 'chat.stage') {
      if (source.adapter.config.provider !== command.provider) throw new Error('The destination agent provider changed. Prepare a new transfer.');
      const result = this.chats.stage(command);
      this.mergeAgents(); this.publish();
      return result;
    }
    if (agent && command.action === 'agent.prompt' && !agent.capabilities.prompt) throw new Error('This session is not attached for control.');
    if (agent && command.action === 'agent.stop' && !agent.capabilities.stop) throw new Error('This session is not attached for control.');
    if (draft) {
      if (draft.command.provider !== source.adapter.config.provider) throw new Error('The configured destination provider changed. Transfer this chat to the correct source.');
      if (draft.phase === 'paused' && command.action === 'agent.prompt') {
        await this.allowedWorkspace(draft.command.workspace);
        if (draft.phase !== 'paused') throw new Error('This transferred chat is already starting. Wait for its status.');
        this.chats.change(draft, 'starting');
        this.mergeAgents(); this.publish();
        let started = false;
        try {
          const result = z.object({ agentId: z.string().max(300) }).parse(await source.adapter.execute({ action: 'agent.create', sourceId: draft.command.sourceId, workspace: draft.command.workspace, text: this.chats.prompt(draft, command.text), ...(draft.command.model ? { model: draft.command.model } : {}) }));
          this.chats.change(draft, 'active', result.agentId);
          started = true;
          try { source.agents = await source.adapter.refresh(); source.updatedAt = Date.now(); } catch { /* The confirmed native start is not retried if status refresh fails. */ }
          return { ok: true, agentId: agent!.id };
        } catch (error) {
          if (!started) this.chats.change(draft, 'uncertain');
          throw error;
        } finally { this.mergeAgents(); this.publish(); }
      }
      if (draft.phase !== 'active' || !draft.nativeAgentId) throw new Error('This transferred chat is paused or its previous start was not confirmed. Check its status before continuing.');
      const native = source.agents.find((item) => item.id === draft.nativeAgentId);
      if (!native) throw new Error('The native session is reconnecting. Refresh its status first.');
      return source.adapter.execute({ ...command, agentId: native.id } as Command, native);
    }
    return source.adapter.execute(command, agent);
  }
  stop() {
    if (this.stopped) return;
    this.stopped = true;
    clearInterval(this.refreshTimer); clearTimeout(this.reconnectTimer); clearTimeout(this.changedTimer);
    this.socket?.terminate();
    for (const entry of this.adapters.values()) entry.adapter.close();
    this.onStopped();
  }
}
