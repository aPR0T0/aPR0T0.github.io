import { spawn, type ChildProcessWithoutNullStreams } from 'node:child_process';
import { createInterface, type Interface } from 'node:readline';
import { WebSocket } from 'ws';
import type { SourceConfig } from '../config';
import { object, string, type ObjectValue } from './common';

interface Pending { resolve: (value: unknown) => void; reject: (error: Error) => void; timeout: ReturnType<typeof setTimeout> }

export class CodexRPC {
  private ws?: WebSocket;
  private child?: ChildProcessWithoutNullStreams;
  private lines?: Interface;
  private initializing?: Promise<void>;
  private ready = false;
  private stopped = false;
  private sequence = 0;
  private pending = new Map<number, Pending>();
  onMessage: (message: ObjectValue) => void = () => {};
  onDisconnect: () => void = () => {};
  get pid() { return this.child?.pid; }
  constructor(private config: SourceConfig) {}

  async connect() {
    if (this.stopped) throw new Error('This Codex connection was closed.');
    if (this.ready) return;
    if (this.initializing) return this.initializing;
    this.initializing = this.initialize().finally(() => { this.initializing = undefined; });
    return this.initializing;
  }
  private async initialize() {
    try {
      if (this.config.url === 'stdio') {
        await new Promise<void>((resolve, reject) => {
          const child = spawn(process.env.CODEX_BIN || 'codex', ['app-server'], { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
          this.child = child;
          this.lines = createInterface({ input: child.stdout });
          this.lines.on('line', (line) => this.receive(line));
          // Drain diagnostics without leaking provider credentials or conversations into relay logs.
          child.stderr.resume();
          child.once('spawn', resolve);
          child.once('error', (error) => { reject(new Error(`Could not start codex app-server: ${error.message}`)); this.disconnected(); });
          child.once('exit', () => { if (this.child === child) { this.child = undefined; this.disconnected(); } });
        });
      } else {
        await new Promise<void>((resolve, reject) => {
          const token = process.env[this.config.tokenEnv || 'CODEX_REMOTE_TOKEN'];
          const ws = new WebSocket(this.config.url, { headers: token ? { Authorization: `Bearer ${token}` } : {}, handshakeTimeout: 8000, maxPayload: 16 * 1024 * 1024, perMessageDeflate: false });
          this.ws = ws;
          ws.once('open', resolve);
          ws.on('message', (data) => this.receive(data.toString()));
          ws.on('error', (error) => { reject(new Error(`Codex connection failed: ${error.message}`)); });
          ws.on('close', () => { if (this.ws === ws) { this.ws = undefined; this.disconnected(); } });
        });
      }
      await this.call('initialize', { clientInfo: { name: 'agent_remote', title: 'Agent Remote', version: '0.1.0' } });
      this.send({ method: 'initialized', params: {} });
      this.ready = true;
    } catch (error) { this.ws?.terminate(); this.child?.kill('SIGTERM'); this.disconnected(); throw error; }
  }
  private receive(line: string) {
    if (Buffer.byteLength(line) > 16 * 1024 * 1024) return;
    let message: ObjectValue;
    try { message = object(JSON.parse(line)); } catch { return; }
    if (typeof message.id === 'number' && !message.method) {
      const request = this.pending.get(message.id);
      if (!request) return;
      clearTimeout(request.timeout); this.pending.delete(message.id);
      if (message.error) request.reject(new Error(string(object(message.error).message, 'Codex could not complete this request.')));
      else request.resolve(message.result);
    } else this.onMessage(message);
  }
  private send(value: unknown) {
    const data = JSON.stringify(value);
    if (this.ws?.readyState === WebSocket.OPEN) this.ws.send(data);
    else if (this.child?.stdin.writable && !this.child.killed) this.child.stdin.write(`${data}\n`);
    else throw new Error('Codex is not connected.');
  }
  private call(method: string, params: unknown): Promise<unknown> {
    const id = ++this.sequence;
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => { this.pending.delete(id); reject(new Error(`Codex timed out on ${method}. Check the session before retrying.`)); }, 15_000);
      this.pending.set(id, { resolve, reject, timeout });
      try { this.send({ id, method, params }); }
      catch (error) { clearTimeout(timeout); this.pending.delete(id); reject(error); }
    });
  }
  async request(method: string, params: unknown = {}): Promise<unknown> { await this.connect(); return this.call(method, params); }
  reply(id: number | string, result: unknown) { this.send({ id, result }); }
  private disconnected() {
    this.ready = false;
    for (const request of this.pending.values()) { clearTimeout(request.timeout); request.reject(new Error('Codex disconnected. Check the session before retrying.')); }
    this.pending.clear(); this.onDisconnect();
  }
  close() { this.stopped = true; this.ws?.terminate(); this.lines?.close(); this.child?.kill('SIGTERM'); this.disconnected(); }
}
