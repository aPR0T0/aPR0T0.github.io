import type { AgentDetail, Approval, Command, LocalAgent, Message, SourceOptions } from '../../shared/types';
import type { SourceConfig } from '../config';
import { array, boundedDetail, number, object, string, text, type Adapter, type ObjectValue } from './common';

class OpenCodeError extends Error { constructor(public status: number, message: string) { super(message); } }

export class OpenCodeAdapter implements Adapter {
  private sessions = new Map<string, ObjectValue>();
  private approvals = new Map<string, { sessionId: string; kind: 'permission' | 'question'; directory: string; raw: ObjectValue }>();
  private previews = new Map<string, string>();
  constructor(public config: SourceConfig, private workspaces: string[]) {}

  private async request(path: string, directory?: string, body?: unknown, method = body === undefined ? 'GET' : 'POST') {
    const url = new URL(path, this.config.url);
    if (directory) url.searchParams.set('directory', directory);
    const password = process.env[this.config.passwordEnv || 'OPENCODE_SERVER_PASSWORD'];
    const username = process.env[this.config.usernameEnv || 'OPENCODE_SERVER_USERNAME'] || 'opencode';
    const headers: Record<string, string> = { Accept: 'application/json' };
    if (password) headers.Authorization = `Basic ${Buffer.from(`${username}:${password}`).toString('base64')}`;
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    const response = await fetch(url, { method, headers, ...(body === undefined ? {} : { body: JSON.stringify(body) }), signal: AbortSignal.timeout(10_000), redirect: 'error' });
    if (!response.ok) {
      if (response.status === 401) throw new OpenCodeError(401, `OpenCode needs its server password. Set ${this.config.passwordEnv || 'OPENCODE_SERVER_PASSWORD'} in the connector environment.`);
      throw new OpenCodeError(response.status, `OpenCode returned HTTP ${response.status} for ${path.split('?')[0]}.`);
    }
    if (response.status === 204) return null;
    return response.json() as Promise<unknown>;
  }
  private async optional(path: string, directory?: string) {
    try { return await this.request(path, directory); }
    catch (error) { if (error instanceof OpenCodeError && error.status === 404) return []; throw error; }
  }

  async refresh(): Promise<LocalAgent[]> {
    const scopes = [undefined, ...this.workspaces] as (string | undefined)[];
    const sessions = new Map<string, ObjectValue>();
    const statuses = new Map<string, ObjectValue>();
    const pending: { raw: ObjectValue; kind: 'permission' | 'question'; directory: string }[] = [];
    const results = await Promise.all(scopes.map(async (directory) => {
      const [items, status, permissions, questions] = await Promise.all([
        this.request('/session?limit=200', directory), this.request('/session/status', directory),
        this.optional('/permission', directory), this.optional('/question', directory),
      ]);
      return { items, status, permissions, questions, directory };
    }));
    for (const { items, status, permissions, questions, directory } of results) {
      for (const item of array(items)) {
        const session = object(item); const id = string(session.id);
        if (id) sessions.set(id, session);
      }
      for (const [id, value] of Object.entries(object(status))) {
        // A shared session can appear in several directory scopes. An idle
        // history view must not overwrite the scope that is actually working.
        const next = object(value);
        if (!statuses.has(id) || next.type === 'busy' || next.type === 'retry') statuses.set(id, next);
        // Busy sessions must not disappear behind the recent-history limit.
        if (!sessions.has(id)) {
          const session = object(await this.request(`/session/${encodeURIComponent(id)}`, directory));
          if (string(session.id)) sessions.set(id, session);
        }
      }
      for (const raw of array(permissions)) pending.push({ raw: object(raw), kind: 'permission', directory: directory || '' });
      for (const raw of array(questions)) pending.push({ raw: object(raw), kind: 'question', directory: directory || '' });
    }
    // Waiting sessions (including subagents) need not occur in either the
    // recent-history page or the busy map. Hydrate every pending request owner.
    for (const item of pending) {
      const id = string(item.raw.sessionID);
      if (!id || sessions.has(id)) continue;
      try {
        const session = object(await this.request(`/session/${encodeURIComponent(id)}`, item.directory || undefined));
        if (string(session.id) === id) sessions.set(id, session);
      } catch (error) { if (!(error instanceof OpenCodeError && error.status === 404)) throw error; }
    }
    this.sessions = sessions;
    this.approvals.clear();
    for (const item of pending) {
      const id = string(item.raw.id); const sessionId = string(item.raw.sessionID);
      if (id && sessionId) this.approvals.set(id, { ...item, sessionId, directory: string(sessions.get(sessionId)?.directory, item.directory) });
    }
    return [...sessions.values()].map((session) => {
      const nativeId = string(session.id); const status = statuses.get(nativeId);
      const approvals: Approval[] = [...this.approvals.entries()].filter(([, approval]) => approval.sessionId === nativeId).map(([id, approval]) => approval.kind === 'question' ? {
        id, kind: 'question', title: 'Your agent has a question', detail: '',
        questions: array(approval.raw.questions).map((question, index) => {
          const item = object(question);
          return { id: String(index), question: string(item.question).slice(0, 12_000), options: array(item.options).map((option) => ({ label: string(object(option).label).slice(0, 500), description: string(object(option).description).slice(0, 2000) })), multiple: item.multiple === true };
        }),
      } : { id, kind: 'permission', title: string(approval.raw.permission, 'Permission requested').slice(0, 500), detail: text({ patterns: approval.raw.patterns, metadata: approval.raw.metadata }, 24_000) });
      const active = status?.type === 'busy' || status?.type === 'retry';
      const preview = approvals.length ? 'Your agent is waiting for your input.' : status?.type === 'retry' ? string(status.message, 'Waiting to retry the request.') : this.previews.get(nativeId) || (active ? 'Working on your task…' : 'Ready for your next instruction.');
      return {
        id: `${this.config.id}:${nativeId}`, nativeId, sourceId: this.config.id, provider: 'opencode',
        title: string(session.title, 'OpenCode session').slice(0, 500), directory: string(session.directory).slice(0, 2000),
        status: approvals.length ? 'waiting' : active ? 'working' : 'idle', preview: preview.slice(0, 2000),
        updatedAt: number(object(session.time).updated, Date.now()),
        ...(session.parentID ? { parentId: `${this.config.id}:${string(session.parentID)}` } : {}),
        capabilities: { messages: true, prompt: true, stop: true }, approvals,
      };
    });
  }

  private model(value?: string) {
    if (!value) return {};
    const separator = value.indexOf('/');
    if (separator < 1 || separator === value.length - 1) throw new Error('Select a model with its provider, such as openai/model-name.');
    return { model: { providerID: value.slice(0, separator), modelID: value.slice(separator + 1) } };
  }
  private async messages(agent: LocalAgent): Promise<AgentDetail> {
    const response = array(await this.request(`/session/${encodeURIComponent(agent.nativeId)}/message?limit=200`, agent.directory));
    const messages: Message[] = [];
    for (const entry of response) {
      const item = object(entry); const info = object(item.info);
      const content = array(item.parts).map(object);
      const role = info.role === 'user' ? 'user' as const : 'assistant' as const;
      const messageText = content.filter((part) => part.type === 'text').map((part) => string(part.text)).join('\n\n').slice(0, 32_000);
      if (messageText) messages.push({ id: string(info.id), role, text: messageText });
      for (const part of content.filter((part) => part.type === 'tool')) {
        const state = object(part.state);
        messages.push({ id: string(part.id), role: 'tool', title: string(state.title, string(part.tool, 'Agent activity')).slice(0, 500), state: string(state.status), text: text(state.output ?? state.error ?? state.input, 12_000) });
      }
      if (info.error) messages.push({ id: `${string(info.id)}:error`, role: 'system', text: text(info.error, 3000) });
    }
    const last = [...messages].reverse().find((message) => message.role === 'assistant');
    if (last) this.previews.set(agent.nativeId, last.text.slice(0, 2000));
    return boundedDetail(messages);
  }
  async execute(command: Command, agent?: LocalAgent): Promise<unknown> {
    if (command.action === 'source.options') {
      const providers = object(await this.request('/config/providers', command.workspace));
      const agents = array(await this.request('/agent', command.workspace));
      return {
        models: array(providers.providers).flatMap((value) => { const provider = object(value); return Object.entries(object(provider.models)).map(([id, model]) => ({ id: `${string(provider.id)}/${id}`, name: `${string(object(model).name, id)} · ${string(provider.name, string(provider.id))}` })); }),
        agents: agents.map(object).filter((item) => item.mode !== 'subagent' && item.hidden !== true).map((item) => ({ id: string(item.name), name: string(item.name) })),
      } satisfies SourceOptions;
    }
    if (command.action === 'agent.create') {
      const session = object(await this.request('/session', command.workspace, { title: command.text.split('\n')[0].slice(0, 90) }));
      const id = string(session.id);
      if (!id) throw new Error('OpenCode did not return a session ID.');
      try { await this.request(`/session/${encodeURIComponent(id)}/prompt_async`, command.workspace, { parts: [{ type: 'text', text: command.text }], ...this.model(command.model), ...(command.agent ? { agent: command.agent } : {}) }); }
      catch (error) { throw new Error(`Session ${id} was created, but its prompt was not confirmed. Check the session before retrying. ${error instanceof Error ? error.message : ''}`); }
      return { agentId: `${this.config.id}:${id}` };
    }
    if (!agent || !this.sessions.has(agent.nativeId)) throw new Error('That OpenCode session is no longer available.');
    if (command.action === 'agent.messages') return this.messages(agent);
    if (command.action === 'agent.prompt') await this.request(`/session/${encodeURIComponent(agent.nativeId)}/prompt_async`, agent.directory, { parts: [{ type: 'text', text: command.text }], ...this.model(command.model) });
    if (command.action === 'agent.stop') await this.request(`/session/${encodeURIComponent(agent.nativeId)}/abort`, agent.directory, {});
    if (command.action === 'agent.approval' || command.action === 'agent.answer') {
      const approval = this.approvals.get(command.approvalId);
      if (!approval || approval.sessionId !== agent.nativeId) throw new Error('This request has already been answered or expired.');
      if (command.action === 'agent.approval') {
        if (approval.kind !== 'permission') throw new Error('This request needs a written answer.');
        await this.request(`/permission/${encodeURIComponent(command.approvalId)}/reply`, approval.directory, { reply: command.decision === 'approve' ? 'once' : 'reject' });
      } else {
        if (approval.kind !== 'question') throw new Error('This request needs a permission decision.');
        const answers = array(approval.raw.questions).map((_, index) => command.answers[String(index)] || []);
        if (answers.some((answer) => !answer.length)) throw new Error('Answer each of the agent’s questions.');
        await this.request(`/question/${encodeURIComponent(command.approvalId)}/reply`, approval.directory, { answers });
      }
      this.approvals.delete(command.approvalId);
    }
    return { ok: true };
  }
  close() {}
}
