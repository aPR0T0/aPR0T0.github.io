import type { AgentStatus, Approval, Command, LocalAgent, Message, SourceOptions } from '../../shared/types';
import type { SourceConfig } from '../config';
import { array, boundedDetail, number, object, string, text, type Adapter, type ObjectValue } from './common';
import { CodexRPC } from './codex-rpc';

const SOURCES = ['cli', 'vscode', 'exec', 'appServer', 'subAgent', 'subAgentReview', 'subAgentCompact', 'subAgentThreadSpawn', 'subAgentOther', 'unknown'];
interface Request { id: string | number; method: string; params: ObjectValue; approval: Approval }

export class CodexAdapter implements Adapter {
  private rpc: CodexRPC;
  private threads = new Map<string, ObjectValue>();
  private loaded = new Set<string>();
  private subscribed = new Set<string>();
  private requests = new Map<string, Request>();
  private liveItems = new Map<string, Map<string, ObjectValue>>();
  private liveTurns = new Map<string, string>();
  get pid() { return this.rpc.pid; }
  constructor(public config: SourceConfig, private changed: (agentId?: string) => void = () => {}) {
    this.rpc = new CodexRPC(config);
    this.rpc.onMessage = (message) => this.event(message);
    this.rpc.onDisconnect = () => { this.subscribed.clear(); this.loaded.clear(); this.requests.clear(); this.liveItems.clear(); this.liveTurns.clear(); };
  }

  private event(message: ObjectValue) {
    const method = string(message.method); const params = object(message.params);
    const threadId = string(params.threadId, string(object(params.thread).id));
    if (message.id !== undefined && (typeof message.id === 'string' || typeof message.id === 'number')) {
      const id = `${typeof message.id}:${message.id}`;
      let approval: Approval;
      if (method === 'item/tool/requestUserInput' || method === 'tool/requestUserInput') {
        approval = { id, kind: 'question', title: 'Codex has a question', detail: '', questions: array(params.questions).map((raw) => {
          const question = object(raw);
          return { id: string(question.id).slice(0, 200), question: string(question.question).slice(0, 12_000), options: array(question.options).map((option) => ({ label: string(object(option).label).slice(0, 500), description: string(object(option).description).slice(0, 2000) })) };
        }) };
      } else if (['item/commandExecution/requestApproval', 'item/fileChange/requestApproval', 'item/permissions/requestApproval'].includes(method)) {
        const network = object(params.networkApprovalContext);
        const permitted = !Array.isArray(params.availableDecisions) || params.availableDecisions.includes('accept');
        approval = { id, kind: permitted ? 'permission' : 'unsupported', title: network.host ? `Network access to ${string(network.host)}` : method.includes('commandExecution') ? 'Run a command' : method.includes('fileChange') ? 'Apply file changes' : 'Grant requested permissions for this turn', detail: text(params, 24_000) };
      } else approval = { id, kind: 'unsupported', title: `Input requested: ${method}`.slice(0, 500), detail: text(params, 24_000) };
      if (this.requests.size < 1000) this.requests.set(id, { id: message.id, method, params, approval });
    }
    if (method === 'serverRequest/resolved') this.requests.delete(`${typeof params.requestId}:${String(params.requestId)}`);
    if (method === 'thread/status/changed' && this.threads.has(threadId)) this.threads.get(threadId)!.status = params.status;
    if (method === 'thread/started') { const thread = object(params.thread); if (string(thread.id)) this.threads.set(string(thread.id), thread); }
    if (method === 'turn/started') this.liveTurns.set(threadId, string(object(params.turn).id));
    if (method === 'turn/completed') {
      this.liveTurns.delete(threadId);
      for (const [key, request] of this.requests) if (request.params.threadId === threadId) this.requests.delete(key);
    }
    if (threadId && (method === 'item/started' || method === 'item/completed' || method === 'item/agentMessage/delta' || method === 'item/commandExecution/outputDelta')) {
      if (!this.liveItems.has(threadId)) {
        if (this.liveItems.size >= 200) this.liveItems.delete(this.liveItems.keys().next().value!);
        this.liveItems.set(threadId, new Map());
      }
      const items = this.liveItems.get(threadId)!;
      if (method === 'item/started' || method === 'item/completed') {
        const item = object(params.item); const id = string(item.id);
        // Raw reasoning is never forwarded; only visible conversation and tool output.
        if (id && item.type !== 'reasoning') items.set(id, item);
      } else {
        const id = string(params.itemId);
        const item = items.get(id) || { id, type: method.includes('agentMessage') ? 'agentMessage' : 'commandExecution' };
        const key = method.includes('agentMessage') ? 'text' : 'aggregatedOutput';
        item[key] = (string(item[key]) + string(params.delta)).slice(-32_000);
        items.set(id, item);
      }
      while (items.size > 200) items.delete(items.keys().next().value!);
    }
    this.changed(threadId ? `${this.config.id}:${threadId}` : undefined);
  }

  async refresh(): Promise<LocalAgent[]> {
    await this.rpc.connect();
    const [listed, loaded] = await Promise.all([
      this.rpc.request('thread/list', { limit: 200, sortKey: 'updated_at', sourceKinds: SOURCES, archived: false }),
      this.rpc.request('thread/loaded/list', {}),
    ]);
    const threads = new Map(array(object(listed).data).map((item) => { const thread = object(item); return [string(thread.id), thread] as const; }).filter(([id]) => id));
    this.loaded = new Set(array(object(loaded).data).map((value) => string(value)).filter(Boolean));
    let cursor = string(object(loaded).nextCursor);
    while (cursor) {
      if (this.loaded.size >= 2000) throw new Error('More than 2,000 loaded Codex threads. Split them across app-server connections.');
      const page = object(await this.rpc.request('thread/loaded/list', { cursor }));
      for (const id of array(page.data)) if (typeof id === 'string') this.loaded.add(id);
      const next = string(page.nextCursor); if (next === cursor) break; cursor = next;
    }
    for (const id of this.loaded) {
      if (!this.subscribed.has(id)) {
        // Only attach to threads confirmed loaded in this exact app-server. Never
        // resume historical threads belonging to an unrelated terminal process.
        const result = object(await this.rpc.request('thread/resume', { threadId: id }));
        const thread = object(result.thread);
        if (string(thread.id)) threads.set(id, thread);
        this.subscribed.add(id);
      } else if (!threads.has(id)) {
        const result = object(await this.rpc.request('thread/read', { threadId: id, includeTurns: false }));
        if (string(object(result.thread).id)) threads.set(id, object(result.thread));
      }
    }
    for (const id of this.subscribed) if (!this.loaded.has(id)) this.subscribed.delete(id);
    this.threads = threads;
    return [...threads.values()].map((thread) => {
      const id = string(thread.id); const runtime = object(thread.status); const flags = array(runtime.activeFlags);
      const approvals = [...this.requests.values()].filter((request) => request.params.threadId === id).map((request) => request.approval);
      const attached = this.loaded.has(id);
      const status: AgentStatus = approvals.length || flags.some((flag) => flag === 'waitingOnApproval' || flag === 'waitingOnUserInput') ? 'waiting' : runtime.type === 'active' ? 'working' : runtime.type === 'systemError' ? 'error' : attached ? 'idle' : 'unknown';
      const latest = [...(this.liveItems.get(id)?.values() || [])].reverse().find((item) => item.type === 'agentMessage');
      return {
        id: `${this.config.id}:${id}`, nativeId: id, sourceId: this.config.id, provider: 'codex', title: string(thread.name, string(thread.preview, 'Codex session')).slice(0, 500), directory: string(thread.cwd).slice(0, 2000), status,
        preview: attached ? (latest ? string(latest.text) : status === 'working' ? 'Working on your task…' : status === 'waiting' ? 'Codex is waiting for input.' : 'Ready for your next instruction.').slice(0, 2000) : 'Stored session · connect the app-server running this thread for live control.',
        updatedAt: number(thread.updatedAt, number(thread.createdAt, Date.now() / 1000)) * 1000,
        ...(thread.model ? { model: string(thread.model).slice(0, 200) } : {}),
        capabilities: { messages: true, prompt: attached, stop: attached }, approvals,
      };
    });
  }

  private itemMessage(raw: unknown): Message | undefined {
    const item = object(raw); const id = string(item.id);
    if (!id) return;
    if (item.type === 'userMessage') return { id, role: 'user', text: array(item.content).map((content) => string(object(content).text)).filter(Boolean).join('\n').slice(0, 32_000) };
    if (item.type === 'agentMessage' || item.type === 'plan') return { id, role: 'assistant', text: string(item.text).slice(0, 32_000) };
    if (item.type === 'commandExecution') return { id, role: 'tool', title: string(item.command, 'Run command').slice(0, 500), state: string(item.status), text: text(item.aggregatedOutput, 12_000) };
    if (item.type === 'fileChange') return { id, role: 'tool', title: 'File changes', state: string(item.status), text: array(item.changes).map((value) => { const change = object(value); return `${string(change.path)}\n${string(change.diff)}`; }).join('\n\n').slice(0, 24_000) };
    if (item.type === 'mcpToolCall' || item.type === 'dynamicToolCall') return { id, role: 'tool', title: string(item.tool, 'Tool call'), state: string(item.status), text: text(item.result ?? item.error ?? item.arguments, 12_000) };
    return undefined;
  }
  private async read(id: string) { return object(object(await this.rpc.request('thread/read', { threadId: id, includeTurns: true })).thread); }
  private async activeTurn(id: string) {
    const thread = await this.read(id);
    return array(thread.turns).map(object).find((turn) => turn.status === 'inProgress')?.id || this.liveTurns.get(id);
  }
  async execute(command: Command, agent?: LocalAgent): Promise<unknown> {
    if (command.action === 'source.options') {
      const models: SourceOptions['models'] = [];
      let cursor: string | undefined;
      do {
        const result = object(await this.rpc.request('model/list', { limit: 100, ...(cursor ? { cursor } : {}) }));
        for (const item of array(result.data).map(object)) models.push({ id: string(item.model, string(item.id)), name: string(item.displayName, string(item.model, string(item.id))) });
        const next = string(result.nextCursor); if (next === cursor) break; cursor = next;
      } while (cursor && models.length < 1000);
      return { models, agents: [] } satisfies SourceOptions;
    }
    if (command.action === 'agent.create') {
      const result = object(await this.rpc.request('thread/start', { cwd: command.workspace, ...(command.model ? { model: command.model } : {}) }));
      const thread = object(result.thread); const id = string(thread.id);
      if (!id) throw new Error('Codex did not return a thread ID.');
      this.loaded.add(id); this.subscribed.add(id); this.threads.set(id, thread);
      try { await this.rpc.request('turn/start', { threadId: id, input: [{ type: 'text', text: command.text }] }); }
      catch (error) { throw new Error(`Thread ${id} was created, but the prompt was not confirmed. Check it before retrying. ${error instanceof Error ? error.message : ''}`); }
      return { agentId: `${this.config.id}:${id}` };
    }
    if (!agent || !this.threads.has(agent.nativeId)) throw new Error('That Codex thread is no longer available.');
    const id = agent.nativeId;
    if (command.action === 'agent.messages') {
      const thread = await this.read(id);
      const items = new Map<string, ObjectValue>();
      for (const turn of array(thread.turns).map(object)) for (const raw of array(turn.items)) { const item = object(raw); items.set(string(item.id), item); }
      for (const [key, item] of this.liveItems.get(id) || []) items.set(key, item);
      return boundedDetail([...items.values()].map((item) => this.itemMessage(item)).filter((item): item is Message => !!item));
    }
    if (!this.loaded.has(id)) throw new Error('This thread is not loaded in the connected Codex app-server. Open it in that server first.');
    if (command.action === 'agent.prompt') {
      const active = await this.activeTurn(id);
      await this.rpc.request(active ? 'turn/steer' : 'turn/start', { threadId: id, input: [{ type: 'text', text: command.text }], ...(active ? { expectedTurnId: active } : command.model ? { model: command.model } : {}) });
    }
    if (command.action === 'agent.stop') {
      const turnId = await this.activeTurn(id);
      if (!turnId) throw new Error('This Codex thread has no running turn.');
      await this.rpc.request('turn/interrupt', { threadId: id, turnId });
    }
    if (command.action === 'agent.approval' || command.action === 'agent.answer') {
      const request = this.requests.get(command.approvalId);
      if (!request || request.params.threadId !== id) throw new Error('This request was already answered or has expired.');
      if (command.action === 'agent.answer') {
        if (request.approval.kind !== 'question') throw new Error('This request needs a permission decision.');
        const answers: Record<string, { answers: string[] }> = {};
        for (const question of request.approval.questions || []) {
          if (!command.answers[question.id]?.length) throw new Error('Answer each of the agent’s questions.');
          answers[question.id] = { answers: command.answers[question.id] };
        }
        this.rpc.reply(request.id, { answers });
      } else {
        if (request.approval.kind !== 'permission') throw new Error('This request must be answered in Codex’s original client.');
        this.rpc.reply(request.id, request.method === 'item/permissions/requestApproval' ? { permissions: command.decision === 'approve' ? request.params.permissions : {}, scope: 'turn' } : { decision: command.decision === 'approve' ? 'accept' : 'decline' });
      }
      this.requests.delete(command.approvalId);
    }
    return { ok: true };
  }
  close() { this.rpc.close(); }
}
