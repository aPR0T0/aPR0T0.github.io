import type { AgentDetail, Command, LocalAgent, Message, Source } from '../../shared/types';
import type { SourceConfig } from '../config';

export type ObjectValue = Record<string, unknown>;
export const object = (value: unknown): ObjectValue => value && typeof value === 'object' && !Array.isArray(value) ? value as ObjectValue : {};
export const array = (value: unknown): unknown[] => Array.isArray(value) ? value : [];
export const string = (value: unknown, fallback = '') => typeof value === 'string' ? value : fallback;
export const number = (value: unknown, fallback = 0) => typeof value === 'number' && Number.isFinite(value) ? value : fallback;
export const text = (value: unknown, max = 12_000) => (typeof value === 'string' ? value : JSON.stringify(value ?? '', null, 2)).slice(0, max);

export interface Adapter {
  config: SourceConfig;
  refresh(): Promise<LocalAgent[]>;
  execute(command: Command, agent?: LocalAgent): Promise<unknown>;
  close(): void;
  pid?: number;
}
export function sourceStatus(config: SourceConfig, connected: boolean, error?: string): Source {
  return { id: config.id, label: config.label, provider: config.provider, connected, canCreate: true, ...(error ? { error: error.slice(0, 1000) } : {}) };
}
export function boundedDetail(messages: Message[]): AgentDetail {
  let remaining = 240_000;
  const selected: Message[] = [];
  for (const message of messages.slice(-200).reverse()) {
    const size = Buffer.byteLength(JSON.stringify(message));
    if (size > remaining) break;
    remaining -= size; selected.unshift(message);
  }
  return { messages: selected, truncated: selected.length !== messages.length };
}
