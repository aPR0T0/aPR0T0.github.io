import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import type { Request } from 'express';

export const secret = () => randomBytes(32).toString('base64url');
export const hash = (value: string) => createHash('sha256').update(value).digest('hex');
export function matches(value: string, expectedHash: string): boolean {
  const actual = Buffer.from(hash(value), 'hex');
  const expected = Buffer.from(expectedHash, 'hex');
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}
export function bearer(request: Pick<Request, 'headers'>): string {
  const authorization = request.headers.authorization;
  return authorization?.startsWith('Bearer ') ? authorization.slice(7) : '';
}
export function cookie(request: Pick<Request, 'headers'>, name: string): string {
  return (request.headers.cookie || '').split(';').map((part) => part.trim()).find((part) => part.startsWith(`${name}=`))?.slice(name.length + 1) || '';
}
export class HttpError extends Error {
  constructor(public status: number, message: string) { super(message); }
}
