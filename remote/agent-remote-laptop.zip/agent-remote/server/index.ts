import 'dotenv/config';
import { readConfig } from './config';
import { createRelay } from './app';

const config = readConfig();
const relay = createRelay(config);
relay.server.listen(config.port, config.host, () => {
  console.log(`Agent Remote relay listening on ${config.host}:${config.port}`);
  console.log(`Phone app: ${config.origin}`);
  console.log('Authentication: relay API key + verified passkey');
});
relay.server.on('error', (error) => { console.error(error.message); process.exitCode = 1; void relay.close(); });
for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => { void relay.close().then(() => process.exit(0)); });
