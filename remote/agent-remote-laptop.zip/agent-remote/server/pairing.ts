import { randomInt, randomUUID } from 'node:crypto';
import { Router } from 'express';
import { rateLimit } from 'express-rate-limit';
import { z } from 'zod';
import { deviceIdentitySchema, type DeviceIdentity } from '../shared/types';
import { Auth } from './auth';
import { Store } from './store';
import { bearer, hash, HttpError, matches, secret } from './security';

interface Pairing {
  requestId: string;
  identity: DeviceIdentity;
  code: string;
  pollHash: string;
  expiresAt: number;
  deviceToken?: string;
}
const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const codeSchema = z.string().transform((value) => value.replace(/[\s-]/g, '').toUpperCase()).pipe(z.string().regex(/^[A-Z2-9]{8}$/));

export class Pairings {
  readonly router = Router();
  private pending = new Map<string, Pairing>();
  onChange = () => {};
  constructor(private store: Store, auth: Auth) {
    const startLimit = rateLimit({ windowMs: 15 * 60_000, limit: 8, standardHeaders: 'draft-8', legacyHeaders: false, message: { error: 'Too many pairing requests. Try again in 15 minutes.' } });
    const claimLimit = rateLimit({ windowMs: 60_000, limit: 15, standardHeaders: 'draft-8', legacyHeaders: false, message: { error: 'Too many pairing attempts. Try again in a minute.' } });
    const pollLimit = rateLimit({ windowMs: 60_000, limit: 180, standardHeaders: 'draft-8', legacyHeaders: false, message: { error: 'Polling too quickly. Wait a moment.' } });
    this.router.post('/request', startLimit, (req, res) => {
      this.sweep();
      const identity = deviceIdentitySchema.parse(req.body);
      if (this.store.identityTaken(identity) || [...this.pending.values()].some((pair) => pair.identity.id.toLowerCase() === identity.id.toLowerCase() || pair.identity.name.toLowerCase() === identity.name.toLowerCase())) throw new HttpError(409, 'That computer name or ID is already in use. Choose a unique one.');
      if (this.pending.size >= 100 || this.store.state.devices.length >= 100) throw new HttpError(429, 'The relay has reached its pairing limit.');
      const requestId = randomUUID(); const pollToken = secret();
      let code: string;
      do { code = Array.from({ length: 8 }, () => alphabet[randomInt(alphabet.length)]).join(''); } while ([...this.pending.values()].some((item) => item.code === code));
      const expiresAt = Date.now() + 10 * 60_000;
      this.pending.set(requestId, { requestId, identity, code, pollHash: hash(pollToken), expiresAt });
      res.status(201).json({ requestId, code: `${code.slice(0, 4)}-${code.slice(4)}`, pollToken, expiresAt });
    });
    this.router.post('/inspect', auth.requireSession, claimLimit, (req, res) => {
      const code = codeSchema.parse(req.body?.code);
      const pairing = this.findCode(code);
      res.json({ ...pairing.identity, requestId: pairing.requestId, expiresAt: pairing.expiresAt });
    });
    this.router.post('/approve', auth.requireSession, claimLimit, (req, res) => {
      const body = z.object({ requestId: z.string().uuid(), code: codeSchema }).parse(req.body);
      const pairing = this.findCode(body.code);
      if (pairing.requestId !== body.requestId || pairing.deviceToken) throw new HttpError(409, 'This pairing request has already been used.');
      if (this.store.identityTaken(pairing.identity)) throw new HttpError(409, 'That name or ID is already attached. Restart pairing with a unique identity.');
      pairing.deviceToken = `ard_${secret()}`;
      this.store.state.devices.push({ ...pairing.identity, tokenHash: hash(pairing.deviceToken), pairedAt: Date.now(), lastSeen: Date.now() });
      this.store.save(); this.onChange();
      res.json({ ok: true, deviceId: pairing.identity.id });
    });
    this.router.get('/:id/poll', pollLimit, (req, res) => {
      const pairing = this.lookup(z.string().parse(req.params.id), bearer(req));
      res.json(pairing.deviceToken ? { status: 'approved', deviceToken: pairing.deviceToken, deviceId: pairing.identity.id } : { status: 'pending' });
    });
    this.router.post('/:id/ack', pollLimit, (req, res) => {
      const pairing = this.lookup(z.string().parse(req.params.id), bearer(req));
      if (!pairing.deviceToken) throw new HttpError(409, 'Pairing has not been approved.');
      this.pending.delete(pairing.requestId);
      res.json({ ok: true });
    });
  }
  private findCode(code: string) {
    this.sweep();
    const pairing = [...this.pending.values()].find((pairing) => pairing.code === code && !pairing.deviceToken);
    if (!pairing) throw new HttpError(404, 'That pairing code was not found or has expired. Check the code on your computer.');
    return pairing;
  }
  private lookup(id: string, token: string) {
    this.sweep();
    const pairing = this.pending.get(id);
    if (!pairing || !matches(token, pairing.pollHash)) throw new HttpError(404, 'Pairing request expired or not found. Start pairing again.');
    return pairing;
  }
  removeForDevice(id: string) { for (const [key, value] of this.pending) if (value.identity.id === id) this.pending.delete(key); }
  sweep() { for (const [key, value] of this.pending) if (value.expiresAt < Date.now()) this.pending.delete(key); }
}
