import {
  generateAuthenticationOptions, generateRegistrationOptions, verifyAuthenticationResponse, verifyRegistrationResponse,
  type AuthenticationResponseJSON, type RegistrationResponseJSON,
} from '@simplewebauthn/server';
import { Router, type Request, type RequestHandler, type Response } from 'express';
import { rateLimit } from 'express-rate-limit';
import { z } from 'zod';
import type { RelayConfig } from './config';
import { Store } from './store';
import { bearer, cookie, hash, HttpError, matches, secret } from './security';

export interface Session { hash: string; lastActivity: number; createdAt: number; kind?: 'web' | 'native'; credentialId?: string }
interface Challenge { value: string; kind: 'register' | 'authenticate'; expiresAt: number; sessionHash?: string; enrollmentSession?: string; bootstrap: boolean }
const SESSION_COOKIE = 'ar_session';
const IDLE_TIMEOUT = 15 * 60_000;
const MAX_SESSION = 12 * 60 * 60_000;
const verificationSchema = z.object({ challengeId: z.string().min(30).max(100), response: z.object({ id: z.string().min(1).max(2048) }).passthrough() });
const optionsSchema = z.object({ enrollmentToken: z.string().trim().regex(/^[A-Za-z0-9_-]{30,100}$/).optional() }).strict();

export class Auth {
  readonly router = Router();
  readonly sessions = new Map<string, Session>();
  private challenges = new Map<string, Challenge>();
  private enrollments = new Map<string, { sessionHash: string; expiresAt: number }>();
  private apiKeyHash: string;
  onExpire: (hash: string) => void = () => {};

  constructor(private config: RelayConfig, private store: Store) {
    this.apiKeyHash = hash(config.apiKey);
    const limiter = rateLimit({ windowMs: 15 * 60_000, limit: 40, standardHeaders: 'draft-8', legacyHeaders: false, message: { error: 'Too many unlock attempts. Try again in 15 minutes.' } });
    this.router.get('/session', (req, res) => res.json({ authenticated: !!this.session(req) }));
    this.router.post('/logout', (req, res) => { const session = this.session(req); if (session) this.expire(session.hash); res.clearCookie(SESSION_COOKIE, this.cookieOptions()); res.json({ ok: true }); });
    this.router.post('/touch', this.requireSession, (_req, res) => res.json({ ok: true }));
    this.router.post('/enrollment', this.requireSession, limiter, (req, res) => res.json(this.createEnrollment(this.session(req)!.hash)));
    this.router.post('/options', limiter, async (req, res) => {
      this.checkApiKey(req);
      const body = optionsSchema.parse(req.body);
      const bootstrap = !this.store.hasCredentials();
      const enrollmentSession = body.enrollmentToken ? this.takeEnrollment(body.enrollmentToken) : undefined;
      const register = bootstrap || !!enrollmentSession;
      if (!register && this.store.state.credentials.length === 0) throw new HttpError(409, 'Link this browser using a device-link code. On your unlocked Android app, choose Settings → Authorize another phone, then select “Link a new device” here.');
      if (register && this.store.state.credentials.length >= 10) throw new HttpError(409, 'This relay already has 10 passkeys.');
      const options = register ? await this.registrationOptions() : await generateAuthenticationOptions({ rpID: this.config.rpID, userVerification: 'required', allowCredentials: this.store.state.credentials.map(({ id, transports }) => ({ id, transports })) });
      const kind = register ? 'register' : 'authenticate';
      const challengeId = this.addChallenge({ value: options.challenge, kind, bootstrap, enrollmentSession, expiresAt: Date.now() + 5 * 60_000 });
      res.json({ kind, challengeId, options });
    });
    this.router.post('/verify', limiter, async (req, res) => {
      this.checkApiKey(req);
      const body = verificationSchema.parse(req.body);
      const challenge = this.takeChallenge(body.challengeId);
      if (challenge.sessionHash) throw new HttpError(400, 'Use the passkey registration endpoint.');
      await this.verify(challenge, body.response);
      this.issueSession(res);
      res.json({ ok: true });
    });
    this.router.post('/register/options', this.requireSession, limiter, async (req, res) => {
      if (this.store.state.credentials.length >= 10) throw new HttpError(400, 'This relay already has 10 passkeys.');
      const session = this.session(req)!;
      const options = await this.registrationOptions();
      const challengeId = this.addChallenge({ value: options.challenge, kind: 'register', bootstrap: false, sessionHash: session.hash, expiresAt: Date.now() + 5 * 60_000 });
      res.json({ challengeId, options });
    });
    this.router.post('/register/verify', this.requireSession, limiter, async (req, res) => {
      const body = verificationSchema.parse(req.body);
      const challenge = this.takeChallenge(body.challengeId);
      if (challenge.sessionHash !== this.session(req)?.hash || challenge.kind !== 'register') throw new HttpError(403, 'This passkey challenge belongs to another session.');
      await this.verify(challenge, body.response);
      res.json({ ok: true });
    });
  }

  private cookieOptions() { return { httpOnly: true, secure: this.config.secure, sameSite: 'strict' as const, path: '/' }; }
  checkApiKey(req: Request) {
    if (!matches(bearer(req), this.apiKeyHash)) throw new HttpError(401, 'That relay API key isn’t correct.');
  }
  private async registrationOptions() {
    return generateRegistrationOptions({
      rpName: 'Agent Remote', rpID: this.config.rpID, userName: 'Personal workspace', userDisplayName: 'Agent Remote',
      userID: new Uint8Array(Buffer.from(this.store.state.userId, 'base64url')),
      attestationType: 'none',
      authenticatorSelection: { residentKey: 'required', userVerification: 'required' },
      excludeCredentials: this.store.state.credentials.map(({ id, transports }) => ({ id, transports })),
    });
  }
  private addChallenge(value: Challenge) {
    this.sweep();
    if (this.challenges.size >= 200) throw new HttpError(429, 'Too many pending unlock requests. Try again shortly.');
    const id = secret(); this.challenges.set(id, value); return id;
  }
  private takeChallenge(id: string) {
    const challenge = this.challenges.get(id);
    this.challenges.delete(id);
    if (!challenge || challenge.expiresAt < Date.now()) throw new HttpError(400, 'Your unlock request expired. Please try again.');
    return challenge;
  }
  private async verify(challenge: Challenge, response: Record<string, unknown>) {
    try {
      if (challenge.kind === 'register') {
        const { verified, registrationInfo } = await verifyRegistrationResponse({ response: response as unknown as RegistrationResponseJSON, expectedChallenge: challenge.value, expectedOrigin: this.config.origin, expectedRPID: this.config.rpID, requireUserVerification: true });
        if (!verified || !registrationInfo) throw new Error('Not verified');
        // Recheck after verification: two bootstrap ceremonies must not race to enroll.
        if (challenge.bootstrap && this.store.hasCredentials()) throw new Error('Already enrolled');
        const authorizer = challenge.sessionHash || challenge.enrollmentSession;
        if (!challenge.bootstrap && (!authorizer || !this.validSession(authorizer))) throw new Error('Authorizing device locked or expired');
        if (this.store.state.credentials.length >= 10) throw new Error('Passkey limit reached');
        if (this.store.state.credentials.some((item) => item.id === registrationInfo.credential.id)) throw new Error('Already registered');
        const credential = registrationInfo.credential;
        this.store.state.credentials.push({ id: credential.id, publicKey: Buffer.from(credential.publicKey).toString('base64url'), counter: credential.counter, transports: credential.transports, createdAt: Date.now() });
      } else {
        const credential = this.store.state.credentials.find((item) => item.id === response.id);
        if (!credential) throw new Error('Unknown passkey');
        const result = await verifyAuthenticationResponse({ response: response as unknown as AuthenticationResponseJSON, expectedChallenge: challenge.value, expectedOrigin: this.config.origin, expectedRPID: this.config.rpID, requireUserVerification: true, credential: { id: credential.id, publicKey: new Uint8Array(Buffer.from(credential.publicKey, 'base64url')), counter: credential.counter, transports: credential.transports } });
        if (!result.verified) throw new Error('Not verified');
        credential.counter = Math.max(credential.counter, result.authenticationInfo.newCounter);
      }
      this.store.save();
    } catch {
      throw new HttpError(400, 'Passkey verification failed. Check your relay URL and try unlocking again.');
    }
  }
  private issueSession(res: Response) {
    const token = this.createSession('web');
    res.cookie(SESSION_COOKIE, token, { ...this.cookieOptions(), maxAge: MAX_SESSION });
  }
  createSession(kind: 'web' | 'native', credentialId?: string) {
    if (this.sessions.size >= 100) this.expire(this.sessions.keys().next().value!);
    const token = `${kind === 'native' ? 'arn_' : ''}${secret()}`;
    const tokenHash = hash(token);
    this.sessions.set(tokenHash, { hash: tokenHash, lastActivity: Date.now(), createdAt: Date.now(), kind, credentialId });
    return token;
  }
  createEnrollment(sessionHash: string) {
    this.sweep();
    if (!this.validSession(sessionHash)) throw new HttpError(401, 'Unlock your trusted device first.');
    if (this.enrollments.size >= 20) throw new HttpError(429, 'Too many pending device links.');
    const enrollmentToken = secret(); const expiresAt = Date.now() + 5 * 60_000;
    this.enrollments.set(hash(enrollmentToken), { sessionHash, expiresAt });
    return { enrollmentToken, expiresAt };
  }
  takeEnrollment(token: string) {
    this.sweep();
    const digest = hash(token);
    const ticket = this.enrollments.get(digest);
    if (!ticket || !this.validSession(ticket.sessionHash)) throw new HttpError(409, 'The device-link code expired or was already used. Generate a new code on an unlocked trusted device.');
    this.enrollments.delete(digest);
    return ticket.sessionHash;
  }
  validSession(tokenHash: string): Session | undefined {
    const value = this.sessions.get(tokenHash);
    if (value && Date.now() - value.lastActivity < IDLE_TIMEOUT && Date.now() - value.createdAt < MAX_SESSION) return value;
    if (value) this.expire(tokenHash);
    return undefined;
  }
  session(req: Pick<Request, 'headers'>, touch = false) {
    const value = this.nativeSession(req) || this.webSession(req);
    if (value && touch) value.lastActivity = Date.now();
    return value;
  }
  private webSession(req: Pick<Request, 'headers'>) {
    const value = this.validSession(hash(cookie(req, SESSION_COOKIE)));
    return value?.kind !== 'native' ? value : undefined;
  }
  nativeSession(req: Pick<Request, 'headers'>) {
    const token = bearer(req);
    if (!token.startsWith('arn_')) return undefined;
    const value = this.validSession(hash(token));
    return value?.kind === 'native' ? value : undefined;
  }
  requireSession: RequestHandler = (req, _res, next) => {
    // Reading or automatic polling never extends the authentication lifetime.
    const meaningfulAction = req.method !== 'GET' && req.body?.action !== 'agent.messages' && req.body?.action !== 'source.options';
    if (!this.session(req, meaningfulAction)) return next(new HttpError(401, 'Your remote is locked. Unlock it to continue.'));
    next();
  };
  expire(tokenHash: string) { this.sessions.delete(tokenHash); this.onExpire(tokenHash); }
  sweep() {
    for (const [id, value] of this.challenges) if (value.expiresAt < Date.now()) this.challenges.delete(id);
    for (const id of this.sessions.keys()) this.validSession(id);
    for (const [id, value] of this.enrollments) if (value.expiresAt <= Date.now() || !this.validSession(value.sessionHash)) this.enrollments.delete(id);
  }
}
