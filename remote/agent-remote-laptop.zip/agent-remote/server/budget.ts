/** Token buckets bound work done for an authenticated but malfunctioning peer. */
export class MessageBudget {
  private messages = 60;
  private bytes = 12 * 1024 * 1024;
  private at = Date.now();
  take(size: number): boolean {
    const now = Date.now(); const seconds = Math.max(0, now - this.at) / 1000; this.at = now;
    this.messages = Math.min(60, this.messages + seconds * 20);
    this.bytes = Math.min(12 * 1024 * 1024, this.bytes + seconds * 4 * 1024 * 1024);
    if (this.messages < 1 || this.bytes < size) return false;
    this.messages--; this.bytes -= size; return true;
  }
}
