import { createPublicKey, verify } from 'node:crypto';
import { Router } from 'express';
import { rateLimit } from 'express-rate-limit';
import { z } from 'zod';
import type { RelayConfig } from './config';
import { Auth, type EnrollmentGrant } from './auth';
import { Store } from './store';
import { hash, HttpError, secret } from './security';

interface NativeChallenge {
  credentialId: string;
  publicKey: string;
  name: string;
  kind: 'register' | 'authenticate';
  payload: string;
  expiresAt: number;
  enrollment?: EnrollmentGrant;
  bootstrap: boolean;
  platform: 'android' | 'linux';
}
const base64url = z.string().regex(/^[A-Za-z0-9_-]+$/);
const optionsSchema = z.object({ publicKey: base64url.min(80).max(200), name: z.string().trim().min(1).max(80), enrollmentToken: base64url.min(30).max(100).optional(), platform: z.enum(['android', 'linux']).default('android') }).strict();
const verifySchema = z.object({ challengeId: base64url.min(30).max(100), signature: base64url.min(80).max(160) }).strict();

export class NativeAuth {
  readonly router = Router();
  private challenges = new Map<string, NativeChallenge>();

  constructor(config: RelayConfig, store: Store, auth: Auth) {
    const limiter = rateLimit({ windowMs: 15 * 60_000, limit: 40, standardHeaders: 'draft-8', legacyHeaders: false, message: { error: 'Too many unlock attempts. Try again in 15 minutes.' } });
    this.router.post('/enrollment', auth.requireSession, limiter, (req, res) => {
      this.sweep();
      res.json(auth.createEnrollment(auth.session(req)!.hash));
    });
    this.router.post('/browser-ticket', auth.requireSession, limiter, (req, res) => res.json(auth.createBrowserTicket(auth.session(req)!.hash)));
    this.router.post('/options', limiter, (req, res) => {
      auth.checkApiKey(req); this.sweep();
      const body = optionsSchema.parse(req.body);
      let encoded: Buffer;
      try {
        encoded = Buffer.from(body.publicKey, 'base64url');
        const key = createPublicKey({ key: encoded, type: 'spki', format: 'der' });
        if (key.asymmetricKeyType !== 'ec' || key.asymmetricKeyDetails?.namedCurve !== 'prime256v1' || !encoded.equals(key.export({ type: 'spki', format: 'der' }))) throw new Error('Invalid key');
      } catch { throw new HttpError(400, 'Use a P-256 device public key.'); }
      const credentialId = hash(encoded.toString('base64url'));
      const credential = store.state.nativeCredentials.find((credential) => credential.id === credentialId);
      const known = !!credential;
      if (credential && (credential.platform || 'android') !== body.platform) throw new HttpError(409, 'This key is registered for another device platform.');
      const bootstrap = !store.hasCredentials();
      let enrollment: EnrollmentGrant | undefined;
      if (!known && !bootstrap) {
        if (!body.enrollmentToken) throw new HttpError(409, 'This relay already has a trusted phone or passkey. Authorize this phone from an unlocked device, or reset credentials on your relay.');
        enrollment = auth.takeEnrollment(body.enrollmentToken);
      }
      if (!known && store.state.nativeCredentials.length >= 10) throw new HttpError(409, 'The relay already has 10 trusted phones.');
      if (this.challenges.size >= 200) throw new HttpError(429, 'Too many pending unlock challenges.');
      const challengeId = secret(); const expiresAt = Math.min(Date.now() + 2 * 60_000, enrollment?.expiresAt ?? Infinity);
      const kind = known ? 'authenticate' : 'register';
      const payload = Buffer.from(JSON.stringify({ protocol: `agent-remote/${body.platform}-auth/v1`, origin: config.origin, challengeId, nonce: secret(), credentialId, kind, expiresAt }), 'utf8').toString('base64url');
      this.challenges.set(challengeId, { credentialId, publicKey: body.publicKey, name: body.name, kind, payload, expiresAt, enrollment, bootstrap, platform: body.platform });
      res.json({ challengeId, credentialId, kind, payload, expiresAt });
    });
    this.router.post('/verify', limiter, (req, res) => {
      auth.checkApiKey(req);
      const body = verifySchema.parse(req.body);
      const challenge = this.challenges.get(body.challengeId);
      this.challenges.delete(body.challengeId);
      if (!challenge || challenge.expiresAt <= Date.now()) throw new HttpError(400, 'Your unlock challenge expired or was already used.');
      const existing = store.state.nativeCredentials.find((credential) => credential.id === challenge.credentialId);
      if (challenge.kind === 'authenticate' && !existing) throw new HttpError(401, 'This phone is no longer trusted.');
      const key = createPublicKey({ key: Buffer.from(existing?.publicKey || challenge.publicKey, 'base64url'), type: 'spki', format: 'der' });
      if (!verify('sha256', Buffer.from(challenge.payload, 'base64url'), key, Buffer.from(body.signature, 'base64url'))) throw new HttpError(401, 'Biometric key signature verification failed.');
      if (challenge.kind === 'register') {
        if (challenge.bootstrap ? store.hasCredentials() : !challenge.enrollment || challenge.enrollment.expiresAt <= Date.now()) throw new HttpError(409, 'The relay was already enrolled or the link code expired. Request authorization for this phone.');
        if (store.state.nativeCredentials.length >= 10) throw new HttpError(409, 'The relay already has 10 trusted phones.');
        if (existing) throw new HttpError(409, 'This phone is already enrolled.');
        store.state.nativeCredentials.push({ id: challenge.credentialId, publicKey: challenge.publicKey, name: challenge.name, createdAt: Date.now(), platform: challenge.platform });
        store.save();
      }
      res.json({ token: auth.createSession('native', challenge.credentialId), credentialId: challenge.credentialId, idleTimeoutMs: 15 * 60_000, maxAgeMs: 12 * 60 * 60_000 });
    });
  }
  sweep() {
    for (const [id, value] of this.challenges) if (value.expiresAt <= Date.now()) this.challenges.delete(id);
  }
}
