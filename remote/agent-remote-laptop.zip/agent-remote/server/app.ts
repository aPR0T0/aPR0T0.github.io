import { createServer } from 'node:http';
import { randomUUID } from 'node:crypto';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import express, { type ErrorRequestHandler } from 'express';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import { WebSocket, WebSocketServer } from 'ws';
import { z, ZodError } from 'zod';
import { bridgeMessageSchema, commandSchema, type LocalAgent, type Snapshot, type Source } from '../shared/types';
import type { RelayConfig } from './config';
import { Store } from './store';
import { Auth } from './auth';
import { NativeAuth } from './native-auth';
import { Commands } from './commands';
import { MessageBudget } from './budget';
import { Pairings } from './pairing';
import { Transfers } from './transfers';
import type { BridgeCommand } from '../shared/transfers';
import { APP_VERSION } from '../shared/version';
import { bearer, HttpError, matches } from './security';

interface Computer {
  socket: WebSocket;
  alive: boolean;
  agents: LocalAgent[];
  sources: Source[];
  workspaces: string[];
  lastSeen: number;
  lastSnapshot: number;
}
interface Pending { deviceId: string; resolve: (value: unknown) => void; reject: (error: Error) => void; timeout: ReturnType<typeof setTimeout> }

export function createRelay(config: RelayConfig) {
  const store = new Store(config.dataDir);
  const auth = new Auth(config, store);
  const nativeAuth = new NativeAuth(config, store, auth);
  const commands = new Commands(store);
  const pairings = new Pairings(store, auth);
  const app = express();
  const server = createServer(app);
  const wss = new WebSocketServer({ noServer: true, maxPayload: 2 * 1024 * 1024, perMessageDeflate: false });
  const computers = new Map<string, Computer>();
  const viewers = new Map<WebSocket, { sessionHash: string; alive: boolean }>();
  const pending = new Map<string, Pending>();
  const dispatch = (deviceId: string, command: BridgeCommand, tokenHash?: string, timeoutMs = 30_000) => new Promise<unknown>((resolve, reject) => {
    const device = store.state.devices.find((item) => item.id === deviceId);
    const computer = computers.get(deviceId);
    if (!device || (tokenHash && device.tokenHash !== tokenHash) || !computer || computer.socket.readyState !== WebSocket.OPEN) return reject(new HttpError(503, 'The selected computer disconnected or changed identity.'));
    if (pending.size >= 250) return reject(new HttpError(429, 'The relay is busy. Try again shortly.'));
    const requestId = randomUUID();
    const timeout = setTimeout(() => { pending.delete(requestId); reject(new HttpError(504, 'The computer did not respond in time. Check its agent list before trying again.')); }, timeoutMs);
    pending.set(requestId, { deviceId, resolve, reject, timeout });
    send(computer.socket, { type: 'command', requestId, command });
  });
  const transfers = new Transfers(store, auth, (id) => {
    const device = store.state.devices.find((item) => item.id === id);
    const computer = computers.get(id);
    return device ? { id, name: device.name, tokenHash: device.tokenHash, connected: computer?.socket.readyState === WebSocket.OPEN, fresh: !!computer && Date.now() - computer.lastSnapshot < 20_000, agents: computer?.agents || [], sources: computer?.sources || [], workspaces: computer?.workspaces || [] } : undefined;
  }, (id, command, tokenHash) => dispatch(id, command, tokenHash, 15_000));
  app.disable('x-powered-by');
  if (config.trustProxy) app.set('trust proxy', 1);
  app.use(helmet({
    contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'"], imgSrc: ["'self'", 'data:'], connectSrc: ["'self'"], objectSrc: ["'none'"], frameAncestors: ["'none'"], baseUri: ["'self'"], formAction: ["'self'"], upgradeInsecureRequests: config.secure ? [] : null } },
    strictTransportSecurity: config.secure ? undefined : false,
  }));
  app.use('/api', (_req, res, next) => { res.setHeader('Cache-Control', 'no-store'); next(); });
  app.use('/api', (req, _res, next) => {
    const origin = req.headers.origin;
    if (origin && origin !== config.origin) return next(new HttpError(403, 'This request came from a different origin.'));
    if (!origin && bearer(req).startsWith('arn_') && !auth.nativeSession(req)) return next(new HttpError(401, 'Your remote is locked. Unlock it to continue.'));
    const connectorRoute = req.path === '/pairing/request' || /^\/pairing\/[\w-]+\/ack$/.test(req.path);
    const nativeAuthRoute = req.path === '/native/auth/options' || req.path === '/native/auth/verify';
    if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method) && !connectorRoute && !nativeAuthRoute && !auth.nativeSession(req) && origin !== config.origin) return next(new HttpError(403, 'A same-origin request is required.'));
    next();
  });
  app.use(express.json({ limit: '256kb', strict: true }));
  app.get('/api/health', (_req, res) => res.json({ ok: true, version: APP_VERSION }));
  app.use('/api/auth', auth.router);
  app.use('/api/native/auth', nativeAuth.router);
  app.use('/api/pairing', pairings.router);
  app.use('/api/transfers', transfers.router);

  function snapshot(): Snapshot {
    const devices = store.state.devices.map(({ id, name, platform, pairedAt, lastSeen }) => {
      const computer = computers.get(id);
      const fresh = !!computer && Date.now() - computer.lastSnapshot < 20_000;
      return { id, name, platform, pairedAt, lastSeen: computer?.lastSeen || lastSeen, connected: computer?.socket.readyState === WebSocket.OPEN, sources: (computer?.sources || []).map((source) => fresh ? source : { ...source, connected: false, error: 'Waiting for fresh agent status from this computer.' }), workspaces: computer?.workspaces || [] };
    });
    const agents = devices.flatMap((device) => (computers.get(device.id)?.agents || []).map((agent) => ({ ...agent, deviceId: device.id, ...(!device.connected || Date.now() - computers.get(device.id)!.lastSnapshot >= 20_000 ? { status: 'offline' as const, approvals: [] } : {}) })));
    return { devices, agents, at: Date.now() };
  }
  function send(socket: WebSocket, value: unknown) {
    if (socket.readyState !== WebSocket.OPEN) return;
    if (socket.bufferedAmount > 4 * 1024 * 1024) { socket.close(1013, 'Connection is too slow'); return; }
    socket.send(JSON.stringify(value));
  }
  function broadcast(value: unknown = { type: 'snapshot', data: snapshot() }) {
    for (const [socket, viewer] of viewers) {
      if (auth.validSession(viewer.sessionHash)) send(socket, value);
      else socket.close(4001, 'Session expired');
    }
  }
  function rejectPending(deviceId: string, message: string) {
    for (const [id, request] of pending) if (request.deviceId === deviceId) {
      clearTimeout(request.timeout); pending.delete(id); request.reject(new HttpError(503, message));
    }
  }
  auth.onExpire = (sessionHash) => { for (const [socket, viewer] of viewers) if (viewer.sessionHash === sessionHash) socket.close(4001, 'Remote locked'); };
  pairings.onChange = () => broadcast();

  app.get('/api/state', auth.requireSession, (_req, res) => res.json(snapshot()));
  app.delete('/api/devices/:id', auth.requireSession, (req, res) => {
    const device = store.state.devices.find((device) => device.id === req.params.id);
    if (!device) throw new HttpError(404, 'Computer not found.');
    store.state.devices = store.state.devices.filter((device) => device.id !== req.params.id);
    store.save(); pairings.removeForDevice(device.id);
    computers.get(device.id)?.socket.close(4003, 'Computer was disconnected from the phone');
    computers.delete(device.id); rejectPending(device.id, 'The computer has been disconnected.'); broadcast();
    res.json({ ok: true });
  });
  const commandLimit = rateLimit({ windowMs: 60_000, limit: 180, standardHeaders: 'draft-8', legacyHeaders: false, message: { error: 'Too many commands. Wait a moment before trying again.' } });
  app.post('/api/devices/:id/command', auth.requireSession, commandLimit, async (req, res) => {
    const command = commandSchema.parse(req.body);
    const deviceId = z.string().parse(req.params.id);
    const computer = computers.get(deviceId);
    if (!store.state.devices.some((item) => item.id === deviceId) || !computer || computer.socket.readyState !== WebSocket.OPEN) throw new HttpError(503, 'Your computer is offline. Reconnect it and try again.');
    if (Date.now() - computer.lastSnapshot >= 20_000) throw new HttpError(503, 'Agent status is stale. Wait for the computer to finish reconnecting.');
    if ('agentId' in command && !computer.agents.some((agent) => agent.id === command.agentId)) throw new HttpError(404, 'That agent is no longer available.');
    if ('sourceId' in command && !computer.sources.some((source) => source.id === command.sourceId && source.connected)) throw new HttpError(404, 'That agent source is not connected.');
    if ('workspace' in command && !computer.workspaces.includes(command.workspace)) throw new HttpError(403, 'Choose a workspace configured on this computer.');
    if (pending.size >= 250) throw new HttpError(429, 'The relay is busy. Try again shortly.');
    const readOnly = command.action === 'agent.messages' || command.action === 'source.options';
    const operationId = readOnly ? randomUUID() : z.string().uuid('A unique Idempotency-Key header is required for agent actions.').parse(req.headers['idempotency-key']);
    const tokenHash = store.state.devices.find((item) => item.id === deviceId)!.tokenHash;
    const execute = () => dispatch(deviceId, command, tokenHash);
    const result = await (readOnly ? execute() : commands.run(operationId, deviceId, command, execute));
    res.json(result ?? { ok: true });
  });
  app.use('/api', (_req, res) => res.status(404).json({ error: 'Endpoint not found.' }));

  if (existsSync(join(config.staticDir, 'index.html'))) {
    app.use(express.static(config.staticDir, { index: false, setHeaders: (res, file) => {
      res.setHeader('Cache-Control', file.includes('/assets/') ? 'public, max-age=31536000, immutable' : 'no-cache');
    } }));
    app.get('/{*path}', (_req, res) => { res.setHeader('Cache-Control', 'no-store'); res.sendFile(join(config.staticDir, 'index.html')); });
  } else app.get('/', (_req, res) => res.type('text').send('Agent Remote relay is running. Open the Vite app at your PUBLIC_URL, or run npm run build.'));

  const errors: ErrorRequestHandler = (error, _req, res, _next) => {
    if (error instanceof HttpError) res.status(error.status).json({ error: error.message });
    else if (error instanceof ZodError) res.status(400).json({ error: error.issues[0]?.message || 'Invalid request.' });
    else if (error instanceof SyntaxError) res.status(400).json({ error: 'Invalid JSON.' });
    else if (error?.type === 'entity.too.large') res.status(413).json({ error: 'This request is too large.' });
    else { console.error('Relay request failed:', error instanceof Error ? error.message : 'Unknown error'); res.status(500).json({ error: 'The relay could not complete this request.' }); }
  };
  app.use(errors);

  server.on('upgrade', (req, socket, head) => {
    const path = req.url?.split('?')[0];
    function deny(status: number) { socket.end(`HTTP/1.1 ${status} ${status === 401 ? 'Unauthorized' : 'Forbidden'}\r\nConnection: close\r\n\r\n`); }
    if (path === '/live') {
      const session = auth.session(req);
      if (req.headers.origin && req.headers.origin !== config.origin) return deny(403);
      if (!session) return deny(401);
      if (!req.headers.origin && session.kind !== 'native') return deny(403);
      if (viewers.size >= 100 || [...viewers.values()].filter((viewer) => viewer.sessionHash === session.hash).length >= 8) return deny(403);
      wss.handleUpgrade(req, socket, head, (ws) => {
        const viewer = { sessionHash: session.hash, alive: true };
        viewers.set(ws, viewer);
        ws.on('pong', () => { viewer.alive = true; });
        ws.on('message', () => ws.close(1008, 'Viewer streams are read-only'));
        ws.on('error', () => ws.terminate());
        ws.on('close', () => viewers.delete(ws));
        send(ws, { type: 'snapshot', data: snapshot() });
      });
    } else if (path === '/bridge') {
      if (req.headers.origin) return deny(403);
      const token = bearer(req);
      const device = store.state.devices.find((device) => matches(token, device.tokenHash));
      if (!device) return deny(401);
      wss.handleUpgrade(req, socket, head, (ws) => {
        const old = computers.get(device.id);
        if (old) { rejectPending(device.id, 'The computer reconnected. Check the agent before retrying.'); old.socket.close(4002, 'Another connector took over this device'); }
        const computer: Computer = { socket: ws, alive: true, agents: [], sources: [], workspaces: [], lastSeen: Date.now(), lastSnapshot: 0 };
        const budget = new MessageBudget();
        computers.set(device.id, computer); device.lastSeen = computer.lastSeen; store.save();
        ws.on('pong', () => { computer.alive = true; computer.lastSeen = Date.now(); });
        ws.on('error', () => ws.terminate());
        ws.on('message', (data, binary) => {
          if (computers.get(device.id) !== computer || !store.state.devices.includes(device)) return;
          const size = Array.isArray(data) ? data.reduce((total, buffer) => total + buffer.length, 0) : data.byteLength;
          if (binary || !budget.take(size)) { ws.close(1008, binary ? 'Text protocol required' : 'Connector message rate exceeded'); return; }
          try {
            const message = bridgeMessageSchema.parse(JSON.parse(data.toString()));
            computer.alive = true; computer.lastSeen = Date.now();
            if (message.type === 'snapshot') {
              computer.lastSnapshot = Date.now();
              computer.agents = message.agents; computer.sources = message.sources; computer.workspaces = message.workspaces;
              broadcast();
            } else if (message.type === 'result') {
              const request = pending.get(message.requestId);
              if (!request || request.deviceId !== device.id) return;
              clearTimeout(request.timeout); pending.delete(message.requestId);
              if (message.error) request.reject(new HttpError(502, message.error));
              else request.resolve(message.result);
            } else broadcast({ type: 'changed', deviceId: device.id, agentId: message.agentId });
          } catch { ws.close(1008, 'Invalid connector message'); }
        });
        ws.on('close', () => {
          if (computers.get(device.id) !== computer) return;
          device.lastSeen = computer.lastSeen;
          if (store.state.devices.includes(device)) store.save();
          rejectPending(device.id, 'The computer disconnected. Check the agent before retrying.'); broadcast();
        });
        send(ws, { type: 'connected', deviceId: device.id }); broadcast();
      });
    } else deny(403);
  });
  const heartbeat = setInterval(() => {
    auth.sweep(); nativeAuth.sweep(); pairings.sweep(); transfers.sweep();
    for (const computer of computers.values()) if (computer.socket.readyState === WebSocket.OPEN) {
      if (!computer.alive) computer.socket.terminate();
      else { computer.alive = false; computer.socket.ping(); }
    }
    for (const [socket, viewer] of viewers) {
      if (!viewer.alive || !auth.validSession(viewer.sessionHash)) socket.terminate();
      else { viewer.alive = false; socket.ping(); send(socket, { type: 'heartbeat', at: Date.now() }); }
    }
    broadcast();
  }, 15_000);
  heartbeat.unref();

  async function close() {
    clearInterval(heartbeat);
    transfers.close();
    for (const request of pending.values()) { clearTimeout(request.timeout); request.reject(new HttpError(503, 'Relay is restarting.')); }
    pending.clear();
    for (const socket of wss.clients) socket.terminate();
    await new Promise<void>((resolve) => wss.close(() => resolve()));
    if (server.listening) await new Promise<void>((resolve, reject) => { server.close((error) => error ? reject(error) : resolve()); server.closeIdleConnections(); });
  }
  return { app, server, store, auth, nativeAuth, pairings, transfers, snapshot, close };
}
