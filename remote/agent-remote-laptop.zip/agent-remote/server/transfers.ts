import { randomUUID } from 'node:crypto';
import { Router, type Request } from 'express';
import { rateLimit } from 'express-rate-limit';
import { z } from 'zod';
import type { LocalAgent, Source } from '../shared/types';
import { exportedChatSchema, prepareTransferSchema, transferTextSchema, type BridgeCommand, type StageCommand, type TransferPreview, type TransferRequest, type TransferResult } from '../shared/transfers';
import { redactCredentials } from '../shared/portable-chat';
import { Auth } from './auth';
import { Store, type TransferReceipt } from './store';
import { hash, HttpError } from './security';

export interface TransferPeer {
  id: string; name: string; tokenHash: string; connected: boolean; fresh: boolean;
  agents: LocalAgent[]; sources: Source[]; workspaces: string[];
}
interface Prepared {
  preview: TransferPreview; request: TransferRequest; sessionHash: string;
  fromTokenHash: string; toTokenHash: string; revision: string;
}
type Peer = (id: string) => TransferPeer | undefined;
type Dispatch = (id: string, command: BridgeCommand, tokenHash: string) => Promise<unknown>;

/** Transfer approval and text live in memory only. Disk holds delivery metadata,
 * never the exported transcript. Destination chats are always staged/paused. */
export class Transfers {
  readonly router = Router();
  private previews = new Map<string, Prepared>();
  private committing = new Map<string, Promise<TransferResult>>();
  private preparing = new Set<string>();
  constructor(private store: Store, private auth: Auth, private peer: Peer, private dispatch: Dispatch) {
    this.router.use(auth.requireSession);
    this.router.use(rateLimit({ windowMs: 60_000, limit: 30, standardHeaders: 'draft-8', legacyHeaders: false, message: { error: 'Too many transfer requests. Wait a minute before trying again.' } }));
    this.router.post('/prepare', async (req, res) => res.json(await this.prepare(req, prepareTransferSchema.parse(req.body))));
    this.router.post('/:id/review', (req, res) => {
      const prepared = this.owned(req, z.string().uuid().parse(req.params.id));
      if (this.committing.has(prepared.preview.id)) throw new HttpError(409, 'This transfer is already being confirmed.');
      const { context } = z.object({ context: transferTextSchema }).strict().parse(req.body);
      const sanitized = redactCredentials(context);
      prepared.preview.context = transferTextSchema.parse(sanitized.text);
      prepared.preview.redactions += sanitized.redactions;
      prepared.preview.reviewHash = this.reviewHash(prepared.preview);
      res.json(prepared.preview);
    });
    this.router.post('/:id/commit', async (req, res) => {
      const id = z.string().uuid().parse(req.params.id);
      const body = z.object({ reviewHash: z.string().regex(/^[a-f0-9]{64}$/) }).strict().parse(req.body);
      const receipt = this.store.state.transfers.find((item) => item.id === id);
      if (receipt) {
        if (receipt.reviewHash !== body.reviewHash) throw new HttpError(409, 'That transfer was confirmed with different context.');
        res.json(this.result(receipt)); return;
      }
      const prepared = this.owned(req, id);
      if (prepared.preview.reviewHash !== body.reviewHash) throw new HttpError(409, 'Review the current transfer text before confirming it.');
      let pending = this.committing.get(id);
      if (!pending) {
        pending = this.commit(prepared).finally(() => { this.committing.delete(id); });
        this.committing.set(id, pending);
      }
      const result = await pending;
      res.status(result.status === 'uncertain' ? 202 : 200).json(result);
    });
    this.router.get('/:id', (req, res) => {
      const id = z.string().uuid().parse(req.params.id);
      const receipt = this.store.state.transfers.find((item) => item.id === id);
      if (!receipt) throw new HttpError(404, 'No submitted transfer with that ID exists.');
      res.json(this.result(receipt));
    });
    this.router.delete('/:id', (req, res) => {
      const id = z.string().uuid().parse(req.params.id);
      this.owned(req, id);
      if (this.committing.has(id)) throw new HttpError(409, 'Transfer confirmation is in progress. Check the destination before trying again.');
      this.previews.delete(id); res.json({ ok: true });
    });
  }

  private connected(id: string, expectedHash?: string) {
    const peer = this.peer(id);
    if (!peer || !peer.connected || !peer.fresh) throw new HttpError(503, 'Both computers must be connected with fresh status.');
    if (expectedHash && peer.tokenHash !== expectedHash) throw new HttpError(409, 'A computer was re-paired. Prepare a new transfer with its current identity.');
    return peer;
  }
  private source(request: TransferRequest, expectedHash?: string) {
    const peer = this.connected(request.fromDeviceId, expectedHash);
    const agent = peer.agents.find((item) => item.id === request.agentId);
    const source = agent && peer.sources.find((item) => item.id === agent.sourceId);
    if (!agent?.capabilities.messages || !source?.canTransfer) throw new HttpError(409, 'Update this computer’s connector and connect this session before transferring.');
    if (agent.handoff?.phase !== 'paused' && (agent.status !== 'idle' || agent.approvals.length || !source.connected)) throw new HttpError(409, 'Finish or stop the current turn before transferring its chat.');
    return { peer, agent };
  }
  private destination(request: TransferRequest, expectedHash?: string) {
    const peer = this.connected(request.toDeviceId, expectedHash);
    const source = peer.sources.find((item) => item.id === request.sourceId);
    if (!source?.connected || !source.canCreate || !source.canTransfer) throw new HttpError(409, 'Choose a connected destination source with an updated connector.');
    if (!peer.workspaces.includes(request.workspace)) throw new HttpError(403, 'Choose a workspace configured on the destination computer.');
    return { peer, source };
  }
  private session(req: Request) {
    const session = this.auth.session(req);
    if (!session) throw new HttpError(401, 'Unlock the app again before transferring.');
    return session;
  }
  private owned(req: Request, id: string) {
    this.sweep();
    const prepared = this.previews.get(id);
    if (!prepared || prepared.sessionHash !== this.session(req).hash) throw new HttpError(404, 'This transfer preview expired or belongs to another login. Prepare it again.');
    return prepared;
  }
  private valid(prepared: Prepared) {
    if (!this.auth.validSession(prepared.sessionHash)) throw new HttpError(401, 'The app locked before transfer confirmation.');
    if (prepared.preview.expiresAt <= Date.now() || this.previews.get(prepared.preview.id) !== prepared) throw new HttpError(409, 'This preview expired or was cancelled. Prepare a new transfer.');
  }
  private reviewHash(preview: TransferPreview) {
    return hash(JSON.stringify({ id: preview.id, context: preview.context, title: preview.title, from: preview.from, destination: preview.destination }));
  }
  private async prepare(req: Request, request: TransferRequest): Promise<TransferPreview> {
    this.sweep();
    if (request.fromDeviceId === request.toDeviceId) throw new HttpError(400, 'Choose a different destination computer.');
    const session = this.session(req);
    if (this.preparing.has(session.hash) || [...this.previews.values()].filter((item) => item.sessionHash === session.hash).length >= 5 || this.previews.size + this.preparing.size >= 50) throw new HttpError(429, 'Finish or cancel an existing transfer preview first.');
    const source = this.source(request); const destination = this.destination(request);
    this.preparing.add(session.hash);
    try {
      const exported = exportedChatSchema.parse(await this.dispatch(source.peer.id, { action: 'chat.export', agentId: request.agentId }, source.peer.tokenHash));
      if (!this.auth.validSession(session.hash)) throw new HttpError(401, 'The app locked while preparing the transfer.');
      this.source(request, source.peer.tokenHash); this.destination(request, destination.peer.tokenHash);
      const sanitized = redactCredentials(exported.context);
      const preview: TransferPreview = {
        id: randomUUID(), reviewHash: '', expiresAt: Date.now() + 5 * 60_000,
        title: exported.title, context: transferTextSchema.parse(sanitized.text),
        from: { deviceId: source.peer.id, deviceName: source.peer.name, agentId: request.agentId, provider: source.agent.provider },
        destination: { deviceId: destination.peer.id, deviceName: destination.peer.name, sourceId: destination.source.id, provider: destination.source.provider, workspace: request.workspace },
        includedMessages: exported.includedMessages, omittedMessages: exported.omittedMessages, limitedHistory: exported.limitedHistory, redactions: exported.redactions + sanitized.redactions,
      };
      preview.reviewHash = this.reviewHash(preview);
      this.previews.set(preview.id, { preview, request, sessionHash: session.hash, fromTokenHash: source.peer.tokenHash, toTokenHash: destination.peer.tokenHash, revision: exported.revision });
      return preview;
    } finally { this.preparing.delete(session.hash); }
  }
  private async commit(prepared: Prepared): Promise<TransferResult> {
    this.valid(prepared);
    this.source(prepared.request, prepared.fromTokenHash); this.destination(prepared.request, prepared.toTokenHash);
    const current = exportedChatSchema.parse(await this.dispatch(prepared.request.fromDeviceId, { action: 'chat.export', agentId: prepared.request.agentId }, prepared.fromTokenHash));
    this.valid(prepared);
    if (current.revision !== prepared.revision) throw new HttpError(409, 'The source chat changed after review. Prepare a new transfer so no new context is missed.');
    this.source(prepared.request, prepared.fromTokenHash);
    const destination = this.destination(prepared.request, prepared.toTokenHash);
    if (destination.source.provider !== prepared.preview.destination.provider) throw new HttpError(409, 'The destination provider changed. Prepare a new transfer.');
    if (this.store.state.transfers.length >= 10_000) throw new HttpError(429, 'The relay’s transfer receipt limit has been reached.');
    const command: StageCommand = { action: 'chat.stage', transferId: prepared.preview.id, sourceId: destination.source.id, provider: destination.source.provider, workspace: prepared.request.workspace, title: prepared.preview.title, context: prepared.preview.context, from: prepared.preview.from, ...(prepared.request.model ? { model: prepared.request.model } : {}) };
    const receipt: TransferReceipt = { id: prepared.preview.id, fromDeviceId: prepared.request.fromDeviceId, toDeviceId: prepared.request.toDeviceId, toTokenHash: prepared.toTokenHash, agentId: `handoff:${prepared.preview.id}`, reviewHash: prepared.preview.reviewHash, createdAt: Date.now(), status: 'sending' };
    this.store.state.transfers.push(receipt);
    try { this.store.save(); } catch (error) { this.store.state.transfers = this.store.state.transfers.filter((item) => item !== receipt); throw error; }
    try {
      this.valid(prepared);
      const reply = z.object({ transferId: z.literal(receipt.id), agentId: z.literal(receipt.agentId), staged: z.literal(true) }).parse(await this.dispatch(destination.peer.id, command, prepared.toTokenHash));
      receipt.status = reply.staged ? 'completed' : 'uncertain';
    } catch {
      receipt.status = 'uncertain';
    } finally {
      this.previews.delete(prepared.preview.id);
      this.store.save();
    }
    return this.result(receipt, true);
  }
  private result(receipt: TransferReceipt, finished = false): TransferResult {
    const destination = this.peer(receipt.toDeviceId);
    const delivered = !!destination?.connected && destination.fresh && destination.tokenHash === receipt.toTokenHash && destination.agents.some((agent) => agent.id === receipt.agentId);
    if (receipt.status !== 'completed' && delivered) { receipt.status = 'completed'; this.store.save(); }
    const status = receipt.status === 'completed' ? 'completed' : !finished && this.committing.has(receipt.id) ? 'preparing' : 'uncertain';
    return { id: receipt.id, status, destinationDeviceId: receipt.toDeviceId, agentId: receipt.agentId, paused: true };
  }
  sweep() {
    for (const [id, prepared] of this.previews) if (prepared.preview.expiresAt <= Date.now() || !this.auth.validSession(prepared.sessionHash)) this.previews.delete(id);
  }
  close() { this.previews.clear(); this.preparing.clear(); }
}
