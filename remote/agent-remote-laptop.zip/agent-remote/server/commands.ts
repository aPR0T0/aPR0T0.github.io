import { hash, HttpError } from './security';
import { Store } from './store';
import type { Command } from '../shared/types';

/** Receipts contain hashes, not prompts/results. Claim before dispatch, and keep
 * an uncertain outcome after a crash rather than risk executing it twice. */
export class Commands {
  private live = new Map<string, { digest: string; promise: Promise<unknown> }>();
  constructor(private store: Store) {}
  run(id: string, deviceId: string, command: Command, dispatch: () => Promise<unknown>): Promise<unknown> {
    const key = `${deviceId}:${id}`;
    const digest = hash(JSON.stringify(command));
    const found = this.store.state.commands.find((receipt) => receipt.id === id && receipt.deviceId === deviceId);
    if (found) {
      if (found.digest !== digest) throw new HttpError(409, 'This operation ID was already used for different instructions.');
      const live = this.live.get(key);
      if (live) return live.promise;
      throw new HttpError(409, 'This operation was already submitted. Check the agent before starting a new operation.');
    }
    const now = Date.now();
    const receipts = this.store.state.commands.filter((receipt) => now - receipt.createdAt < 24 * 60 * 60_000);
    if (receipts.length >= 10_000) throw new HttpError(429, 'The daily command receipt limit was reached.');
    const previous = this.store.state.commands;
    this.store.state.commands = [...receipts, { id, deviceId, digest, createdAt: now }];
    try { this.store.save(); } catch (error) { this.store.state.commands = previous; throw error; }
    // Schedule dispatch after the promise has been entered into the registry.
    const promise = Promise.resolve().then(dispatch);
    this.live.set(key, { digest, promise });
    void promise.finally(() => {
      const timer = setTimeout(() => this.live.delete(key), 60_000); timer.unref();
    }).catch(() => {});
    return promise;
  }
}
