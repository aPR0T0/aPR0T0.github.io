import { resolve } from 'node:path';

export interface RelayConfig {
  apiKey: string;
  origin: string;
  rpID: string;
  secure: boolean;
  host: string;
  port: number;
  dataDir: string;
  trustProxy: boolean;
  staticDir: string;
}
export function readConfig(env: NodeJS.ProcessEnv = process.env): RelayConfig {
  const apiKey = env.REMOTE_API_KEY || '';
  if (apiKey.length < 32 || apiKey.startsWith('replace-with-')) throw new Error('Set a random REMOTE_API_KEY of at least 32 characters. Run npm run setup first.');
  const url = new URL(env.PUBLIC_URL || 'http://localhost:5173');
  const secure = url.protocol === 'https:';
  if ((!secure && !(url.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(url.hostname))) || url.pathname !== '/' || url.username || url.password || url.search || url.hash) {
    throw new Error('PUBLIC_URL must be an HTTPS origin, or an HTTP localhost origin for development.');
  }
  const port = Number(env.PORT || 4317);
  if (!Number.isInteger(port) || port < 0 || port > 65535) throw new Error('PORT must be a valid port number.');
  return { apiKey, origin: url.origin, rpID: url.hostname, secure, host: env.HOST || '127.0.0.1', port, dataDir: resolve(env.DATA_DIR || './data'), trustProxy: env.TRUST_PROXY === '1', staticDir: resolve('dist') };
}
