import { randomBytes } from 'node:crypto';
import { chmodSync, existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import type { WebAuthnCredential } from '@simplewebauthn/server';
import type { DeviceIdentity } from '../shared/types';

export interface StoredCredential {
  id: string;
  publicKey: string;
  counter: number;
  transports?: WebAuthnCredential['transports'];
  createdAt: number;
}
export interface StoredDevice extends DeviceIdentity {
  tokenHash: string;
  pairedAt: number;
  lastSeen: number;
}
export interface NativeCredential { id: string; publicKey: string; name: string; createdAt: number }
export interface CommandReceipt { id: string; deviceId: string; digest: string; createdAt: number }
export interface TransferReceipt {
  id: string; fromDeviceId: string; toDeviceId: string; toTokenHash: string;
  agentId: string; reviewHash: string; createdAt: number;
  status: 'sending' | 'completed' | 'uncertain';
}
interface State { version: 1; userId: string; credentials: StoredCredential[]; nativeCredentials: NativeCredential[]; devices: StoredDevice[]; commands: CommandReceipt[]; transfers: TransferReceipt[] }

/** One relay process owns this small, atomically replaced private state file. */
export class Store {
  state: State;
  private file: string;
  constructor(directory: string) {
    mkdirSync(directory, { recursive: true, mode: 0o700 });
    this.file = join(directory, 'state.json');
    if (existsSync(this.file)) {
      this.state = JSON.parse(readFileSync(this.file, 'utf8')) as State;
      if (this.state.version !== 1 || !Array.isArray(this.state.credentials) || !Array.isArray(this.state.devices) || !this.state.userId) throw new Error('The relay state is invalid. Restore a valid state.json backup.');
      this.state.nativeCredentials ??= [];
      this.state.commands ??= [];
      this.state.transfers ??= [];
      if (!Array.isArray(this.state.nativeCredentials) || !Array.isArray(this.state.commands) || !Array.isArray(this.state.transfers)) throw new Error('The relay state is invalid.');
      chmodSync(this.file, 0o600);
    } else {
      this.state = { version: 1, userId: randomBytes(32).toString('base64url'), credentials: [], nativeCredentials: [], devices: [], commands: [], transfers: [] };
      this.save();
    }
  }
  save() {
    const temporary = `${this.file}.${randomBytes(8).toString('hex')}.tmp`;
    writeFileSync(temporary, JSON.stringify(this.state, null, 2), { mode: 0o600, flag: 'wx' });
    renameSync(temporary, this.file);
  }
  identityTaken(identity: DeviceIdentity) {
    return this.state.devices.some((device) => device.id.toLowerCase() === identity.id.toLowerCase() || device.name.toLowerCase() === identity.name.toLowerCase());
  }
  hasCredentials() { return this.state.credentials.length + this.state.nativeCredentials.length > 0; }
}
