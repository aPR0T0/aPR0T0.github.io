#!/usr/bin/env bash
set -u
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)" || exit 1
cd "$ROOT" || exit 1
NODE_CHECK='const [major, minor] = process.versions.node.split(".").map(Number); process.exit(major > 22 || (major === 22 && minor >= 13) ? 0 : 1)'
if ! node -e "$NODE_CHECK" >/dev/null 2>&1; then
  for NODE_DIR in /opt/homebrew/bin /usr/local/bin; do
    if [ -x "$NODE_DIR/node" ] && "$NODE_DIR/node" -e "$NODE_CHECK" >/dev/null 2>&1; then
      export PATH="$NODE_DIR:$PATH"
      break
    fi
  done
fi
if ! node -e "$NODE_CHECK" >/dev/null 2>&1 && [ -s "${NVM_DIR:-$HOME/.nvm}/nvm.sh" ]; then
  export NVM_DIR="${NVM_DIR:-$HOME/.nvm}"
  set +u
  . "$NVM_DIR/nvm.sh"
  nvm use 24 >/dev/null 2>&1 || nvm use 22 >/dev/null 2>&1 || true
  set -u
fi
if ! command -v node >/dev/null 2>&1; then
  printf '\nInstall Node.js 24 from https://nodejs.org/en/download, then open this file again.\n'
  read -r -p "Press Enter to close… " _
  exit 1
fi
node "$ROOT/launch.mjs" "$@"
RESULT=$?
if [ "$RESULT" -ne 0 ]; then
  read -r -p "Press Enter to close… " _
fi
exit "$RESULT"
