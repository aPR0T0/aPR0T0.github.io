# Native Linux fingerprint unlock

Agent Remote 0.6.0 can use a laptop reader exposed through **fprintd**, including the Xiaomi Mi NoteBook Pro's FPC `10a5:9200` reader with its installed experimental driver.

This is a native companion, not a browser-native FIDO authenticator. On this Pop!_OS laptop, the fingerprint reader and an enrolled right index finger were detected, but an isolated Chrome test exposed no user-verifying platform authenticator. Installing a Linux fingerprint driver alone does not connect that reader to WebAuthn.

## First setup

1. Update and restart your **relay host** with 0.6.0 or newer. Check its `/api/health` version.
2. On a Linux desktop with an enrolled fprintd fingerprint, run this from the updated laptop kit:

   ```sh
   npm run fingerprint:install
   ```

   Approve the one-time administrator prompt. The installer adds **Agent Remote Fingerprint** to your application launcher and registers the `agent-remote-fingerprint:` browser link handler.

3. Open **Agent Remote Fingerprint**, or choose **Use laptop fingerprint (Linux)** on your relay's web login page.
4. Enter your relay's HTTPS address and relay API key. On your unlocked phone, create a device-link code and paste it into the companion's **Device-link code** field. This authorizes the laptop's new signing key; the existing phone stays trusted.
5. Optionally select **Save relay key in the desktop keyring**. Your desktop may ask to unlock that keyring with its password; fingerprint-based OS login does not necessarily unlock a password-encrypted keyring.
6. Click **Scan fingerprint & open workspace** and touch the enrolled finger. The browser opens your workspace after the relay verifies the signature.

For later logins, open the companion or use the Linux fingerprint button. Leave the device-link field empty. The relay key can be loaded from the desktop keyring if you saved it. No USB security key is needed for this native path.

Required distro packages are `python3-gi`, `python3-cryptography`, `gir1.2-gtk-4.0`, `fprintd`, `polkitd`/`pkexec`, and `desktop-file-utils`; `gir1.2-secret-1` enables optional keyring storage. The installed FPC driver is separate and is not bundled or changed by this installer.

## Protection boundaries

- The GTK client runs as your normal user. Its relay key can be saved through the desktop Secret Service; it does not write that key to its settings file.
- A fixed-purpose root helper keeps P-256 signing keys under `/var/lib/agent-remote-fingerprint/<uid>/`. Directories are `0700`, keys are `0600`, and each relay origin has a separate key. The helper never exports a private key.
- The Polkit action permits only the installed, root-owned helper and only from an active local desktop session. It does not authorize arbitrary Python commands or a shell.
- The helper performs no networking. It signs only bounded `agent-remote/linux-auth/v1` challenges matching the chosen HTTPS origin, its public-key identity, the expected nonce fields, and a short expiry.
- The helper talks to the system fprintd service, verifies the calling OS user's enrolled finger, and rechecks expiry after the scan. A failed scan has no password fallback in the helper. The reader is released on completion or timeout.
- Fingerprint images/templates remain under fprintd's existing management. The companion receives no images or templates.
- After successful relay verification, a **30-second, single-use ticket** opens the browser session. The ticket is removed from the address bar and is not saved to browser storage. Redeeming it consumes the native login session; the browser receives the normal HttpOnly, Secure, SameSite cookie.
- Browser lock/idle expiry and passkey authentication continue to work normally.

These are **root-protected software signing keys**, not TPM-sealed or hardware-FIDO keys. The Xiaomi driver performs matching on the host; root compromise can bypass a software helper. The relay verifies the enrolled signing key and does not attest the laptop or its fingerprint hardware.

## Checks

```sh
npm run test:fingerprint
npm test -- tests/linux-fingerprint.test.ts
/usr/bin/python3 -I linux-fingerprint/check_hardware.py https://YOUR-RELAY.ts.net
```

The hardware check waits up to 40 seconds for your finger and verifies the resulting P-256 signature locally. It does not enroll a relay credential, log in to the relay, or make model calls. First relay linking still requires your trusted device's one-use code.

On the development Xiaomi, installation permissions, desktop-handler registration, GTK startup, and a real fingerprint-backed signature were verified. The physical fingerprint match used the existing enrolled finger; no fingerprint templates or driver settings were changed.

## Removal

Remove `/usr/share/polkit-1/actions/app.agentremote.fingerprint.policy`, `/usr/share/applications/agent-remote-fingerprint.desktop`, and `/opt/agent-remote-fingerprint` with administrator approval, then refresh the desktop application database. The private keys under `/var/lib/agent-remote-fingerprint` and optional desktop-keyring entry are separate retained data. Deleting a key means that laptop will need a fresh trusted-device link to enroll a replacement.
