# One-time laptop setup — no rented server

**Using another device?** Open [apr0t0.github.io/remote/](https://apr0t0.github.io/remote/) for a permanent start page and Windows/macOS/Linux laptop download. See [Connect any device](CONNECT-ANY-DEVICE.md) for browser access, device-link codes, and adding another laptop.

Run the **web setup wizard on the laptop where your OpenCode and Codex agents live**. The recommended setup hosts Agent Remote on that laptop and uses Tailscale Serve for a stable, private HTTPS address.

```text
Phone with Tailscale ── private HTTPS ── Tailscale Serve on your laptop
                                                 │
                                          Relay :4317
                                                 │
                                         Laptop connector
                                          ├─ OpenCode
                                          └─ Codex

Laptop browser ── localhost :4316 ── One-time setup & start/stop controls
```

## 1. Launch the wizard

Install **Node.js 22.13+ (24 recommended)**. In the `agent-remote` project folder:

```bash
npm ci
npm run setup:gui
```

If you use nvm, run `nvm use 24` first. The command builds the browser pages and opens the setup assistant. If a browser does not open, copy the **full private link** printed in the terminal. It looks like `http://127.0.0.1:4316/setup#token=…`.

The setup assistant runs on this laptop only. Keep its terminal open while using Agent Remote. The browser tab can be closed after setup.

## 2. Follow the six steps

### This laptop

Check the detected Node.js, OpenCode, Codex, and Tailscale installations. A missing tool can be installed during the following steps. These are installation checks; the agent connection tests happen later.

### Private connection

Choose **This laptop + Tailscale** for phone access without a server bill.

1. [Install Tailscale](https://tailscale.com/download) on the laptop and phone.
2. Sign both devices in to the same **Personal** account/network.
3. Click **Check Tailscale** in the wizard. It detects your laptop’s `https://laptop.tailnet.ts.net` address.
4. Click **Enable private HTTPS**. The wizard runs:

   ```bash
   tailscale serve --bg --https=443 http://127.0.0.1:4317
   ```

5. If Tailscale needs to enable HTTPS certificates or asks for administrator access, run that command in a terminal and follow its activation link. On Linux it may need `sudo`. Click **Check Tailscale** afterward.
6. Keep the detected HTTPS address and continue.

Tailscale supplies both the hostname and certificate. Serve forwards the dashboard, API, and WebSockets to port 4317. The setup assistant on port 4316 stays local. The wizard checks for existing Serve routes and Funnel settings before changing port 443.

If the Tailscale app is installed but its CLI is not found, set `TAILSCALE_BIN` to the executable path and restart the launcher. Common macOS and Windows installation paths are also checked automatically.

**Try on this laptop** uses `http://localhost:4317` for a local browser trial. To use the phone, choose the stable Tailscale address before enrolling its passkey. A phone’s `localhost` is the phone, and an HTTP LAN address does not support the required phone WebAuthn flow.

**Connect another laptop** joins an existing relay; see step 4 below.

### Your projects

Choose a unique computer name and ID. Enter your project folders **one per line**. Use absolute paths, for example:

```text
/home/you/projects/my-app
/home/you/projects/another project
```

On macOS, `/Users/you/projects/my-app` or `~/projects/my-app` works. On Windows, use paths such as `C:\Users\you\projects\my-app`.

**Check project folders** verifies that the directories exist and resolves their canonical paths. These are the allowed folders for new phone-started tasks.

### Your agents

The wizard supports both providers and multiple local sources.

| Choice | Behavior |
| --- | --- |
| OpenCode → **Start with Agent Remote** | Starts a headless local OpenCode server in the first selected project folder. Reuses the endpoint if a healthy server is already listening there. |
| OpenCode → **Connect to a running server** | Connects the server doing your existing work. A fixed-port TUI can be launched with `opencode --hostname 127.0.0.1 --port 4096`. |
| Codex → **Start with Agent Remote** | The connector starts `codex app-server` over private stdio using your laptop’s Codex configuration. |
| Codex → **Connect to a running server** | Connects a shared app-server, for example `codex app-server --listen ws://127.0.0.1:4500`. |

If needed, expand **Install, sign in & server credentials**. Install and authenticate your agents in a laptop terminal:

```bash
npm install -g opencode-ai
opencode auth login
```

```bash
npm install -g @openai/codex
codex login
```

The project also includes a pinned Codex CLI dependency, which npm launch commands can find. You can select a particular executable with `OPENCODE_BIN` or `CODEX_BIN` in the launcher environment. On Windows, if a managed CLI is only available through an npm `.cmd` shim, run its server in a terminal and select **Connect to a running server**.

Use **Find running servers** to add detected endpoints. Keep automatic discovery enabled to pick up later OpenCode/Codex listeners. If discovery is unavailable, use explicit loopback URLs; Linux/macOS discovery uses `lsof`.

Click **Start & test OpenCode** or **Test … connection**, then **Save & start**. Tests check OpenCode health or the Codex app-server handshake. They do not submit model prompts or prove your model subscription is authenticated. Agent login happens through the CLI commands above.

For password-protected OpenCode, provide `OPENCODE_SERVER_PASSWORD` and optionally `OPENCODE_SERVER_USERNAME` in the launcher environment. For a bearer-protected Codex WebSocket, provide `CODEX_REMOTE_TOKEN`. Custom environment-variable names can be entered in the advanced source fields. The normal `.env` is also loaded when the launcher starts.

A headless or managed server is a separate session host. For live control of work already running in a terminal, connect the endpoint that owns it. A compatible Codex terminal can attach using `codex --remote ws://127.0.0.1:4500`.

### Pair your phone

1. Open the displayed HTTPS relay address on your phone, with Tailscale connected. You can use the browser/PWA or the existing [Android app](ANDROID.md).
2. Click **Copy relay key** or reveal it in the laptop wizard. Save it in your password manager.
3. Enter that key on the phone and complete its passkey/native biometric enrollment.
4. In the laptop wizard, click **Create pairing code**.
5. On the unlocked phone, choose **Connect a computer**, enter the code, match the name and ID, and select **Attach this computer**.
6. The wizard detects approval, saves the laptop’s device token, and starts its connector. Click **Finish setup**.

Pairing codes expire after ten minutes. Refreshing the setup page keeps an active pairing available while its launcher remains running. The relay key is separate from model-provider API keys.

### Ready to go

The final page shows the relay, connector, and agent connection status. Use **Open my remote** to access the dashboard. You can stop and start the local services here.

## 3. Daily launch — no setup again

```bash
npm run local
```

This starts the saved local relay, any managed OpenCode server, and the paired connector. Managed Codex starts with the connector. It opens the local control page directly at the saved setup.

For a background service or a terminal without a desktop:

```bash
npm run local -- --no-open
```

Keep the process running. Closing the terminal or pressing Ctrl+C stops the local services it owns. A previously running OpenCode server or an external relay has its own lifetime. Tailscale Serve’s `--bg` configuration persists; to turn off this HTTPS route later, run `tailscale serve --https=443 off`.

After updating the project, run `npm ci` and `npm run build` before launching again.

### Start automatically at login

**Linux:** adjust the project and Node.js paths in [`deploy/agent-remote-local.service`](../deploy/agent-remote-local.service), then install it as your own user:

```bash
mkdir -p ~/.config/systemd/user
cp deploy/agent-remote-local.service ~/.config/systemd/user/
systemctl --user daemon-reload
systemctl --user enable --now agent-remote-local.service
systemctl --user status agent-remote-local.service
```

Stop the terminal launcher before starting the service so that only one process owns the relay and setup ports. This service starts the full local stack, so use it in place of a separate relay/connector service for this copy. It can read agent-server credentials from `~/.config/agent-remote/connector.env`.

To stop it: `systemctl --user stop agent-remote-local.service`. To remove automatic startup: `systemctl --user disable --now agent-remote-local.service`.

**macOS:** create a user LaunchAgent with your Node.js executable and arguments `--import tsx scripts/setup-gui.ts --start --no-open`, the project folder as `WorkingDirectory`, and a `PATH` containing your Node.js, agent executables, and the project’s `node_modules/.bin`. Enable Tailscale’s start-at-login option.

**Windows:** create a Task Scheduler task for your own user, triggered **At log on**. Select your `node.exe`, set arguments to `--import tsx scripts/setup-gui.ts --start --no-open`, and set **Start in** to the project folder. Make the agent executables available on its `PATH`. Enable Tailscale’s start-at-login option.

Configure the laptop’s power settings to stay awake while remote work runs. Sleep or a closed laptop lid can interrupt access.

## 4. Connect more laptops

On each additional laptop:

```bash
npm ci
npm run setup:gui
```

Choose **Connect another laptop** and enter the first laptop’s HTTPS relay address. Select this new laptop’s name, project folders, and local agent sources, then approve its pairing on the same phone. Run `npm run local` there for later launches.

The first laptop hosts the relay and must remain awake for all connected laptops. Each additional laptop uses its own connector token and its own local provider logins.

## Saved files and recovery

| File | Purpose |
| --- | --- |
| `.env` in the project | Relay URL, private relay key, bind address, port, and data directory. Existing keys and unrelated variables are preserved. |
| `.local/setup/settings.json` | Saved wizard choices and connector-file location. |
| `~/.config/agent-remote/connector.json` | Laptop identity, revocable device token, workspaces, and sources. `XDG_CONFIG_HOME` is supported. |
| `data/state.json` by default | Relay passkey/native public keys and hashed device credentials. |

Configuration files are written privately with mode `0600` on Unix. Keep them on the laptop and retain the relay data between launches. Setup capabilities and relay keys are not stored in browser local/session storage.

To choose a separate connector file, use `npm run setup:gui -- --config /absolute/path/connector.json`. Its location is remembered for `npm run local`. `--port 4316` selects the setup page’s port, separate from the relay port selected in the GUI.

If you change files outside the wizard, restart the launcher to load them. The wizard refuses to overwrite a different saved pairing. Existing enrolled relays must keep their original hostname; use the [hostname/passkey recovery instructions](../README.md#privacy-persistence-and-recovery) when deliberately migrating an established relay.

## What costs money?

- **Rented server:** $0 with this laptop-hosted setup.
- **Domain and HTTPS certificate:** $0 using Tailscale Serve’s supplied hostname.
- **Private networking:** Tailscale’s [Personal plan](https://tailscale.com/pricing) is free for eligible personal, non-commercial use. Use that plan rather than a business trial.
- **AI models:** your existing OpenCode providers and Codex subscription/API usage still apply.
- **Your laptop:** existing internet access and electricity are yours to provide.

This path uses your own online laptop instead of a free-tier cloud host that can sleep or impose WebSocket/runtime limits. The wizard can complete local configuration, but Tailscale sign-in, provider login, and physical-phone biometric verification happen on your devices.

## Verify the setup implementation

`npm run check` builds the app and runs the protocol/configuration and browser suites. The setup browser test uses a virtual authenticator with the real passkey verifier and fixture OpenCode/Codex servers; Tailscale CLI responses are simulated.

With OpenCode and Codex installed, `npm run test:setup-agents` checks actual managed OpenCode startup, actual Codex stdio initialization, and owned-process shutdown in isolated temporary agent homes. It submits no model prompts.
