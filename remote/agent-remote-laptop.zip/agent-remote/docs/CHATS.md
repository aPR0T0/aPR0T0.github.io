# Chats, activity, and requests across computers

Agent Remote 0.5.0 adds a chat-history menu to Android and the browser, with computer-scoped conversations and nested subagents.

## Update all parts

1. Install [`agent-remote-0.5.2.apk`](../releases/agent-remote-0.5.2.apk) over the existing Android app.
2. Update the Agent Remote files on the relay host **and every laptop running a connector**. The updated laptop kit is built at `dist-pages/agent-remote-laptop.zip`. Keep each installation’s existing `.env`, `data/`, `.local/`, and connector configuration.
3. Restart each laptop’s launcher/connector. Source installations use `npm run build` and `npm run local`; the laptop kit includes the built UI and its usual launcher.
4. In **Computers**, confirm the laptop is online and its OpenCode/Codex source is connected.

The APK alone cannot fix old connector status reporting. An agent must run through the local agent API connected on its own laptop. A standalone terminal process without that API remains **Not attached**. For Codex, connect to the app-server actually running the thread; a separate managed server cannot control an unrelated terminal process.

## Navigation

- **Android:** open **☰ Chats** or **☰ Chats & subagents**. Search by chat title, project, provider, or computer. Tap a conversation to open it.
- **Browser:** the left sidebar contains chat history; **Chats & subagents** opens the same menu on small screens.
- Subagents appear beneath their parent on the same computer. Orphaned subagents remain accessible when their parent is outside the loaded history.
- **Working** and **Needs input** activity controls switch back to all computers. Choose a computer afterward if you want to narrow the list.
- Android’s filtered activity/search lists omit computers with no matching chats. **All** and **Computers** keep offline-device information accessible.
- When a subagent matches a filter, its parent can appear as context even when that parent is idle.

## Answer requests

The browser’s **Needs input · all computers** section lists waiting conversations independently of the dashboard’s computer filter. Open one to review its pending requests above the conversation.

On Android, a chat with several requests opens a request chooser. You can select **any** pending request, including questions, rather than repeatedly opening only the first. Questions have radio buttons or checkboxes, plus a custom-answer field. Permission decisions remain **Allow once** or **Decline**.

Each reply is bound to the selected computer, conversation, and request. Offline/stale sources cannot receive control commands. A waiting state with no available request payload explicitly directs you to the owning agent client; the app does not invent an approval or silently approve it.

## Edit and copy

- **Copy message** (web) or **Copy** (Android) copies visible message text. Tool output is collapsible.
- **Edit as draft** puts a previous user instruction into the composer. You can edit it and send a new instruction. It does not rewrite the agent’s past transcript.
- Unsent drafts stay with their specific chat while you switch between computers. They are kept in memory and cleared when the remote locks.
- Browser conversation updates preserve your reading position when you scroll up.

## Status fixes

- OpenCode refreshes load pending-request sessions even when they are absent from recent history and the busy map. Idle data from another directory scope no longer overwrites an active scope.
- Codex reads loaded-thread runtime state from its owning server instead of using persisted history status. Newer status notifications win over a racing read.
- New subagent questions arriving during a refresh are retained until their thread appears in the next loaded-thread list.
- Connector deduplication prefers a live waiting/working source and preserves parent relationships when selecting a source route.
- Both interfaces retain device IDs in chat keys, so identical session IDs on different laptops stay separate.

## Editing the interface

The UI uses the existing React/native Android stack, with no new runtime dependencies:

| Concern | Web | Android |
| --- | --- | --- |
| Chat index | `shared/chat-index.ts` | `DeviceSections.kt` |
| Chat history menu | `src/components/ChatNavigation.tsx` | `ChatMenu.kt` |
| Request UI | `RequestInbox.tsx`, `ApprovalCard.tsx` | `RequestReview.kt` |
| Conversation and composer | `AgentConversation.tsx` | `MainActivity.kt`, `RemoteModel.kt` |

Android source files are under `android/app/src/main/java/app/agentremote/`. Android menus use RecyclerView; web message polling avoids overlapping reads. Source protocols, local-only agent endpoints, passkey/biometric verification, request idempotency, and private networking retain their existing boundaries.
