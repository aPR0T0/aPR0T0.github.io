# One start page for every device

Start at **https://apr0t0.github.io/remote/**. Enter your relay laptop’s Tailscale HTTPS address once, or open a connection link shared from the laptop wizard. The page can remember the address in that browser.

## Use a phone, tablet, or laptop as a remote

1. Install [Tailscale](https://tailscale.com/download) on the device.
2. Sign in to the **same Tailscale account/network** as your relay laptop and turn the connection on.
3. Confirm the relay laptop appears in Tailscale’s device list.
4. Open the start page, enter the relay’s `.ts.net` address, and choose **Open my workspace**.
5. Unlock on the private relay using its API key and a passkey.

The browser works on supported desktop and mobile platforms. You can use a device passkey, a phone passkey, or a security key; a built-in fingerprint reader is optional. Verification remains required. The existing native Android app also works with the same relay address and key.

### Link a new browser after using the Android app

The new browser needs either an existing synced passkey or authorization to create its own passkey:

1. Unlock the trusted Android app and choose **Settings → Authorize another phone**. This existing app action now creates a code that also works for a browser.
2. Keep that phone unlocked. Copy the one-time code to the new laptop/browser.
3. On the new browser’s private relay login page, select **Link a new device**.
4. Enter the relay API key and device-link code, then complete passkey creation.

An already-unlocked browser can generate the same code with **Settings → Link another device**. Codes expire after five minutes, can be used once across native/browser enrollment, and stop working if the authorizing device is locked before registration finishes. They are not placed in public URLs or browser storage.

After linking, use the regular unlock button. This does not change the relay’s hostname, remove existing credentials, or reset your phone.

## Connect the agents on an additional laptop

The viewing browser needs Tailscale. A laptop whose **own** OpenCode/Codex agents you want to control also needs the local Agent Remote connector.

1. On the start page, choose **Connect this laptop’s agents** and download the laptop kit.
2. Install Node.js 24 and Tailscale, then extract the ZIP into a permanent folder.
3. Open the included Windows, macOS, or Linux launcher. The first run installs dependencies and opens the setup GUI; later runs use the saved setup.
4. Choose **Connect another laptop**, paste the existing relay URL, and choose that laptop’s project folders and local agent sources.
5. Approve the laptop’s pairing code from an unlocked remote.

Open the same launcher for daily use. Reopening it finds the existing setup process and opens its private control page. Its launch capability is recorded in an owner-only `.local/setup/launcher.json` file and is invalid after that process stops.

Use **This laptop + Tailscale** only on a laptop intended to host a relay. One relay can coordinate several connected laptops.

## Why the GitHub page opens a Tailscale address

GitHub Pages serves the permanent start page and clean laptop download for free. The live app needs a running relay for API requests, WebSockets, and passkey verification. That relay stays on your laptop and is reached through Tailscale Serve.

The public page opens the private relay as a normal top-level browser navigation. Authentication stays on the relay’s original HTTPS hostname, keeping passkeys, cookies, and WebSockets on their expected origin. The public page does not fetch agent data or ask for model/relay keys. Only relay addresses can be saved in its browser storage; shared connection links carry the address in the URL fragment.

All viewing devices must have Tailscale connected. GitHub Pages cannot turn on a device’s VPN or run a laptop connector on its behalf.

## Troubleshooting

The local wizard now shows other devices visible on the laptop’s Tailscale network. If it shows no other devices, check that the phone/new laptop has joined the same account/network. An online peer is useful evidence, but test from the viewing device too.

Open `https://YOUR-LAPTOP.YOUR-TAILNET.ts.net/api/health` in that device’s browser. A response containing `"ok":true` confirms it reached the relay. If it cannot connect:

- Turn on Tailscale on both devices, and check they use the same network.
- Keep the relay laptop awake and the launcher running.
- Verify Tailscale Serve forwards HTTPS port 443 to the local relay port, normally 4317.
- On Android, check per-app routing and whether another VPN replaced Tailscale.
- Use **Check Tailscale** in the setup wizard to refresh its device list.

## Build and publish the public files

From the source project:

```bash
npm ci
npm run build:pages
npm run stage:pages -- /path/to/apr0t0.github.io
```

The build uses relative asset paths so it can live under `/remote/`. The laptop ZIP uses an allowlist of runtime source, built UI, launchers, and selected instructions. `.env`, `.local/`, relay data, laptop connector configurations, Android signing material, and conversation history are excluded. It includes a per-file manifest; the public download also has a SHA-256 checksum.

The staging command checks the public manifest and refuses to overwrite separately edited generated files. Review and commit only the intended `/remote/` files and any deliberate navigation link. The portfolio’s normal Pages workflow deploys them.
