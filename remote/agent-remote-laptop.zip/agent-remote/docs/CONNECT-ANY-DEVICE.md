# One start page for every device

Start at **https://apr0t0.github.io/remote/**. Enter your relay laptop’s Tailscale HTTPS address once, or open a connection link shared from the laptop wizard. The page can remember the address in that browser.

## Use a phone, tablet, or laptop as a remote

1. Install [Tailscale](https://tailscale.com/download) on the device.
2. Sign in to the **same Tailscale account/network** as your relay laptop and turn the connection on.
3. Confirm the relay laptop appears in Tailscale’s device list.
4. Open the start page, enter the relay’s `.ts.net` address, select **Link this as a new device** if needed, and choose **Open my workspace**. The relay login continues in the same browser window.
5. Unlock on the private relay using its API key and a passkey.

The browser works on supported desktop and mobile platforms. You can use a device passkey, a phone passkey, or a security key; a built-in fingerprint reader is optional. Verification remains required. The existing native Android app also works with the same relay address and key.

### Link a new browser after using the Android app

The new browser needs either an existing synced passkey or authorization to create its own passkey:

1. Unlock the trusted Android app and choose **Settings → Link another device** (called **Authorize another phone** before 0.4.2).
2. Tap **Copy device-link URL** and transfer that link to your laptop. It includes the relay address and one-time code. **Copy device-link code** is available if you prefer to paste only the code. Copying uses the current device’s clipboard; cross-device clipboard sync depends on your devices.
3. With Tailscale connected on the laptop, open the copied URL. The browser automatically selects **Link a new device** and fills in the code. For code-only copying, select that option and paste the code yourself.
4. Enter the relay API key and complete passkey creation in that same window. With relay 0.5.2 or newer, you can switch apps or lock the authorizing phone after copying. Finish linking within five minutes of creating the code.

An already-unlocked browser provides both copy buttons under **Settings → Link another device**. From relay 0.5.2 onward, codes are independent five-minute grants: locking the issuing device revokes its app session but preserves the code until its original expiry. Claiming a code consumes it once across native/browser enrollment; the new device must also finish verification before the original deadline. Cancelled verification needs a fresh code. Restarting the relay clears outstanding codes. Device-link URLs point directly to your private relay and carry the code in a URL fragment, which is removed from the address bar when the login form loads. Codes are not put in the public start-page URL, HTTP query strings, or browser storage. Share these one-use links only with the device you intend to authorize. Your relay API key is never included.

**Code expires as soon as you switch apps?** Update and restart the **relay host** with 0.5.2 or newer, then create a fresh code. The older relay invalidated codes when the authorizing app locked. Updating only the APK does not change that server behavior. Open `/api/health` on your relay to check its running version.

If the relay is a Linux **system** service, the kit includes `scripts/update-relay.py`. Run it as the installation owner with `--target /path/to/the/running/relay --service your-relay.service` for a preflight check; add `--apply` to update. It verifies that the service's Node process owns the relay port and runs from that folder, checks the download and package manifests, installs dependencies before downtime, and backs up replaced program files/dependencies. It leaves configuration and relay data in place, restarts only the selected system service, and checks the live version. A failed health check restores the previous program/dependency files and restarts the previous service. Locally edited manifest-tracked code requires review first. This updater is separate from a laptop connector's user service.

Android 0.4.2 also has **Connect Tailscale** on the lock screen and in Settings. It opens the installed Tailscale app, or its official download page if missing. Tailscale remains the system VPN client; Agent Remote does not embed a VPN engine. In the laptop wizard, **Connect Tailscale** starts the local client’s sign-in flow and detects the resulting connection automatically. The public browser guide covers all device types, with installation and VPN approval handled by the device’s OS.

After linking, use the regular unlock button. This does not change the relay’s hostname, remove existing credentials, or reset your phone.

## Connect the agents on an additional laptop

The viewing browser needs Tailscale. A laptop whose **own** OpenCode/Codex agents you want to control also needs the local Agent Remote connector.

1. On the start page, choose **Connect this laptop’s agents** and download the laptop kit.
2. Install Node.js 24 and Tailscale, then extract the ZIP into a permanent folder.
3. Open the included Windows, macOS, or Linux launcher. The first run installs dependencies and opens the setup GUI; later runs use the saved setup.
4. Choose **Connect another laptop**, paste the existing relay URL, and choose that laptop’s project folders and local agent sources.
5. Approve the laptop’s pairing code from an unlocked remote.

Open the same launcher for daily use. Reopening it finds the existing setup process and opens its private control page. Its launch capability is recorded in an owner-only `.local/setup/launcher.json` file and is invalid after that process stops.

Use **This laptop + Tailscale** only on a laptop intended to host a relay. One relay can coordinate several connected laptops.

## Why the GitHub page opens a Tailscale address

GitHub Pages serves the permanent start page and clean laptop download for free. The live app needs a running relay for API requests, WebSockets, and passkey verification. That relay stays on your laptop and is reached through Tailscale Serve.

The public page opens the private relay as a normal top-level browser navigation. Authentication stays on the relay’s original HTTPS hostname, keeping passkeys, cookies, and WebSockets on their expected origin. The public page does not fetch agent data or ask for model/relay keys. Only relay addresses can be saved in its browser storage; shared connection links carry the address in the URL fragment.

All viewing devices must have Tailscale connected. GitHub Pages cannot turn on a device’s VPN or run a laptop connector on its behalf.

## Troubleshooting

The local wizard now shows other devices visible on the laptop’s Tailscale network. If it shows no other devices, check that the phone/new laptop has joined the same account/network. An online peer is useful evidence, but test from the viewing device too.

Open `https://YOUR-LAPTOP.YOUR-TAILNET.ts.net/api/health` in that device’s browser. A response containing `"ok":true` confirms it reached the relay. If it cannot connect:

- Turn on Tailscale on both devices, and check they use the same network.
- Keep the relay laptop awake and the launcher running.
- Verify Tailscale Serve forwards HTTPS port 443 to the local relay port, normally 4317.
- On Android, check per-app routing and whether another VPN replaced Tailscale.
- Use **Check Tailscale** in the setup wizard to refresh its device list.

## Build and publish the public files

From the source project:

```bash
npm ci
npm run apk
npm run build:pages
npm run stage:pages -- /path/to/apr0t0.github.io
```

The build uses relative asset paths so it can live under `/remote/`. The laptop ZIP uses an allowlist of runtime source, built UI, launchers, and selected instructions. `.env`, `.local/`, relay data, laptop connector configurations, Android signing material, and conversation history are excluded. It includes a per-file manifest; the public download also has a SHA-256 checksum.

The staging command checks the public manifest and refuses to overwrite separately edited generated files. Review and commit only the intended `/remote/` files and any deliberate navigation link. The portfolio’s normal Pages workflow deploys them.
