# Android app

**Current APK: [Agent Remote 0.6.0](../releases/agent-remote-0.6.0.apk).** Device-link codes survive app switching with relay 0.5.2 or newer. Relay 0.6.0 also supports the optional [Linux fingerprint companion](LINUX-FINGERPRINT.md). See the [device-link guide](CONNECT-ANY-DEVICE.md), [chat guide](CHATS.md), and [transfer guide](TRANSFERS.md).

The Android app is a **native, signed APK** with a simple agents-first interface. It uses Android Keystore and the system biometric prompt, and talks to the same private relay and laptop connectors as the web dashboard.

## Install and connect

1. Copy [`agent-remote-0.6.0.apk`](../releases/agent-remote-0.6.0.apk) to your phone and install it **as an update over the existing app**. Android 9 / API 28 or newer and an enrolled strong biometric are required. Update and restart the relay for new authentication features, and update each laptop’s connector for activity/subagent and transfer fixes.
2. Run `npm run setup:gui` on your laptop and choose **This laptop + Tailscale** for a stable private HTTPS address with no rented server. Install Tailscale on the phone too. Follow the [one-time setup guide](SETUP.md); Docker/Caddy is also covered in the main [README](../README.md#2-put-the-relay-online).
3. Open **Agent Remote**. Enter that HTTPS address and the **relay API key** shown by the wizard once, then choose **Save key and unlock**.
4. Complete the system biometric prompt. A successful first unlock enrolls this phone's public key and saves the API key encrypted. Later openings ask only for biometrics.
5. In the laptop wizard, click **Create pairing code** and enter that code in **Computers → Connect a computer** on the phone. The terminal command `npm run connector -- pair` also works.

The relay must be reachable by both the phone and the laptop connectors. That is what provides access across different Wi-Fi networks. The delivered APK has no embedded relay address, API key, account, or test certificate.

### Daily use

- **Agents:** search chats and view activity across computers. Working/Needs input filters return to all computers and omit empty sections.
- **Chats menu:** searchable history with subagents nested beneath their own computer’s parent chat.
- **Agent details:** read/copy replies, expand tool output, edit a past instruction as a new draft, stop a turn, or choose any of the agent’s pending requests. Unsent drafts remain scoped to their chat until locking.
- **New task:** choose the computer, source, workspace, and optional model.
- **Computers:** verify paired identities and revoke a connector's access.
- **Settings:** view/change the relay address, connect Tailscale, or link another device with a copyable code or pre-filled URL.

If an agent is shown as **Not attached**, connect the server that owns its live session. A standalone process sharing a session database does not automatically provide a remote-control interface.

## Authentication and locking

- The app supplies the encrypted saved API key automatically and asks for a new biometric-gated signature from its P-256 Android Keystore key. **Settings → Change API key** explicitly replaces the saved value after validation.
- The app requests **BIOMETRIC_STRONG**, with **no device-PIN/password fallback**. The Android system selects the enrolled strong modality, normally fingerprint on fingerprint-equipped phones; compatible strong face authentication may also be offered.
- The private key is non-exportable through Keystore APIs and requires authentication for each signing operation. It is configured to invalidate when the enrolled biometrics change.
- The relay verifies a single-use, two-minute challenge bound to the protocol, exact relay origin, and public-key identity. A known API key alone cannot enroll a replacement phone once the relay has a trusted credential.
- Plaintext API keys are not written to preferences, saved view state, backups, or logs. An AES-GCM encrypted key record is retained in private no-backup storage, protected by a separate Android Keystore key. Only the public relay URL is saved in preferences. Login tokens and conversations stay in memory.
- Going into the background immediately locks the native app, clears its in-memory session/UI data, and requests server-side revocation. A failed network revocation is bounded by the server's 15-minute idle and 12-hour absolute expiry.
- `FLAG_SECURE` blocks normal screenshots/recents capture. Backup/transfer exclusions, secure touch handling, and overlay hiding on supported Android versions protect the UI.

The server proves possession of the enrolled signing key; it does not perform Android hardware attestation. Actual hardware protection depends on the phone. The relay is trusted and can see the content it forwards; this is TLS transport encryption, not end-to-end encryption through an untrusted relay.

## Another phone or recovery

In v0.4.1, an unrecognized phone key automatically opens **Restore this phone’s access** on the lock screen. Get a device-link code from an unlocked browser’s **Settings → Link another device → Create link code**, paste it into the app, and tap **Reconnect this phone**. The app uses its saved API key automatically. You can also open this form using **Reconnect or link this phone**. If this is a fresh install, the entered key stays in the secure form while you add the code.

Cancelled or rejected one-time codes give a clear instruction to create a fresh code. Changing the phone’s biometric enrollment can invalidate its signing key; the same recovery form handles that condition. An APK cannot reconstruct a private key removed by Android, so a currently untrusted installation still needs one trusted-device authorization.

On an already-unlocked Android phone, choose **Settings → Link another device → Copy device-link code**. Paste the code under **Reconnect or link this phone** on the new phone and complete its biometric prompt. The token expires five minutes after creation and can be claimed only once. With relay 0.5.2, switching apps or locking the source phone preserves that code while revoking the source app session normally. Older APKs call the Settings action **Authorize another phone**.

To link a laptop browser, use **Copy device-link URL** instead. Open it on the laptop to pre-fill the code, then enter the relay key and verify a passkey. Update the relay/web build too to enable URL pre-filling and background-safe codes. You may switch to a messaging app to send the link; finish verification within the code’s original five-minute window. See [Connect any device](CONNECT-ANY-DEVICE.md).

**Connect Tailscale** is available on the lock screen and in Settings. It opens Tailscale if installed, otherwise the official Android download page. Sign in, enable the VPN, approve Android’s prompt, and return to Agent Remote. This is an integration with the installed VPN client, not an embedded VPN engine.

If the relay was previously enrolled only through the web app, or every trusted phone/key is unavailable, stop the relay and use `npm run reset-passkeys` on its host, then enroll the Android phone. The Docker equivalent is documented in the main README. That local recovery resets both native keys and web passkeys; paired laptops retain their identities.

If biometrics change, the invalidated local key is replaced only after the phone is re-authorized or the relay is reset. Changing to a different relay hostname creates a separate local key identity.

## Connection behavior

HTTPS and WSS are mandatory. The release trusts system certificate authorities, rejects untrusted certificates, and does not follow redirects. It has no WebView or JavaScript bridge.

Socket cleanup runs on background threads. Network changes invalidate the old connection and reconnect with bounded backoff. An offline or stale agent cannot receive a new instruction from the UI. Requests have bounded sizes, queues, and timeouts.

Mutating commands carry a unique operation ID. The relay persists a hash-only receipt **before dispatch**, preventing duplicate dispatch after repeated submissions or a relay restart. An uncertain outcome is retained rather than automatically replayed. Receipts are bounded to 10,000 per rolling day. If delivery is not confirmed, inspect the agent before deliberately sending a new instruction.

## Build

From the project folder, with Node.js 24:

```bash
npm ci
npm run android:bootstrap
npm run apk
```

On Linux, bootstrap downloads the JDK, Gradle, Android SDK, and emulator to the ignored `.local/android-tools/` cache. Downloads are checked against publisher-provided checksums. `AGENT_REMOTE_TOOLS` overrides this location.

The build generates a private signing keystore and password under `.local/android-signing/`, with owner-only permissions. **Keep those files privately backed up** to sign compatible future updates. They are excluded from Git, the Docker context, and the APK. The build emits:

```text
releases/agent-remote-0.6.0.apk
releases/SHA256SUMS
releases/SIGNING-CERT.txt
```

The app is minified, non-debuggable, targets Android 16 / API 36, and uses APK Signature Scheme v2 with an RSA-3072 signing key.

## Reproduce the tests

```bash
npm run android:prepare-tests
npm run apk -- :app:assembleRelease :app:assembleReleaseAndroidTest :app:lintRelease :app:testReleaseUnitTest
npm run test:android
npm test
npm run test:opencode
npm run test:codex
npm run android:gradle -- :app:writeRuntimeInventory --console=plain
npm run audit:apk
```

The Android harness uses only the isolated **AgentRemoteSecurityLab** emulator on `emulator-5558`. Its test CA is installed in that emulator's system trust store; the production APK is tested with its normal system-only TLS policy. The lab's OpenCode/Codex task adapters use fixtures, so these tests do not spend model credits or operate your real sessions. Separate compatibility commands check installed OpenCode/Codex APIs without submitting model prompts.

The release instrumentation uses real Android biometric/Keystore operations with simulated fingerprint touches, not a boolean authentication stub. Test-only instrumentation is built separately and is not part of the delivered APK.

To stop the isolated lab:

```bash
npm run android:lab -- stop
npm run android:emulator -- stop
```

See [the test report](SECURITY-TEST-REPORT.md) for exact results, scope, and remaining physical-device checks.
