# Agent Remote 0.5.0 — chat and activity verification

Checked September 15, 2026, with Node 24.11.0 and the isolated Android 13 emulator.

## Artifacts

- [`releases/agent-remote-0.5.0.apk`](../releases/agent-remote-0.5.0.apk): signed, minified Android release, versionCode 7.
- `dist/`: production browser dashboard and laptop setup UI.
- `dist-pages/agent-remote-laptop.zip`: updated relay/connector kit and setup instructions.
- [Chat guide](CHATS.md): usage, update requirements, and UI module locations.

APK SHA-256:

```text
92e4aaf8d198bf3b79fd2297a0d2c37bdb6d11e3d4376dee9d387db775cbfca7
```

The APK signature and increasing versionCode were checked against all five earlier release APKs. Install it over the existing app. A full trust-retention upgrade test was not repeated in this iteration.

## Verified

| Check | Result |
| --- | --- |
| TypeScript typecheck and production builds | Passed |
| Unit/integration suite | 70 tests passed |
| Browser suite | 9 tests passed |
| Android release assembly, lint, unit tests | Passed |
| Focused signed-release Android cross-laptop test | Passed |

The two-connector browser test runs real relay and connector code against separate local OpenCode API fixtures. Both laptops deliberately use identical session and request IDs. It verifies global Working counts, nested subagent navigation, permission/question handling, reply isolation to the intended laptop, per-chat draft retention, editable instructions, and disabled sending after disconnect.

The Android test `NativeReleaseTest#a19_crossLaptopChatsSubagentsAndAllRequests` verifies:

- Working returns to all computers after selecting one laptop.
- Offline/empty sections do not bury matching chats.
- A second laptop’s subagent appears in the searchable chat menu.
- The second of two requests can be selected and answered with multiple choices.
- The remaining permission request can then be answered.
- Switching between that chat and another computer’s Codex chat preserves separate drafts.
- Conversation messages load and **Edit as draft** updates the composer.

Adapter regressions cover OpenCode pending sessions outside recent history, cross-directory active status preservation, Codex runtime/history differences, status-notification races, subagent ancestry, and a new subagent question arriving during a loaded-thread refresh.

## Security and size

No new runtime dependencies or Android permissions were added. Android chat menus use RecyclerView. Web polling prevents overlapping conversation reads. Drafts stay in memory and are cleared on lock; copied message contents are marked sensitive on Android.

Passkey/native biometric authentication, private local agent endpoints, computer-scoped command routing, request idempotency, and offline/stale control checks remain in place. New Android dialogs use the existing secure-window and obscured-touch protections. Raw agent reasoning is still excluded from forwarded conversation data.

The production app-specific JavaScript is 58.83 kB gzip (about 2.2 kB more than 0.4.2), plus the existing shared bundle. The native release remains minified with resource shrinking.

The automated scenarios use fixture agents and spend no model credits. Your laptops still need their own updated, connected agent APIs. These artifacts were built locally; publishing the public site and updating other devices are deployment steps.
