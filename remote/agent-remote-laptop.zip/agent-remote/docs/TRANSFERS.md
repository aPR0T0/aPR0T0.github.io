# Separate devices and chat handoff

**Current APK:** [`releases/agent-remote-0.5.2.apk`](../releases/agent-remote-0.5.2.apk)

## Finding transferred chats in Codex — 0.5.1

A **paused** transfer is stored only in Agent Remote. It is not yet a native Codex thread. Send its first instruction on the destination to create the native continuation; this intentionally avoids starting model work during transfer confirmation.

After that instruction, look for **Transferred · <original title>** in Codex on the destination laptop. Open **Find this chat in Codex** in the APK, or the transfer information in the browser, to copy its native session ID or `codex resume <session-id>` command.

The Codex window and connector must use the same OS user, `CODEX_HOME`, and project directory. Windows and WSL homes can be different, as can profiles used by separate installations. Refresh the Codex history list and check project filters. ChatGPT's cloud conversations are not the local Codex history.

0.5.1 explicitly creates a persistent, named Codex thread and saves its ID before submitting work. After a connector restart, an explicit continuation reattaches that same destination-owned thread instead of creating another or leaving it read-only. A failed first start retains its known native ID for inspection and is never replayed automatically. Older, already-started transfers keep their previous native title but expose their saved session ID.

The installed Codex 0.154.0 was tested with a localhost model fixture: two turns, a connector restart, and a separate Codex client listing/reading the persisted chat. No paid model calls were made. Creating an empty thread or injecting model-visible context alone did **not** make a paused chat appear in the native history list, so the app does not claim otherwise. The test verifies Codex's actual persisted listing/read APIs; a desktop GUI was not automated here.

Run `npm run test:codex-transfer` to reproduce it. Newer Codex threads use paginated history, which the connector now reads through `thread/items/list` and `thread/turns/list`.

## Devices are separate

The Android **Agents** screen groups chats under each computer's own name, unique ID, connection state, and agent count. Offline computers and computers with no matching agents keep their own section.

Use **All computers** to select a single device, tap a device section to focus it, or choose **Computers → View agents on…**. Identical chat names/session IDs on different devices remain distinct.

## Transfer a chat

1. Open the source chat. Let the current turn finish, or stop it and wait for **Ready**.
2. Tap **Transfer chat**.
3. Select another connected computer, an agent source, and one of that computer's configured project folders.
4. Tap **Prepare preview**. Review the destination name/ID and the actual context that will be sent.
5. Edit or remove anything you do not want to share. If you edit the text, tap **Review changes**, then inspect the updated preview.
6. Tap **Transfer paused chat**. Open the transferred chat on the destination and send a new instruction when you want it to continue.

The destination receives a **paused continuation**, not a running-process checkpoint. The source chat remains available as a recovery copy. Preparing/reviewing a transfer performs no work on the destination; confirming it stores the reviewed context, and model work begins only with your next instruction there.

The handoff format is provider-independent text, so the selected destination can use OpenCode or Codex with its own configured model and permissions.

## What is included

- Visible user/assistant conversation text, with role labels.
- The reviewed title and source-device provenance.
- Your chosen destination source and workspace.

The workflow excludes tool-log/system-message records, hidden reasoning, outstanding approvals, provider configuration, and account credentials stored by the agents. It does **not** copy repositories, files, processes, or filesystem changes. Prepare the relevant project files on the destination separately.

Up to 200 recent message records are available from the existing conversation APIs; the handoff preview is bounded to 64,000 characters. The preview explicitly reports omitted/limited history. This is a portable conversation snapshot, not a byte-for-byte native session migration.

## Safety behavior

- Your existing API-key/biometric-authenticated session authorizes the flow.
- Previews belong to the login that created them, expire after five minutes, and stay in relay memory rather than being written to its data file.
- Both device identities and destination capabilities/workspace are checked before preparing and again before delivery. Revoking/re-pairing a device invalidates an old preview.
- The source is freshly checked for an idle state and re-exported before delivery. If its revision changed after review, confirmation is rejected and a new preview is required.
- Common API tokens, bearer credentials, password assignments, URL credentials, and private-key blocks are masked. This is best-effort detection; **review remains necessary** for secrets without a recognizable pattern or private information embedded in prose.
- Changes to the preview require a new server-issued review hash. Internal export/stage commands cannot be invoked through the public agent-command endpoint.
- Only the reviewed context is delivered. The destination starts with its own permissions; old tool approvals are not carried over.
- Transfer receipts and destination IDs prevent duplicate staging. A lost acknowledgement is reported as uncertain, with **Check status** rather than an automatic retry. A fresh matching destination snapshot can confirm a previously uncertain delivery.
- A destination copy remains paused across connector restarts. A crash during its first native start leaves an uncertain state that cannot automatically launch another agent. Inspect the native sessions before starting fresh work.

The private relay can see the context it forwards. HTTPS/WSS protects transport; this feature does not add end-to-end encryption through an untrusted relay.

## Update both sides

Install the current APK and update/restart the relay **and each laptop connector** from this project. Existing pairings can be reused. Older connectors do not advertise transfer support and are excluded from destination choices.

Both the CLI connector and local setup launcher enable persistent handoff storage beside the connector configuration:

```text
<connector-config-directory>/chat-data/<pairing-identity-hash>/chats.json
```

The scope is tied to the unique device ID and its pairing token, so switching between the CLI and setup launcher retains the same handoffs. On Unix, directories/files use owner-only `0700`/`0600` permissions. The destination stores reviewed text locally; the relay persists only delivery metadata/hashes. Limits are 200 transferred chats per destination store and 10,000 transfer receipts per relay. These files are private application data and should follow your normal computer-backup/retention policy.

Embedders constructing `Connector` directly must supply `{ stateDirectory: ... }` to enable durable transfer support.

## Historical verification — 0.3.0

- **14/14 Android release instrumentation tests**, including device isolation, edited-preview review, paused delivery, and continuation only on the destination.
- **56/56 Node tests**, including 14 transfer-specific tests for authorization, cross-provider dispatch, source changes, device rebinding, workspace changes, cancellation, expiry, concurrent confirmation, lost delivery, redaction, private persistence, and reconnect-safe continuation.
- **5/5 Android JVM tests**, including grouped/empty/offline devices and identical session IDs across computers.
- **4/4 browser/setup flows** remain passing.
- Signed, non-debuggable APK; Android lint has no errors; 9 artifact/security checks pass, including tamper rejection and a clean test-key log scan.
- **52 runtime Android dependencies:** zero known OSV findings at audit time. This is not a guarantee against undisclosed vulnerabilities.

APK SHA-256: `8179963f38c95198b6fcf5314e4fa174ce8ec598b728da78d8414cf952d50872`

Signing-certificate SHA-256: `2c89b24ba982ba8177cdbbce103901c72bc6ec840dc071cf03d219dbd2a7e865`

Evidence: [`docs/evidence/android-0.3.0/`](evidence/android-0.3.0/). Device tests use the signed release on an isolated Android 13 emulator with real Keystore operations and simulated fingerprint touches. Handoff task execution uses isolated agent fixtures. Physical-device/public-network checks and the broader limitations in the [security report](SECURITY-TEST-REPORT.md#scope-limits) still apply.
