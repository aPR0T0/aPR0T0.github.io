import { execFile } from 'node:child_process';
import { access } from 'node:fs/promises';
import { join } from 'node:path';
import { promisify } from 'node:util';
import type { TailscaleStatus, ToolCheck } from '../shared/setup';
import { array, object, string } from '../connector/adapters/common';

const exec = promisify(execFile);
export type RunCommand = (binary: string, args: string[]) => Promise<string>;
export const runCommand: RunCommand = async (binary, args) => {
  const result = await exec(binary, args, { timeout: 12_000, maxBuffer: 256 * 1024, windowsHide: true });
  return result.stdout;
};

export async function tailscaleBinary(): Promise<string> {
  if (process.env.TAILSCALE_BIN) return process.env.TAILSCALE_BIN;
  const installed = process.platform === 'darwin' ? '/Applications/Tailscale.app/Contents/MacOS/Tailscale' : process.platform === 'win32' ? join(process.env.ProgramFiles || 'C:\\Program Files', 'Tailscale', 'tailscale.exe') : undefined;
  if (installed && await access(installed).then(() => true, () => false)) return installed;
  return 'tailscale';
}

export async function checkTool(binary: string, run: RunCommand = runCommand): Promise<ToolCheck> {
  try {
    const output = await run(binary, ['--version']);
    return { available: true, version: output.replace(/\x1b\[[0-9;]*m/g, '').trim().split('\n')[0].slice(0, 100) };
  } catch { return { available: false }; }
}

export async function checkTailscale(port: number, run: RunCommand = runCommand): Promise<TailscaleStatus> {
  const binary = await tailscaleBinary();
  let state: Record<string, unknown>;
  try { state = object(JSON.parse(await run(binary, ['status', '--json']))); }
  catch {
    const installed = (await checkTool(binary, run)).available;
    return { installed, running: false, serving: false, conflict: false, message: installed ? 'Open Tailscale and sign in on this laptop, then check again.' : 'Install Tailscale on this laptop and your phone, then sign in to the same account.' };
  }
  const dns = string(object(state.Self).DNSName).replace(/\.$/, '');
  const url = /^[a-z0-9-]+(?:\.[a-z0-9-]+)+\.ts\.net$/i.test(dns) ? `https://${dns}` : undefined;
  const running = state.BackendState === 'Running';
  const devices = Object.values(object(state.Peer)).slice(0, 100).map((peer) => {
    const item = object(peer);
    return { name: string(item.HostName, 'Connected device').slice(0, 100), os: string(item.OS).slice(0, 40), online: item.Online === true };
  });
  const result: TailscaleStatus = { installed: true, running, url, serving: false, conflict: false, devices, message: !running ? 'Open Tailscale and sign in on this laptop, then check again.' : !url ? 'Enable MagicDNS in your Tailscale DNS settings, then check again.' : 'Ready to enable private HTTPS for this laptop.' };
  if (!running || !url) return result;
  try {
    const serve = object(JSON.parse(await run(binary, ['serve', 'status', '--json'])));
    const web = object(serve.Web);
    const handlers = object(object(web[`${dns}:443`]).Handlers);
    const proxy = string(object(handlers['/']).Proxy);
    const target = `http://127.0.0.1:${port}`;
    const funnel = Object.entries(object(serve.AllowFunnel)).some(([key, value]) => key.endsWith(':443') && value === true);
    const tcp = object(object(serve.TCP)['443']);
    const otherWeb = Object.keys(web).some((key) => key.endsWith(':443') && key !== `${dns}:443`);
    const extraPaths = Object.keys(handlers).some((key) => key !== '/');
    result.conflict = funnel || otherWeb || extraPaths || (!!proxy && proxy.replace(/\/$/, '') !== target) || (!!handlers['/'] && !proxy) || (!!Object.keys(tcp).length && tcp.HTTPS !== true);
    result.serving = proxy.replace(/\/$/, '') === target && tcp.HTTPS === true && !result.conflict;
    result.message = result.conflict ? 'Tailscale port 443 already has another route or Funnel enabled. Keep that configuration and use an existing relay URL, or adjust it in Tailscale before continuing.' : result.serving ? 'Private HTTPS is forwarding to your local relay.' : 'Ready to enable private HTTPS for this laptop.';
  } catch { result.conflict = true; result.message = 'Could not inspect Tailscale Serve. Run tailscale serve status in a terminal before enabling HTTPS.'; }
  return result;
}

export async function enableTailscale(port: number, run: RunCommand = runCommand): Promise<TailscaleStatus> {
  const before = await checkTailscale(port, run);
  if (!before.running || !before.url || before.conflict || before.serving) return before;
  try { await run(await tailscaleBinary(), ['serve', '--bg', '--https=443', `http://127.0.0.1:${port}`]); }
  catch { return { ...before, message: 'Tailscale needs a one-time terminal step. Run the command below, follow its HTTPS activation link or administrator prompt, then click Check Tailscale.' }; }
  return checkTailscale(port, run);
}

export async function checkRelay(url: string) {
  try {
    const response = await fetch(new URL('/api/health', url), { signal: AbortSignal.timeout(8000), redirect: 'error' });
    const value = object(await response.json());
    if (!response.ok || value.ok !== true || typeof value.version !== 'string') throw new Error('Not a relay');
    return { ok: true, message: 'Agent Remote is reachable at this address from the laptop. Open it on your phone to check the phone’s connection too.' };
  } catch { return { ok: false, message: 'Could not reach Agent Remote at this address. Check the URL, that the relay is running, and that Tailscale is connected on both devices.' }; }
}

export function openCodeHealth(value: unknown): string | undefined {
  const result = object(value);
  return result.healthy === true ? string(result.version, 'ready').slice(0, 80) : undefined;
}

export function discoveredEndpoints(value: { endpoints: { provider: 'opencode' | 'codex'; url: string }[]; warning?: string }) {
  return { endpoints: array(value.endpoints).map((endpoint) => { const item = object(endpoint); return { provider: item.provider as 'opencode' | 'codex', url: string(item.url) }; }), ...(value.warning ? { warning: value.warning } : {}) };
}
