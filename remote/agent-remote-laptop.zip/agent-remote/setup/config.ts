import { randomBytes } from 'node:crypto';
import { homedir, hostname, platform } from 'node:os';
import { dirname, isAbsolute, join, resolve } from 'node:path';
import { mkdir, readFile, realpath, rename, rm, stat, writeFile } from 'node:fs/promises';
import { parse } from 'dotenv';
import { z } from 'zod';
import { connectorConfigSchema, sourceConfigSchema, type ConnectorConfig } from '../connector/config';
import { deviceIdentitySchema } from '../shared/types';
import type { SetupDraft } from '../shared/setup';
import { readConfig } from '../server/config';

export const setupDraftSchema = z.object({
  mode: z.enum(['tailscale', 'local', 'existing']),
  relayUrl: connectorConfigSchema.shape.relayUrl,
  relayPort: z.number().int().min(1024).max(65535),
  device: deviceIdentitySchema,
  workspaces: z.array(z.string().trim().min(1).max(4096)).min(1, 'Choose at least one project folder.').max(100),
  discover: z.boolean(),
  sources: z.array(sourceConfigSchema).max(100),
  managedOpenCode: z.string().optional(),
}).superRefine((draft, context) => {
  const issue = (message: string) => context.addIssue({ code: 'custom', message });
  if (!draft.discover && !draft.sources.length) issue('Add an agent source or enable discovery.');
  if (new Set(draft.sources.map((source) => source.id)).size !== draft.sources.length) issue('Source IDs must be unique.');
  const endpoints = draft.sources.map((source) => {
    try { return `${source.provider}:${source.url === 'stdio' ? source.url : new URL(source.url).origin}`; }
    catch { return `${source.provider}:${source.url}`; }
  });
  if (new Set(endpoints).size !== draft.sources.length) issue('Each agent endpoint should only be added once.');
  const url = new URL(draft.relayUrl);
  if (draft.mode === 'local' && (url.protocol !== 'http:' || !['localhost', '127.0.0.1'].includes(url.hostname) || Number(url.port) !== draft.relayPort)) issue('Local mode needs http://localhost:<relay port>.');
  if (draft.mode === 'tailscale' && (url.protocol !== 'https:' || !url.hostname.endsWith('.ts.net') || url.port)) issue('Use the stable https://<laptop>.<tailnet>.ts.net address from Tailscale Serve.');
  if (draft.managedOpenCode) {
    const source = draft.sources.find((source) => source.id === draft.managedOpenCode && source.provider === 'opencode');
    let url: URL | undefined;
    try { if (source) url = new URL(source.url); } catch { /* Source validation supplies the endpoint error. */ }
    if (!url || url.protocol !== 'http:' || url.hostname !== '127.0.0.1' || Number(url.port) < 1024 || !url.port) issue('Managed OpenCode needs an http://127.0.0.1:<port> source with a port above 1023.');
    if (Number(url?.port) === draft.relayPort && draft.mode !== 'existing') issue('OpenCode and the relay need different ports.');
  }
});

export const platformName = () => platform() === 'darwin' ? 'macOS' : platform() === 'win32' ? 'Windows' : 'Linux';
export const settingsPath = (root: string) => join(root, '.local', 'setup', 'settings.json');

export async function readOptional(path: string): Promise<string | undefined> {
  try { return await readFile(path, 'utf8'); }
  catch (error) { if ((error as NodeJS.ErrnoException).code === 'ENOENT') return undefined; throw error; }
}

export async function writePrivate(path: string, content: string) {
  await mkdir(dirname(path), { recursive: true, mode: 0o700 });
  const temporary = `${path}.${randomBytes(8).toString('hex')}.tmp`;
  try {
    await writeFile(temporary, content, { mode: 0o600, flag: 'wx' });
    await rename(temporary, path);
  } finally { await rm(temporary, { force: true }); }
}

export async function canonicalWorkspaces(input: string[], root: string): Promise<string[]> {
  const paths = z.array(z.string().trim().min(1).max(4096)).min(1, 'Choose at least one project folder.').max(100).parse(input);
  return [...new Set(await Promise.all(paths.map(async (directory) => {
    const expanded = directory.replace(/^~(?=[/\\]|$)/, homedir());
    if (!isAbsolute(expanded)) throw new Error(`Use an absolute project path, such as ${root}.`);
    try {
      const canonical = await realpath(expanded);
      if (!(await stat(canonical)).isDirectory()) throw new Error('Not a directory');
      return canonical;
    } catch { throw new Error(`Project folder not found or not accessible: ${directory}`); }
  })))];
}

export async function initialDraft(root: string, configPath: string): Promise<{ draft: SetupDraft; configured: boolean }> {
  const env = parse(await readOptional(join(root, '.env')) || '');
  const raw = await readOptional(configPath);
  const connector = raw ? connectorConfigSchema.parse(JSON.parse(raw)) : undefined;
  const saved = await readOptional(settingsPath(root));
  if (saved) {
    const value = z.object({ version: z.literal(1), draft: setupDraftSchema, connectorPath: z.string().optional() }).parse(JSON.parse(saved));
    if ((!value.connectorPath || resolve(value.connectorPath) === configPath) && (!connector || samePairing(connector, value.draft))) {
      const draft = connector ? { ...value.draft, device: connector.device, sources: connector.sources, discover: connector.discover, workspaces: connector.workspaces } : value.draft;
      if (draft.managedOpenCode && !draft.sources.some((source) => source.id === draft.managedOpenCode && source.provider === 'opencode' && source.url === value.draft.sources.find((item) => item.id === source.id)?.url)) draft.managedOpenCode = undefined;
      const envMatches = draft.mode === 'existing' || (env.PUBLIC_URL && new URL(env.PUBLIC_URL).origin === draft.relayUrl && Number(env.PORT || 4317) === draft.relayPort);
      if (envMatches && setupDraftSchema.safeParse(draft).success) return { draft, configured: true };
    }
  }
  const name = hostname().slice(0, 48);
  const relayPort = Number(env.PORT || 4317);
  const relayUrl = connector?.relayUrl || env.PUBLIC_URL || '';
  const mode = connector && (!env.PUBLIC_URL || new URL(connector.relayUrl).origin !== new URL(env.PUBLIC_URL).origin) ? 'existing' : relayUrl.startsWith('http:') ? 'local' : relayUrl && !new URL(relayUrl).hostname.endsWith('.ts.net') ? 'existing' : 'tailscale';
  return { configured: false, draft: {
    mode, relayUrl: mode === 'local' ? `http://localhost:${relayPort}` : relayUrl, relayPort,
    device: connector?.device || { id: `${name.toLowerCase().replace(/[^a-z0-9-]/g, '-').slice(0, 45)}-${randomBytes(3).toString('hex')}`, name, platform: platformName() },
    workspaces: connector?.workspaces || [root], discover: connector?.discover ?? true,
    sources: connector?.sources || [
      { id: 'opencode-local', label: 'OpenCode · laptop', provider: 'opencode', url: 'http://127.0.0.1:4096', passwordEnv: 'OPENCODE_SERVER_PASSWORD', usernameEnv: 'OPENCODE_SERVER_USERNAME' },
      { id: 'codex-managed', label: 'Codex · managed', provider: 'codex', url: 'stdio', tokenEnv: 'CODEX_REMOTE_TOKEN' },
    ],
    ...(!connector ? { managedOpenCode: 'opencode-local' } : {}),
  } };
}

/** Update only launcher-owned variables; preserve comments, provider settings, and the existing key. */
export function updateEnv(content: string, values: Record<string, string>): string {
  const remaining = new Set(Object.keys(values));
  // Consume entire dotenv assignments, including multiline quoted provider values.
  const assignment = /^[ \t]*(?:export[ \t]+)?([\w.-]+)(?:[ \t]*=[ \t]*|:[ \t]+)(?:'(?:\\'|[^'])*'|"(?:\\"|[^"])*"|`(?:\\`|[^`])*`|[^#\r\n]*)[ \t]*(?:#[^\r\n]*)?$/gm;
  const updated = content.replace(assignment, (line: string, key: string) => {
    if (!(key in values)) return line;
    if (!remaining.delete(key)) return '';
    return `${key}=${JSON.stringify(values[key])}`;
  });
  const lines = [updated.trimEnd()];
  for (const key of remaining) lines.push(`${key}=${JSON.stringify(values[key])}`);
  return `${lines.join('\n').trim()}\n`;
}

export async function prepareRelayEnv(root: string, draft: SetupDraft) {
  const content = await readOptional(join(root, '.env'));
  const env = parse(content || '');
  const dataDir = resolve(root, env.DATA_DIR || './data');
  if (env.PUBLIC_URL && new URL(env.PUBLIC_URL).origin !== new URL(draft.relayUrl).origin) {
    const state = await readOptional(join(dataDir, 'state.json'));
    if (state) {
      const value = JSON.parse(state) as { credentials?: unknown[]; nativeCredentials?: unknown[]; devices?: unknown[] };
      if (value.credentials?.length || value.nativeCredentials?.length || value.devices?.length) throw new Error('This relay already has a phone or computer enrolled at another URL. Keep its original URL. To migrate, follow the hostname recovery steps in README.md first.');
    }
  }
  const apiKey = env.REMOTE_API_KEY || `ar_${randomBytes(32).toString('base64url')}`;
  if (content !== undefined && !env.REMOTE_API_KEY) throw new Error('Your existing .env has no REMOTE_API_KEY. Add your relay key there before using this wizard.');
  const values = { REMOTE_API_KEY: apiKey, PUBLIC_URL: new URL(draft.relayUrl).origin, HOST: '127.0.0.1', PORT: String(draft.relayPort), DATA_DIR: env.DATA_DIR || './data', TRUST_PROXY: draft.mode === 'tailscale' ? '1' : '0' };
  const config = readConfig({ ...values, DATA_DIR: dataDir });
  // Keep existing keys/paths in their original quoting, including Windows backslashes.
  const changes = Object.fromEntries(Object.entries(values).filter(([key, value]) => env[key] !== value));
  const updated = updateEnv(content || '', changes);
  const parsed = parse(updated);
  if (Object.entries({ ...env, ...values }).some(([key, value]) => parsed[key] !== value)) throw new Error('Could not preserve the existing .env quoting. Update the relay variables in .env manually, then reopen setup.');
  return { content: updated, config: { ...config, staticDir: join(root, 'dist') } };
}

export function samePairing(config: ConnectorConfig, draft: SetupDraft) {
  return new URL(config.relayUrl).origin === new URL(draft.relayUrl).origin && config.device.id === draft.device.id && config.device.name === draft.device.name;
}
