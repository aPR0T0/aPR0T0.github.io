import { spawn, type ChildProcess } from 'node:child_process';
import { createServer } from 'node:net';
import { dirname, join, resolve } from 'node:path';
import { access } from 'node:fs/promises';
import { parse } from 'dotenv';
import { z } from 'zod';
import { Connector } from '../connector/runtime';
import { connectorConfigSchema, loadConfig, saveConfig, validateLocalEndpoint, type ConnectorConfig, type SourceConfig } from '../connector/config';
import { CodexRPC } from '../connector/adapters/codex-rpc';
import { discover } from '../connector/discovery';
import { createRelay } from '../server/app';
import { readConfig } from '../server/config';
import type { SetupDraft, SetupStatus, SetupSystem, SourceCheck } from '../shared/setup';
import { canonicalWorkspaces, initialDraft, platformName, prepareRelayEnv, readOptional, samePairing, settingsPath, setupDraftSchema, writePrivate } from './config';
import { checkRelay, checkTailscale, checkTool, connectTailscale, discoveredEndpoints, enableTailscale, openCodeHealth, runCommand, type RunCommand } from './system';

const pause = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));
const pairingSchema = z.object({ requestId: z.string().uuid(), code: z.string().regex(/^[A-Z2-9]{4}-[A-Z2-9]{4}$/), pollToken: z.string().min(32).max(200), expiresAt: z.number().int() });
const pollSchema = z.discriminatedUnion('status', [z.object({ status: z.literal('pending') }), z.object({ status: z.literal('approved'), deviceToken: z.string().min(32).max(200) })]);
type Pairing = z.infer<typeof pairingSchema> & { status: 'pending' | 'approved' | 'expired'; error?: string };

async function availablePort(port: number) {
  const socket = createServer();
  await new Promise<void>((resolve, reject) => {
    socket.once('error', () => reject(new Error(`Port ${port} is already in use. Stop the other process or choose a different port.`)));
    socket.listen(port, '127.0.0.1', () => socket.close(() => resolve()));
  });
}

export class SetupController {
  private draft!: SetupDraft;
  private configured = false;
  private started = false;
  private savedConnector?: ConnectorConfig;
  private connectorFile?: string;
  private relay?: ReturnType<typeof createRelay>;
  private connector?: Connector;
  private openCode?: { child: ChildProcess; url: string; workspace: string };
  private pairing?: Pairing;
  private pollTimer?: ReturnType<typeof setTimeout>;
  private message?: string;
  private queue: Promise<unknown> = Promise.resolve();
  private closing = false;
  reservedPort = 0;

  constructor(readonly root: string, readonly configPath: string, private run: RunCommand = runCommand) {}

  async initialize() {
    const initial = await initialDraft(this.root, this.configPath);
    this.draft = initial.draft; this.configured = initial.configured;
    this.connectorFile = await readOptional(this.configPath);
    if (this.connectorFile) this.savedConnector = connectorConfigSchema.parse(JSON.parse(this.connectorFile));
  }

  /** Serialize writes, process starts, and pairing delivery, including double-clicks. */
  exclusive<T>(action: () => Promise<T>): Promise<T> {
    const result = this.queue.then(() => {
      if (this.closing) throw new Error('The setup launcher is shutting down.');
      return action();
    });
    this.queue = result.catch(() => {});
    return result;
  }

  status(): SetupStatus {
    const connector = this.connector?.status();
    return {
      configured: this.configured, draft: this.draft,
      running: this.started || !!this.relay,
      relay: this.draft.mode === 'existing' ? 'external' : this.relay ? 'running' : 'stopped',
      connector: { paired: !!this.savedConnector && samePairing(this.savedConnector, this.draft), connected: connector?.connected ?? false, sources: connector?.sources || [] },
      ...(this.pairing ? { pairing: { status: this.pairing.status === 'pending' && this.pairing.expiresAt <= Date.now() ? 'expired' : this.pairing.status, code: this.pairing.code, expiresAt: this.pairing.expiresAt, ...(this.pairing.error ? { error: this.pairing.error } : {}) } } : {}),
      ...(this.message ? { message: this.message } : {}),
    };
  }

  async system(): Promise<SetupSystem> {
    const [opencode, codex, tailscale] = await Promise.all([
      checkTool(process.env.OPENCODE_BIN || 'opencode', this.run),
      checkTool(process.env.CODEX_BIN || 'codex', this.run),
      checkTailscale(this.draft.relayPort, this.run),
    ]);
    return { platform: platformName(), node: process.versions.node, projectDir: this.root, configPath: this.configPath, tools: { opencode, codex }, tailscale };
  }
  async network(port: number, enable: boolean, connect = false) {
    z.number().int().min(1024).max(65535).parse(port);
    if (port === this.reservedPort) throw new Error('Choose a relay port different from the setup page’s port.');
    return connect ? connectTailscale(port, this.run) : enable ? enableTailscale(port, this.run) : checkTailscale(port, this.run);
  }
  async discover() { return discoveredEndpoints(await discover()); }
  async workspaces(paths: string[]) { return canonicalWorkspaces(paths, this.root); }

  private async validated(input: unknown): Promise<SetupDraft> {
    const draft = setupDraftSchema.parse(input);
    if (draft.mode !== 'existing' && draft.relayPort === this.reservedPort) throw new Error('Choose a relay port different from the setup page’s port.');
    draft.relayUrl = new URL(draft.relayUrl).origin;
    draft.sources = draft.sources.map((source) => ({ ...source, url: validateLocalEndpoint(source.url, source.provider) }));
    draft.workspaces = await canonicalWorkspaces(draft.workspaces, this.root);
    draft.device.platform = platformName();
    return draft;
  }

  async save(input: unknown) {
    const draft = await this.validated(input);
    if (this.status().running) throw new Error('Stop the local services on the Ready step before changing saved settings.');
    if (this.pairing?.status === 'pending' && this.pairing.expiresAt > Date.now()) throw new Error('Finish the current phone pairing before changing settings.');
    await this.checkConnectorFile();
    if (this.savedConnector && !samePairing(this.savedConnector, draft)) throw new Error('This laptop already has a saved pairing. Keep its relay URL, computer name, and ID, or launch the wizard with --config pointing to a new connector file.');
    const env = draft.mode !== 'existing' ? await prepareRelayEnv(this.root, draft) : undefined;
    if (env) await writePrivate(join(this.root, '.env'), env.content);
    if (this.savedConnector) {
      const config = { ...this.savedConnector, workspaces: draft.workspaces, sources: draft.sources, discover: draft.discover };
      await saveConfig(this.configPath, config);
      this.savedConnector = config; this.connectorFile = await readOptional(this.configPath);
    }
    await writePrivate(settingsPath(this.root), `${JSON.stringify({ version: 1, connectorPath: this.configPath, draft }, null, 2)}\n`);
    this.draft = draft; this.configured = true; this.message = undefined;
    return this.status();
  }

  private async checkConnectorFile() {
    if (await readOptional(this.configPath) !== this.connectorFile) throw new Error('The connector file was changed outside this wizard. Restart the launcher to load those changes.');
  }

  async key() {
    if (!this.configured || this.draft.mode === 'existing') throw new Error('Use the relay API key from the computer hosting your relay.');
    const env = parse(await readOptional(join(this.root, '.env')) || '');
    const config = readConfig(env);
    if (config.origin !== this.draft.relayUrl) throw new Error('The relay URL changed outside this wizard. Restart the launcher to load it.');
    return { apiKey: config.apiKey };
  }

  async verifyRelay(url: string) {
    const relayUrl = connectorConfigSchema.shape.relayUrl.parse(url);
    return checkRelay(relayUrl);
  }

  private async probeOpenCode(source: SourceConfig): Promise<SourceCheck> {
    try {
      const password = process.env[source.passwordEnv || 'OPENCODE_SERVER_PASSWORD'];
      const username = process.env[source.usernameEnv || 'OPENCODE_SERVER_USERNAME'] || 'opencode';
      const response = await fetch(new URL('/global/health', source.url), {
        headers: { Accept: 'application/json', ...(password ? { Authorization: `Basic ${Buffer.from(`${username}:${password}`).toString('base64')}` } : {}) },
        signal: AbortSignal.timeout(3000), redirect: 'error',
      });
      if (response.status === 401) return { ok: false, message: `Set ${source.passwordEnv || 'OPENCODE_SERVER_PASSWORD'} in the launcher’s environment to match your OpenCode server, then restart the launcher.` };
      const version = response.ok ? openCodeHealth(await response.json()) : undefined;
      return version ? { ok: true, message: `OpenCode API connected (${version}).` } : { ok: false, message: 'This endpoint did not return an OpenCode health response. Check the server URL.' };
    } catch { return { ok: false, message: 'OpenCode is not reachable. Start its local server or select “Start with Agent Remote”, then test again.' }; }
  }

  private async startOpenCode(draft: SetupDraft) {
    const source = draft.sources.find((source) => source.id === draft.managedOpenCode);
    if (!source) return;
    if (this.openCode && (this.openCode.url !== source.url || this.openCode.workspace !== draft.workspaces[0])) await this.stopOpenCode();
    const probe = await this.probeOpenCode(source);
    if (probe.ok) return; // Reuse an existing server without taking ownership of it.
    if (this.openCode) await this.stopOpenCode();
    const port = Number(new URL(source.url).port);
    await availablePort(port);
    const env = { ...process.env };
    if (source.passwordEnv && process.env[source.passwordEnv]) env.OPENCODE_SERVER_PASSWORD = process.env[source.passwordEnv];
    if (source.usernameEnv && process.env[source.usernameEnv]) env.OPENCODE_SERVER_USERNAME = process.env[source.usernameEnv];
    const child = spawn(process.env.OPENCODE_BIN || 'opencode', ['serve', '--hostname', '127.0.0.1', '--port', String(port)], { cwd: draft.workspaces[0], env, stdio: 'ignore', windowsHide: true });
    const owned = { child, url: source.url, workspace: draft.workspaces[0] };
    this.openCode = owned;
    let failed = false;
    child.once('error', () => { failed = true; if (this.openCode === owned) this.openCode = undefined; });
    child.once('exit', () => { failed = true; if (this.openCode === owned) this.openCode = undefined; });
    const deadline = Date.now() + 25_000;
    while (Date.now() < deadline && !failed && !this.closing) {
      await pause(300);
      if ((await this.probeOpenCode(source)).ok && !failed) return;
    }
    await this.stopOpenCode();
    throw new Error('Could not start OpenCode. Install and sign in to OpenCode on this laptop, or connect an already-running server. OPENCODE_BIN can select its executable.');
  }

  async testSource(input: unknown, sourceId: string): Promise<SourceCheck> {
    const draft = await this.validated(input);
    const source = draft.sources.find((item) => item.id === sourceId);
    if (!source) throw new Error('Choose a configured source to test.');
    if (source.provider === 'opencode') {
      if (draft.managedOpenCode === source.id) {
        if (this.status().running && (this.draft.managedOpenCode !== source.id || this.draft.sources.find((item) => item.id === source.id)?.url !== source.url || this.draft.workspaces[0] !== draft.workspaces[0])) throw new Error('Stop local services before testing a different managed OpenCode server.');
        await this.startOpenCode(draft);
      }
      return this.probeOpenCode(source);
    }
    const rpc = new CodexRPC(source);
    try { await rpc.connect(); return { ok: true, message: 'Codex app-server connected. Model login is handled by codex login on this laptop.' }; }
    catch { return { ok: false, message: source.url === 'stdio' ? 'Could not start Codex app-server. Install Codex, run codex login, and restart this launcher. CODEX_BIN can select its executable.' : 'Codex app-server is not reachable. Check its WebSocket URL and CODEX_REMOTE_TOKEN if authentication is enabled.' }; }
    finally { rpc.close(); }
  }

  async start() {
    if (!this.configured) throw new Error('Save your setup before starting services.');
    this.message = undefined;
    await canonicalWorkspaces(this.draft.workspaces, this.root);
    if (this.draft.mode !== 'existing' && !this.relay) {
      await access(join(this.root, 'dist', 'index.html')).catch(() => { throw new Error('Build the app first with npm run setup:gui.'); });
      const env = parse(await readOptional(join(this.root, '.env')) || '');
      const config = readConfig({ ...env, DATA_DIR: resolve(this.root, env.DATA_DIR || './data') });
      if (config.origin !== this.draft.relayUrl || config.port !== this.draft.relayPort || config.host !== '127.0.0.1') throw new Error('The relay .env changed outside this wizard. Reopen setup and save matching settings before starting.');
      await availablePort(config.port);
      const relay = createRelay({ ...config, staticDir: join(this.root, 'dist') });
      try {
        await new Promise<void>((resolve, reject) => { relay.server.once('error', reject); relay.server.listen(config.port, '127.0.0.1', resolve); });
        this.relay = relay;
      } catch (error) { await relay.close(); throw error; }
    }
    this.started = true;
    await this.startOpenCode(this.draft).catch((error: Error) => { this.message = error.message; });
    if (this.savedConnector) await this.startConnector();
    if (this.pairing?.status === 'pending') this.schedulePoll();
    return this.status();
  }

  private relayAddress() { return this.draft.mode === 'existing' ? this.draft.relayUrl : `http://127.0.0.1:${this.draft.relayPort}`; }

  private async startConnector() {
    if (this.connector && !this.connector.status().stopped) return;
    await this.checkConnectorFile();
    const config = await loadConfig(this.configPath);
    if (!samePairing(config, this.draft)) throw new Error('The saved connector belongs to another relay or computer. Reopen setup to load its configuration.');
    const connector = new Connector({ ...config, relayUrl: this.relayAddress() }, (message) => { this.message = message; }, { stateDirectory: join(dirname(this.configPath), 'chat-data') });
    this.connector = connector;
    connector.start();
  }

  private async request(path: string, body?: unknown, token?: string): Promise<unknown> {
    const response = await fetch(new URL(`/api${path}`, this.relayAddress()), {
      method: body === undefined ? 'GET' : 'POST', headers: { ...(body === undefined ? {} : { 'Content-Type': 'application/json' }), ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }), signal: AbortSignal.timeout(10_000), redirect: 'error',
    });
    const value = await response.json() as { error?: string };
    if (!response.ok) throw new Error(typeof value.error === 'string' ? value.error.slice(0, 500) : `The relay returned HTTP ${response.status}.`);
    return value;
  }

  async pair() {
    if (!this.configured) throw new Error('Save your setup first.');
    if (!this.started) throw new Error('Start your saved setup before pairing.');
    if (this.pairing?.status === 'pending' && this.pairing.expiresAt > Date.now()) return this.status();
    if (this.connector?.status().connected) return this.status();
    await this.checkConnectorFile();
    const value = pairingSchema.parse(await this.request('/pairing/request', this.draft.device));
    if (value.expiresAt <= Date.now() || value.expiresAt > Date.now() + 11 * 60_000) throw new Error('The relay returned an invalid pairing expiry.');
    this.connector?.stop(); this.connector = undefined;
    this.pairing = { ...value, status: 'pending' };
    this.schedulePoll();
    return this.status();
  }

  private schedulePoll() {
    clearTimeout(this.pollTimer);
    if (this.closing || this.pairing?.status !== 'pending') return;
    this.pollTimer = setTimeout(() => { void this.exclusive(() => this.poll()).catch(() => {}); }, 2500);
    this.pollTimer.unref();
  }

  private async poll() {
    const pairing = this.pairing;
    if (!pairing || pairing.status !== 'pending') return;
    if (pairing.expiresAt <= Date.now()) { pairing.status = 'expired'; return; }
    try {
      const result = pollSchema.parse(await this.request(`/pairing/${pairing.requestId}/poll`, undefined, pairing.pollToken));
      if (this.closing || pairing !== this.pairing) return;
      pairing.error = undefined;
      if (result.status === 'approved') {
        await this.checkConnectorFile();
        const config: ConnectorConfig = { version: 1, relayUrl: this.draft.relayUrl, device: this.draft.device, token: result.deviceToken, workspaces: this.draft.workspaces, sources: this.draft.sources, discover: this.draft.discover };
        await saveConfig(this.configPath, config);
        this.savedConnector = config; this.connectorFile = await readOptional(this.configPath);
        pairing.status = 'approved';
        await this.request(`/pairing/${pairing.requestId}/ack`, {}, pairing.pollToken).catch(() => {});
        await this.startConnector();
      }
    } catch (error) { pairing.error = error instanceof Error ? error.message.slice(0, 500) : 'Could not complete pairing. Retrying…'; }
    this.schedulePoll();
  }

  private async stopOpenCode() {
    const owned = this.openCode; this.openCode = undefined;
    if (!owned || owned.child.exitCode !== null || owned.child.signalCode !== null) return;
    await new Promise<void>((resolve) => {
      const timeout = setTimeout(() => { owned.child.kill('SIGKILL'); resolve(); }, 3000);
      owned.child.once('exit', () => { clearTimeout(timeout); resolve(); });
      owned.child.kill('SIGTERM');
    });
  }

  async stop() {
    this.started = false;
    clearTimeout(this.pollTimer);
    this.connector?.stop(); this.connector = undefined;
    await this.stopOpenCode();
    if (this.relay) {
      await this.relay.close(); this.relay = undefined;
      if (this.pairing?.status === 'pending') this.pairing = undefined;
    }
    this.message = 'Local services stopped. Your saved setup is ready for next time.';
    return this.status();
  }

  async close() {
    this.closing = true; clearTimeout(this.pollTimer);
    await this.queue;
    await this.stop();
  }
}
