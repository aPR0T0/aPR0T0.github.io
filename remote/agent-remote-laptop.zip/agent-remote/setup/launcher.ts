import { rm } from 'node:fs/promises';
import { join } from 'node:path';
import { z } from 'zod';
import { readOptional, writePrivate } from './config';

const recordSchema = z.object({ version: z.literal(1), origin: z.string(), token: z.string().regex(/^[A-Za-z0-9_-]{43}$/), pid: z.number().int().positive(), configPath: z.string().optional() });
const recordPath = (root: string) => join(root, '.local', 'setup', 'launcher.json');
export async function rememberLauncher(root: string, origin: string, token: string, configPath?: string) {
  await writePrivate(recordPath(root), `${JSON.stringify({ version: 1, origin, token, pid: process.pid, configPath })}\n`);
}
export async function forgetLauncher(root: string, token: string) {
  try {
    const record = recordSchema.parse(JSON.parse(await readOptional(recordPath(root)) || '{}'));
    if (record.token === token) await rm(recordPath(root), { force: true });
  } catch { /* Another launch may have already replaced or removed its private record. */ }
}
export async function existingLauncher(root: string, port: number, configPath?: string) {
  try {
    const record = recordSchema.parse(JSON.parse(await readOptional(recordPath(root)) || '{}'));
    // A private record can never redirect the launcher or its capability off this laptop.
    if (record.origin !== `http://127.0.0.1:${port}`) return;
    if (configPath && record.configPath !== configPath) return;
    const response = await fetch(`${record.origin}/setup-api/status`, { headers: { 'X-Setup-Token': record.token }, signal: AbortSignal.timeout(1500), redirect: 'error' });
    if (!response.ok) return;
    const status = z.object({ configured: z.boolean(), running: z.boolean() }).parse(await response.json());
    return { ...record, ...status, url: `${record.origin}/setup#token=${record.token}` };
  } catch { return; }
}
