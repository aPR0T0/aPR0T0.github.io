import { randomBytes, timingSafeEqual } from 'node:crypto';
import { createServer } from 'node:http';
import type { AddressInfo } from 'node:net';
import { join, resolve } from 'node:path';
import express, { type ErrorRequestHandler } from 'express';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import { z, ZodError } from 'zod';
import { defaultConfigPath } from '../connector/config';
import { SetupController } from './controller';
import type { RunCommand } from './system';
import { readOptional, settingsPath } from './config';

export async function createSetup(options: { root: string; configPath?: string; run?: RunCommand }) {
  const root = resolve(options.root);
  const saved = await readOptional(settingsPath(root));
  const savedPath = saved ? z.object({ connectorPath: z.string().optional() }).parse(JSON.parse(saved)).connectorPath : undefined;
  const controller = new SetupController(root, resolve(options.configPath || savedPath || defaultConfigPath()), options.run);
  await controller.initialize();
  const token = randomBytes(32).toString('base64url');
  const app = express();
  const server = createServer(app);
  const origin = () => `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  app.disable('x-powered-by');
  app.use(helmet({
    contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'"], imgSrc: ["'self'", 'data:'], connectSrc: ["'self'"], objectSrc: ["'none'"], frameAncestors: ["'none'"], baseUri: ["'self'"], formAction: ["'self'"], upgradeInsecureRequests: null } },
    strictTransportSecurity: false, referrerPolicy: { policy: 'no-referrer' },
  }));
  app.use((req, res, next) => {
    res.setHeader('Cache-Control', 'no-store');
    const expected = new URL(origin());
    if (!['127.0.0.1', '::ffff:127.0.0.1', '::1'].includes(req.socket.remoteAddress || '') || req.headers.host !== expected.host || (req.headers.origin && req.headers.origin !== expected.origin) || req.headers['sec-fetch-site'] === 'cross-site') {
      res.status(403).json({ error: 'Open the private setup link on this laptop.' }); return;
    }
    controller.reservedPort = Number(expected.port);
    next();
  });
  app.use('/setup-api', rateLimit({ windowMs: 60_000, limit: 180, standardHeaders: 'draft-8', legacyHeaders: false, message: { error: 'Too many setup requests. Try again in a minute.' } }));
  app.use('/setup-api', (req, res, next) => {
    const supplied = req.headers['x-setup-token'];
    if (typeof supplied !== 'string' || Buffer.byteLength(supplied) !== Buffer.byteLength(token) || !timingSafeEqual(Buffer.from(supplied), Buffer.from(token))) {
      res.status(401).json({ error: 'Open the full private setup link printed by npm run setup:gui. It changes when the launcher restarts.' }); return;
    }
    if (!['GET', 'HEAD'].includes(req.method) && (req.headers.origin !== origin() || !req.is('application/json'))) {
      res.status(403).json({ error: 'Use the setup page on this laptop to make changes.' }); return;
    }
    next();
  });
  app.use('/setup-api', express.json({ limit: '64kb', strict: true }));
  app.get('/setup-api/status', (_req, res) => res.json(controller.status()));
  app.get('/setup-api/system', async (_req, res) => res.json(await controller.system()));
  app.post('/setup-api/network', async (req, res) => {
    const body = z.object({ port: z.number(), enable: z.boolean().default(false) }).parse(req.body);
    res.json(await controller.exclusive(() => controller.network(body.port, body.enable)));
  });
  app.post('/setup-api/workspaces', async (req, res) => res.json({ workspaces: await controller.workspaces(req.body?.workspaces) }));
  app.post('/setup-api/discover', async (_req, res) => res.json(await controller.exclusive(() => controller.discover())));
  app.post('/setup-api/source/test', async (req, res) => {
    const id = z.string().min(1).max(100).parse(req.body?.sourceId);
    res.json(await controller.exclusive(() => controller.testSource(req.body?.draft, id)));
  });
  app.post('/setup-api/save', async (req, res) => res.json(await controller.exclusive(() => controller.save(req.body))));
  app.post('/setup-api/start', async (_req, res) => res.json(await controller.exclusive(() => controller.start())));
  app.post('/setup-api/stop', async (_req, res) => res.json(await controller.exclusive(() => controller.stop())));
  app.post('/setup-api/key', async (_req, res) => res.json(await controller.exclusive(() => controller.key())));
  app.post('/setup-api/relay/check', async (req, res) => res.json(await controller.verifyRelay(z.string().max(2000).parse(req.body?.url))));
  app.post('/setup-api/pair', async (_req, res) => res.json(await controller.exclusive(() => controller.pair())));
  app.use('/setup-api', (_req, res) => res.status(404).json({ error: 'Setup endpoint not found.' }));
  app.use('/assets', express.static(join(root, 'dist', 'assets'), { index: false, dotfiles: 'deny' }));
  app.get(['/', '/setup', '/setup.html'], (_req, res) => res.sendFile(join(root, 'dist', 'setup.html')));
  app.use((_req, res) => res.status(404).type('text').send('Setup page not found.'));
  const errors: ErrorRequestHandler = (error, _req, res, _next) => {
    if (error instanceof ZodError) res.status(400).json({ error: error.issues[0]?.message || 'Check your setup fields.' });
    else if (error?.type === 'entity.too.large') res.status(413).json({ error: 'This setup request is too large.' });
    else res.status(400).json({ error: error instanceof Error ? error.message.slice(0, 700) : 'The setup request could not be completed.' });
  };
  app.use(errors);
  async function close() {
    await controller.close();
    if (server.listening) await new Promise<void>((resolve) => { server.close(() => resolve()); server.closeAllConnections(); });
  }
  return { app, server, token, controller, origin, close };
}
