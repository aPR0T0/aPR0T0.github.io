import { spawn } from 'node:child_process';
import { resolve } from 'node:path';

if (process.platform !== 'linux') throw new Error('The fingerprint companion is for Linux desktops.');
const child = spawn('/usr/bin/pkexec', ['/usr/bin/python3', '-I', resolve('linux-fingerprint/install.py')], { stdio: 'inherit' });
child.once('error', (error) => { console.error(error.message); process.exitCode = 1; });
child.once('exit', (code) => { process.exitCode = code ?? 1; });
