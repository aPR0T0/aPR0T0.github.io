import 'dotenv/config';
import { createInterface } from 'node:readline/promises';
import { stdin, stdout } from 'node:process';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { readConfig } from '../server/config';
import { Store } from '../server/store';

const config = readConfig();
if (!existsSync(join(config.dataDir, 'state.json'))) throw new Error('No relay state exists in DATA_DIR. Check your configuration before resetting passkeys.');
const running = await fetch(`http://${config.host === '0.0.0.0' ? '127.0.0.1' : config.host}:${config.port}/api/health`, { signal: AbortSignal.timeout(1500) }).then((response) => response.ok).catch(() => false);
if (running) throw new Error('Stop the relay before resetting its passkeys.');
const prompt = createInterface({ input: stdin, output: stdout });
const answer = await prompt.question(`Reset all passkeys for ${config.origin}? This enables enrollment with your relay API key. Type RESET to continue: `);
prompt.close();
if (answer !== 'RESET') { console.log('Cancelled.'); process.exit(0); }
const store = new Store(config.dataDir);
store.state.credentials = [];
store.state.nativeCredentials = [];
store.save();
console.log('Passkeys reset. Start the relay and enroll your phone using your API key.');
