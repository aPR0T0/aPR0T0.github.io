import { randomBytes } from 'node:crypto';
import { existsSync, writeFileSync } from 'node:fs';
import { createInterface } from 'node:readline/promises';
import { stdin, stdout } from 'node:process';

if (existsSync('.env')) {
  console.error('A .env already exists. Edit it to change your relay URL; your existing key has been preserved.');
  process.exit(1);
}
const prompt = createInterface({ input: stdin, output: stdout });
const input = (await prompt.question('Public app URL [http://localhost:5173 for development]: ')).trim() || 'http://localhost:5173';
prompt.close();
const url = new URL(input);
if (url.username || url.password || url.search || url.hash || url.pathname !== '/' || (url.protocol !== 'https:' && !(url.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(url.hostname)))) {
  throw new Error('Use an HTTPS origin, or http://localhost:5173 for local development.');
}
const key = `ar_${randomBytes(32).toString('base64url')}`;
writeFileSync('.env', `REMOTE_API_KEY=${key}\nPUBLIC_URL=${url.origin}\nHOST=127.0.0.1\nPORT=4317\nDATA_DIR=./data\nTRUST_PROXY=0\n`, { mode: 0o600, flag: 'wx' });
console.log(`\nRelay configured for ${url.origin}.\n\nYour private relay API key:\n${key}\n\nSave it in your password manager. You will enter it on your phone, then register a passkey.\n\n${url.protocol === 'https:' ? 'Build with npm run build, then follow the HTTPS deployment steps in README.md.' : 'Start development with npm run dev and open http://localhost:5173.'}`);
