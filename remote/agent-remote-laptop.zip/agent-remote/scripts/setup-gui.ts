import 'dotenv/config';
import { access } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { resolve } from 'node:path';
import { parseArgs } from 'node:util';
import { createSetup } from '../setup/app';
import { existingLauncher, forgetLauncher, rememberLauncher } from '../setup/launcher';

const { values } = parseArgs({ options: { port: { type: 'string', default: '4316' }, config: { type: 'string' }, start: { type: 'boolean' }, 'no-open': { type: 'boolean' }, help: { type: 'boolean', short: 'h' } } });
const root = process.cwd();

function openBrowser(url: string) {
  const binary = process.platform === 'darwin' ? 'open' : process.platform === 'win32' ? 'rundll32.exe' : 'xdg-open';
  const args = process.platform === 'win32' ? ['url.dll,FileProtocolHandler', url] : [url];
  const child = spawn(binary, args, { stdio: 'ignore', detached: true, windowsHide: true });
  child.on('error', () => {});
  child.unref();
}

async function main() {
  if (values.help) {
    console.log('Agent Remote · laptop setup\n\n  npm run setup:gui                 Build and open the one-time web wizard\n  npm run local                     Start your saved setup and open its controls\n  npm run local -- --no-open         Start without opening a browser\n\nOptions: --port 4316  --config /path/to/connector.json  --no-open\n\nThe setup page listens only on 127.0.0.1. Keep the launcher running while using your remote.');
    return;
  }
  const [major, minor] = process.versions.node.split('.').map(Number);
  if (major < 22 || (major === 22 && minor < 13)) throw new Error('Node.js 22.13+ is required. Run nvm use 24, or install Node.js 24, then launch setup again.');
  const port = Number(values.port);
  if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('Choose a setup port between 1024 and 65535.');
  const running = await existingLauncher(root, port, values.config ? resolve(values.config) : undefined);
  if (running) {
    if (values.start && running.configured && !running.running) {
      const response = await fetch(`${running.origin}/setup-api/start`, { method: 'POST', headers: { Origin: running.origin, 'Content-Type': 'application/json', 'X-Setup-Token': running.token }, body: '{}', signal: AbortSignal.timeout(45_000), redirect: 'error' });
      if (!response.ok) console.error('The saved setup needs attention. Open its control page to continue.');
    }
    console.log(`Agent Remote is already running.\n${running.url}`);
    if (!values['no-open']) openBrowser(running.url);
    return;
  }
  await access(resolve(root, 'dist', 'setup.html')).catch(() => { throw new Error('Build the setup page first: npm run setup:gui'); });
  const setup = await createSetup({ root, configPath: values.config });
  try {
    await new Promise<void>((resolve, reject) => { setup.server.once('error', reject); setup.server.listen(port, '127.0.0.1', resolve); });
  } catch (error) { await setup.close(); throw error; }
  setup.controller.reservedPort = port;
  try { await rememberLauncher(root, setup.origin(), setup.token, setup.controller.configPath); }
  catch (error) { await setup.close(); throw error; }
  const url = `${setup.origin()}/setup#token=${setup.token}`;
  console.log(`\nAgent Remote · laptop setup\n\nOpen this private link on this laptop:\n${url}\n\nKeep this terminal running. You can close the browser after setup.\nPress Ctrl+C to stop local services.\n`);
  let stopping = false;
  for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => {
    if (stopping) return;
    stopping = true;
    void setup.close().then(() => forgetLauncher(root, setup.token)).then(() => process.exit(0));
  });
  if (values.start) {
    try { await setup.controller.exclusive(() => setup.controller.start()); }
    catch (error) { console.error(`Startup needs attention: ${error instanceof Error ? error.message : 'Open the setup page.'}`); }
  }
  if (!values['no-open']) openBrowser(url);
}
void main().catch((error) => { console.error(error instanceof Error ? error.message : 'Could not start the setup GUI.'); process.exitCode = 1; });
