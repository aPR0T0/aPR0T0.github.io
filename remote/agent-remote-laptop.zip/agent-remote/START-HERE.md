# Agent Remote — start here

## I only want to use my agents from this device

1. Install **Tailscale** from https://tailscale.com/download.
2. Connect it using the same account/network as your relay laptop.
3. Open https://apr0t0.github.io/remote/ and enter the laptop's Tailscale HTTPS address.
4. Unlock with your relay key and a passkey. A phone passkey or security key works on laptops without a fingerprint reader.

For a new device, create a one-time **Link another device** code in Settings on an unlocked phone or browser. Older Android apps call this **Authorize another phone**. Copy the code, then select **Link a new device** on the new browser and enter it with your relay key. With relay 0.5.2 or newer, you can switch apps or lock the authorizing device after copying; finish linking within five minutes of creating the code.

## I want to connect this laptop's OpenCode/Codex agents

1. Install **Node.js 24** from https://nodejs.org/en/download and **Tailscale** from https://tailscale.com/download.
2. Sign Tailscale into the same account/network as the relay laptop.
3. Extract the complete ZIP into a permanent folder.
4. Open the launcher for your system:
   - **Windows:** `Start Agent Remote.cmd`
   - **macOS:** `Start Agent Remote.command`. If needed, open Terminal in this folder and run `bash "Start Agent Remote.command"`.
   - **Linux:** allow executing `Start Agent Remote.sh` in its file Properties, or run `bash "Start Agent Remote.sh"` in this folder.
5. The first launch installs dependencies and opens the local setup page. Choose **Connect another laptop**, enter your existing relay URL, select project folders and agent connections, then approve this laptop from your unlocked phone/browser.

**After setup, open the same launcher again.** It starts the saved setup, or reopens the control page if it is already running. Keep its terminal window/process running while using the laptop's agents remotely.

## This is my first relay laptop

Use the same launcher, but choose **This laptop + Tailscale** in the wizard. Enable private HTTPS, choose projects and agents, then **Save & start**. Copy the resulting `.ts.net` address into the public start page on your other devices. Keep the relay laptop awake and online.

## Existing source checkout

You can also run `npm ci` and `npm run setup:gui`, then `npm run local` for later launches. When using nvm, run `nvm use 24` first. The downloadable kit already includes the built browser pages.

## Connection help

- Tailscale must be connected on **both** the viewing device and the relay laptop.
- The Tailscale device list should show the relay laptop. Check the account/network if it does not.
- The relay laptop must remain awake with Agent Remote running.
- Open `https://YOUR-LAPTOP.YOUR-TAILNET.ts.net/api/health` in the viewing device's browser. `"ok":true` confirms the route works.
- For an Android phone, check that its browser/Agent Remote is included in Tailscale's app routing and that another VPN hasn't replaced Tailscale.
- If you edit program files or install a newer kit, stop the existing launcher before opening the updated copy. Keep `.env`, `.local/setup/`, and the relay `data/` directory when updating.
- If the launcher can't find an installed agent, set `OPENCODE_BIN` or `CODEX_BIN` to its executable, or connect an already-running local server in the wizard.

The kit contains application code and browser assets, with no personal pairing, relay key, account login, or conversation data. Your setup is created locally. GitHub Pages provides the start page and download; the live relay remains on your laptop.

Server rental is $0. Tailscale Personal is free for eligible personal use. Model-provider subscriptions/API use, internet access, and electricity remain separate.

More detail: `docs/SETUP.md` and `README.md`.
