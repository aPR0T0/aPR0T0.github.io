import { createHash } from 'node:crypto';
import { access, mkdir, readFile, writeFile } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { delimiter, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
process.chdir(root);
const [major, minor] = process.versions.node.split('.').map(Number);
if (major < 22 || (major === 22 && minor < 13)) {
  console.error(`Node.js ${process.versions.node} is too old. Install Node.js 24 from https://nodejs.org/en/download, then open this launcher again.`);
  process.exit(1);
}
const env = { ...process.env, PATH: [join(root, 'node_modules', '.bin'), dirname(process.execPath), process.env.PATH || ''].join(delimiter) };
async function run(binary, args, shell = false) {
  await new Promise((resolve, reject) => {
    const child = spawn(binary, args, { cwd: root, env, stdio: 'inherit', shell, windowsHide: false });
    const stop = (signal) => { if (!child.killed) child.kill(signal); };
    const interrupt = () => stop('SIGINT'); const terminate = () => stop('SIGTERM');
    process.on('SIGINT', interrupt); process.on('SIGTERM', terminate);
    const cleanup = () => { process.off('SIGINT', interrupt); process.off('SIGTERM', terminate); };
    child.once('error', (error) => { cleanup(); reject(error); });
    child.once('exit', (code, signal) => { cleanup(); code === 0 || signal === 'SIGINT' || signal === 'SIGTERM' ? resolve() : reject(new Error(`The launcher command exited with code ${code}.`)); });
  });
}
try {
  await access(join(root, 'dist', 'setup.html')).catch(() => { throw new Error('The setup page is missing. Extract the complete laptop kit, or run npm run build in the source project.'); });
  const digest = createHash('sha256').update(await readFile(join(root, 'package-lock.json'))).digest('hex');
  const stamp = join(root, '.local', 'setup', 'dependencies.sha256');
  const installed = await access(join(root, 'node_modules', 'tsx', 'package.json')).then(() => true, () => false);
  const previous = await readFile(stamp, 'utf8').catch(() => '');
  if (!installed || previous.trim() !== digest) {
    console.log('\nFirst launch or updated dependencies: preparing Agent Remote. This can take a few minutes.\n');
    // Only the fixed npm command uses the Windows command shim; user input is never passed to a shell.
    await run(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['ci', '--no-audit', '--no-fund'], process.platform === 'win32');
    await mkdir(dirname(stamp), { recursive: true, mode: 0o700 });
    await writeFile(stamp, `${digest}\n`, { mode: 0o600 });
  }
  await run(process.execPath, ['--import', 'tsx', 'scripts/setup-gui.ts', '--start', ...process.argv.slice(2)]);
} catch (error) {
  console.error(error instanceof Error ? error.message : 'Could not launch Agent Remote.');
  console.error('Your saved setup stays in this folder and your Agent Remote user configuration. Open START-HERE.md for help.');
  process.exitCode = 1;
}
