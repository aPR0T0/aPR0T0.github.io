import { createHash } from 'node:crypto';
import { z } from 'zod';
import type { LocalAgent } from './types';
import { exportedChatSchema, MAX_TRANSFER_TEXT, type ExportedChat } from './transfers';

const detailSchema = z.object({
  messages: z.array(z.object({
    id: z.string().max(300), role: z.enum(['user', 'assistant', 'tool', 'system']),
    text: z.string().max(32_000), title: z.string().max(500).optional(), state: z.string().max(100).optional(),
  })).max(200),
  truncated: z.boolean().optional(),
});

/** Best-effort credential masking. Review remains necessary for secrets without
 * recognizable formats; no claim is made that arbitrary prose is secret-free. */
export function redactCredentials(input: string): { text: string; redactions: number } {
  let redactions = 0;
  const mask = () => { redactions++; return '[REDACTED CREDENTIAL]'; };
  let text = input.replace(/-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----[\s\S]*?(?:-----END (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----|$)/g, mask);
  text = text.replace(/\b(?:sk-[A-Za-z0-9_-]{16,}|gh[pousr]_[A-Za-z0-9_]{20,}|github_pat_[A-Za-z0-9_]{20,}|ar[dn]?_[A-Za-z0-9_-]{24,}|AKIA[0-9A-Z]{16})\b/g, mask);
  text = text.replace(/(\bAuthorization\s*[:=]\s*)(?:Bearer|Basic)\s+[^\s"',;]+/gi, (_match, label: string) => `${label}${mask()}`);
  text = text.replace(/(\b(?:[A-Z][A-Z0-9_]*_(?:KEY|TOKEN|SECRET|PASSWORD)|api[-_]?key|password|passwd|client[-_]?secret|access[-_]?token|refresh[-_]?token)["']?\s*[:=]\s*)("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|[^\s,;&]+)/gi, (_match, label: string, value: string) => value.startsWith('[REDACTED') ? `${label}${value}` : `${label}${mask()}`);
  text = text.replace(/(https?:\/\/)[^\s/:@]+:[^\s/@]+@/gi, (_match, protocol: string) => `${protocol}${mask()}@`);
  return { text, redactions };
}

export function exportConversation(agent: LocalAgent, rawDetail: unknown): ExportedChat {
  const detail = detailSchema.parse(rawDetail);
  const revision = createHash('sha256').update(JSON.stringify({ id: agent.id, title: agent.title, updatedAt: agent.updatedAt, detail })).digest('hex');
  let redactions = 0;
  const visible = detail.messages.filter((message) => ['user', 'assistant'].includes(message.role) && message.text.trim()).map((message) => {
    const redacted = redactCredentials(message.text); redactions += redacted.redactions;
    return `${message.role === 'user' ? 'User' : 'Assistant'}:\n${redacted.text}`;
  });
  const selected: string[] = [];
  let length = 0;
  for (const message of visible.slice().reverse()) {
    if (length + message.length + 2 > MAX_TRANSFER_TEXT - 100) break;
    selected.unshift(message); length += message.length + 2;
  }
  if (!selected.length) throw new Error('This chat has no visible conversation text to transfer.');
  const omittedMessages = visible.length - selected.length;
  const title = redactCredentials(agent.title);
  redactions += title.redactions;
  return exportedChatSchema.parse({
    title: title.text, revision,
    context: `${omittedMessages ? '[Earlier visible messages omitted to fit the handoff limit.]\n\n' : ''}${selected.join('\n\n')}`,
    includedMessages: selected.length, omittedMessages,
    limitedHistory: !!detail.truncated || detail.messages.length >= 200 || omittedMessages > 0,
    redactions,
  });
}
