import type { Agent, AgentStatus, Device } from './types';

export const chatKey = (agent: Pick<Agent, 'id' | 'deviceId'>) => `${agent.deviceId}/${agent.id}`;
export function effectiveStatus(agent: Agent, device: Device | undefined, live = true): AgentStatus {
  const source = device?.sources.find((item) => item.id === agent.sourceId);
  if (!live || !device?.connected || source?.connected === false || agent.status === 'offline') return 'offline';
  return agent.approvals.length ? 'waiting' : agent.status;
}

export interface ChatEntry { agent: Agent; depth: number; context: boolean }
/** Device-scoped ancestry: IDs and titles may be identical on different laptops. */
export function chatEntries(agents: Agent[], devices: Device[], filter = 'all', query = '', live = true): ChatEntry[] {
  const deviceMap = new Map(devices.map((device) => [device.id, device]));
  const normalized = agents.map((agent) => ({ ...agent, status: effectiveStatus(agent, deviceMap.get(agent.deviceId), live) }));
  const byKey = new Map(normalized.map((agent) => [chatKey(agent), agent]));
  const search = query.trim().toLowerCase();
  const matched = new Set(normalized.filter((agent) => (filter === 'all' || agent.status === filter) && (!search || `${agent.title} ${agent.directory} ${agent.provider} ${deviceMap.get(agent.deviceId)?.name || agent.deviceId}`.toLowerCase().includes(search))).map(chatKey));
  const included = new Set(matched);
  for (const key of matched) {
    let agent = byKey.get(key);
    const visited = new Set([key]);
    while (agent?.parentId) {
      const parent = `${agent.deviceId}/${agent.parentId}`;
      if (visited.has(parent) || !byKey.has(parent)) break;
      visited.add(parent); included.add(parent); agent = byKey.get(parent);
    }
  }
  const rank = (agent: Agent) => agent.status === 'waiting' ? 0 : agent.status === 'working' ? 1 : 2;
  const sorted = normalized.filter((agent) => included.has(chatKey(agent))).sort((a, b) => rank(a) - rank(b) || b.updatedAt - a.updatedAt || chatKey(a).localeCompare(chatKey(b)));
  const children = new Map<string, Agent[]>();
  for (const agent of sorted) if (agent.parentId) {
    const key = `${agent.deviceId}/${agent.parentId}`;
    children.set(key, [...(children.get(key) || []), agent]);
  }
  const result: ChatEntry[] = [];
  const visited = new Set<string>();
  function append(agent: Agent, depth: number) {
    const key = chatKey(agent);
    if (visited.has(key)) return;
    visited.add(key); result.push({ agent, depth: Math.min(depth, 6), context: !matched.has(key) });
    if (depth < 32) for (const child of children.get(key) || []) append(child, depth + 1);
  }
  for (const agent of sorted) if (!agent.parentId || !included.has(`${agent.deviceId}/${agent.parentId}`)) append(agent, 0);
  for (const agent of sorted) if (!visited.has(chatKey(agent))) append(agent, 0);
  return result;
}
