import { z } from 'zod';

export const providerSchema = z.enum(['opencode', 'codex']);
export type Provider = z.infer<typeof providerSchema>;
export const statusSchema = z.enum(['working', 'waiting', 'idle', 'error', 'offline', 'unknown']);
export type AgentStatus = z.infer<typeof statusSchema>;

export const questionSchema = z.object({
  id: z.string().max(200),
  question: z.string().max(12_000),
  options: z.array(z.object({ label: z.string().max(500), description: z.string().max(2000).optional() })).max(30),
  multiple: z.boolean().optional(),
});
export const approvalSchema = z.object({
  id: z.string().max(200),
  title: z.string().max(500),
  detail: z.string().max(24_000),
  kind: z.enum(['permission', 'question', 'unsupported']),
  questions: z.array(questionSchema).max(30).optional(),
});
export type Approval = z.infer<typeof approvalSchema>;

export const agentSchema = z.object({
  id: z.string().min(1).max(300),
  nativeId: z.string().max(200),
  sourceId: z.string().max(100),
  provider: providerSchema,
  title: z.string().max(500),
  directory: z.string().max(2000),
  status: statusSchema,
  preview: z.string().max(2000),
  updatedAt: z.number().finite(),
  model: z.string().max(200).optional(),
  parentId: z.string().max(300).optional(),
  capabilities: z.object({ messages: z.boolean(), prompt: z.boolean(), stop: z.boolean() }),
  approvals: z.array(approvalSchema).max(100),
  handoff: z.object({
    id: z.string().uuid(),
    fromDeviceId: z.string().max(64),
    fromDeviceName: z.string().max(48),
    phase: z.enum(['paused', 'starting', 'active', 'uncertain']),
  }).optional(),
});
export type LocalAgent = z.infer<typeof agentSchema>;
export type Agent = LocalAgent & { deviceId: string };

export const sourceSchema = z.object({
  id: z.string().max(100),
  label: z.string().max(200),
  provider: providerSchema,
  connected: z.boolean(),
  error: z.string().max(1000).optional(),
  canCreate: z.boolean(),
  canTransfer: z.boolean().optional(),
});
export type Source = z.infer<typeof sourceSchema>;
export interface Device {
  id: string;
  name: string;
  platform: string;
  connected: boolean;
  lastSeen: number;
  pairedAt: number;
  sources: Source[];
  workspaces: string[];
}
export interface Snapshot {
  devices: Device[];
  agents: Agent[];
  at: number;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant' | 'tool' | 'system';
  text: string;
  title?: string;
  state?: string;
}
export interface AgentDetail { messages: Message[]; truncated?: boolean }
export interface SourceOptions {
  models: { id: string; name: string }[];
  agents: { id: string; name: string }[];
}

export const commandSchema = z.discriminatedUnion('action', [
  z.object({ action: z.literal('agent.messages'), agentId: z.string().min(1).max(300) }),
  z.object({ action: z.literal('agent.prompt'), agentId: z.string().min(1).max(300), text: z.string().trim().min(1).max(32_000), model: z.string().max(200).optional() }),
  z.object({ action: z.literal('agent.stop'), agentId: z.string().min(1).max(300) }),
  z.object({ action: z.literal('agent.approval'), agentId: z.string().min(1).max(300), approvalId: z.string().max(200), decision: z.enum(['approve', 'deny']) }),
  z.object({ action: z.literal('agent.answer'), agentId: z.string().min(1).max(300), approvalId: z.string().max(200), answers: z.record(z.string().max(200), z.array(z.string().max(4000)).max(30)) }),
  z.object({ action: z.literal('agent.create'), sourceId: z.string().max(100), workspace: z.string().max(2000), text: z.string().trim().min(1).max(32_000), model: z.string().max(200).optional(), agent: z.string().max(100).optional() }),
  z.object({ action: z.literal('source.options'), sourceId: z.string().max(100), workspace: z.string().max(2000) }),
]);
export type Command = z.infer<typeof commandSchema>;

export const bridgeMessageSchema = z.discriminatedUnion('type', [
  z.object({ type: z.literal('snapshot'), agents: z.array(agentSchema).max(2000), sources: z.array(sourceSchema).max(100), workspaces: z.array(z.string().max(2000)).max(100) }),
  z.object({ type: z.literal('result'), requestId: z.string().uuid(), result: z.unknown().optional(), error: z.string().max(2000).optional() }),
  z.object({ type: z.literal('changed'), agentId: z.string().max(300).optional() }),
]);
export type BridgeMessage = z.infer<typeof bridgeMessageSchema>;

export const deviceIdentitySchema = z.object({
  name: z.string().trim().min(2).max(48),
  id: z.string().trim().regex(/^[a-zA-Z0-9][a-zA-Z0-9._-]{2,63}$/, 'Use 3–64 letters, numbers, dots, underscores, or hyphens.'),
  platform: z.string().max(80),
});
export type DeviceIdentity = z.infer<typeof deviceIdentitySchema>;
export interface PairingPreview extends DeviceIdentity { requestId: string; expiresAt: number }
