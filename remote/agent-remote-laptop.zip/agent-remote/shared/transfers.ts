import { z } from 'zod';
import { commandSchema, providerSchema } from './types';

export const MAX_TRANSFER_TEXT = 64_000;
export const transferTextSchema = z.string().trim().min(1, 'The transferred context cannot be empty.').max(MAX_TRANSFER_TEXT);
export const provenanceSchema = z.object({
  deviceId: z.string().min(3).max(64),
  deviceName: z.string().min(2).max(48),
  agentId: z.string().min(1).max(300),
  provider: providerSchema,
}).strict();

export const exportCommandSchema = z.object({ action: z.literal('chat.export'), agentId: z.string().min(1).max(300) }).strict();
export const stageCommandSchema = z.object({
  action: z.literal('chat.stage'),
  transferId: z.string().uuid(),
  sourceId: z.string().min(1).max(100),
  provider: providerSchema,
  workspace: z.string().min(1).max(2000),
  title: z.string().min(1).max(500),
  context: transferTextSchema,
  from: provenanceSchema,
  model: z.string().max(200).optional(),
}).strict();
export type StageCommand = z.infer<typeof stageCommandSchema>;
export const bridgeCommandSchema = z.union([commandSchema, exportCommandSchema, stageCommandSchema]);
export type BridgeCommand = z.infer<typeof bridgeCommandSchema>;

export const exportedChatSchema = z.object({
  title: z.string().min(1).max(500),
  revision: z.string().regex(/^[a-f0-9]{64}$/),
  context: transferTextSchema,
  includedMessages: z.number().int().min(1).max(200),
  omittedMessages: z.number().int().min(0).max(1000),
  limitedHistory: z.boolean(),
  redactions: z.number().int().min(0),
}).strict();
export type ExportedChat = z.infer<typeof exportedChatSchema>;

export const prepareTransferSchema = z.object({
  fromDeviceId: z.string().min(3).max(64),
  agentId: z.string().min(1).max(300),
  toDeviceId: z.string().min(3).max(64),
  sourceId: z.string().min(1).max(100),
  workspace: z.string().min(1).max(2000),
  model: z.string().max(200).optional(),
}).strict();
export type TransferRequest = z.infer<typeof prepareTransferSchema>;

export interface TransferPreview {
  id: string;
  reviewHash: string;
  expiresAt: number;
  title: string;
  context: string;
  from: z.infer<typeof provenanceSchema>;
  destination: { deviceId: string; deviceName: string; sourceId: string; provider: z.infer<typeof providerSchema>; workspace: string };
  includedMessages: number;
  omittedMessages: number;
  limitedHistory: boolean;
  redactions: number;
}
export interface TransferResult {
  id: string;
  status: 'preparing' | 'completed' | 'uncertain';
  destinationDeviceId: string;
  agentId: string;
  paused: boolean;
}
