import type { SourceConfig } from '../connector/config';
import type { DeviceIdentity, Provider, Source } from './types';

export interface SetupDraft {
  mode: 'tailscale' | 'local' | 'existing';
  relayUrl: string;
  relayPort: number;
  device: DeviceIdentity;
  workspaces: string[];
  discover: boolean;
  sources: SourceConfig[];
  managedOpenCode?: string;
}

export interface ToolCheck { available: boolean; version?: string }
export interface TailscaleStatus {
  installed: boolean;
  running: boolean;
  url?: string;
  serving: boolean;
  conflict: boolean;
  message: string;
  devices?: { name: string; os: string; online: boolean }[];
}
export interface SetupSystem {
  platform: string;
  node: string;
  projectDir: string;
  configPath: string;
  tools: { opencode: ToolCheck; codex: ToolCheck };
  tailscale: TailscaleStatus;
}
export interface SetupStatus {
  configured: boolean;
  draft: SetupDraft;
  running: boolean;
  relay: 'stopped' | 'running' | 'external';
  connector: { paired: boolean; connected: boolean; sources: Source[] };
  pairing?: { status: 'pending' | 'approved' | 'expired'; code: string; expiresAt: number; error?: string };
  message?: string;
}
export interface SourceCheck { ok: boolean; message: string }
export interface DiscoveredSources {
  endpoints: { provider: Provider; url: string }[];
  warning?: string;
}
